#!/bin/bash
#
# DKVPS - SSH/SFTP Management Module
#

ssh_handler() {
    local action="$1"
    shift
    case "$action" in
        port)     ssh_change_port "$@" ;;
        password) ssh_change_password "$@" ;;
        sftp)     ssh_change_sftp_password "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown SSH action: $action"
            fi
            ssh_menu
            ;;
    esac
}

ssh_menu() {
    load_config
    echo ""
    print_subheader "SSH/SFTP Management"
    echo ""
    echo "  SSH Port: ${port_ssh:-22}"
    echo "  SSHD:     $(service_status sshd)"
    echo ""

    local options=(
        "Change SSH/SFTP Port"
        "Change Root Password"
        "Change SFTP User Password"
        "View Failed Login Attempts"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") ssh_change_port ;;
            "${options[1]}") ssh_change_password ;;
            "${options[2]}") ssh_change_sftp_password ;;
            "${options[3]}") ssh_login_failed ;;
            *) return ;;
        esac
    done
}

ssh_change_port() {
    local new_port="${1:-}"
    load_config

    echo ""
    echo "Current SSH port: ${port_ssh:-22}"
    if [[ -z "$new_port" ]]; then
        read -p "Enter new SSH port: " new_port
    fi

    if ! [[ "$new_port" =~ ^[0-9]+$ ]] || [[ "$new_port" -lt 1 ]] || [[ "$new_port" -gt 65535 ]]; then
        print_error "Invalid port number."
        return 1
    fi

    # Update sshd_config
    sed -i "s/^#*Port .*/Port $new_port/" /etc/ssh/sshd_config

    # SELinux
    if command -v semanage &>/dev/null; then
        semanage port -a -t ssh_port_t -p tcp "$new_port" 2>/dev/null
    fi

    # Firewall
    firewall_open_port "$new_port"
    if ! sshd -t 2>/dev/null; then print_error "sshd config test failed, port not changed"; return 1; fi
    if systemctl is-active --quiet ssh.socket 2>/dev/null; then
        # Ubuntu 22.10+: sshd is socket-activated, the port comes from the
        # socket unit (regenerated from sshd_config on daemon-reload)
        systemctl daemon-reload; systemctl restart ssh.socket
    else
        systemctl reload "$SSH_SERVICE" 2>/dev/null || systemctl restart "$SSH_SERVICE"
    fi
    if ! ss -ltn 2>/dev/null | grep -q ":$new_port "; then
        print_warning "sshd is not listening on $new_port yet: keep this session open and check 'ss -ltn'"
    fi

    # Save config
    set_config "port_ssh" "$new_port"

    print_success "SSH port changed to $new_port"
    print_warning "Remember: ssh -p $new_port user@${ip:-$(get_public_ip)}"
}

ssh_change_password() {
    echo ""
    print_info "Changing root password..."
    passwd root
}

ssh_change_sftp_password() {
    choose_domain || return
    local domain="$SELECTED_DOMAIN"
    local username=$(get_username "$domain")

    echo ""
    print_info "Changing SFTP password for user: $username"
    local new_password=$(generate_password 32)
    echo "$username:$new_password" | chpasswd

    set_config "password_sftp" "$new_password" "$DKVPS_USER_DIR/.$domain.conf"

    print_success "SFTP password changed for $username"
    echo "  New Password: $new_password"
}

ssh_login_failed() {
    echo ""
    print_subheader "Failed Login Attempts"
    echo ""

    local src
    if [[ -f /var/log/secure ]]; then src="cat /var/log/secure"
    elif [[ -f /var/log/auth.log ]]; then src="cat /var/log/auth.log"
    else src="journalctl -q --no-pager -t sshd -t sshd-session --since -7days"; fi
    echo "Failed attempts by IP (last 7 days):"
    $src 2>/dev/null | grep -E "Failed password|Invalid user|authentication failure" \
        | grep -oE "from [0-9a-fA-F:.]+" | awk '{print $2}' | sort | uniq -c | sort -rn | head -20
    echo ""
    echo "Last successful logins:"
    if command -v last >/dev/null 2>&1; then last -n 10 2>/dev/null | grep -v "^$"
    elif command -v wtmpdb >/dev/null 2>&1; then wtmpdb last -n 10 2>/dev/null
    else $src 2>/dev/null | grep "Accepted" | tail -10; fi
}
