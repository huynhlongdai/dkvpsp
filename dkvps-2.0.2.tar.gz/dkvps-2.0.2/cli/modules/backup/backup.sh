#!/bin/bash
#
# DKVPS - Backup & Restore Module
# Supports: Local backup, Cloud backup (rclone), restic (see restic.sh)
#
source "${CLI_DIR}/modules/backup/restic.sh"

backup_handler() {
    local action="$1"
    shift
    case "$action" in
        create)  backup_create "$@" ;;
        db-only|db) backup_db_only "$@" ;;
        restore) backup_restore "$@" ;;
        list)    backup_list ;;
        cloud)   backup_cloud_setup ;;
        repo)      backup_repo "$@" ;;
        run)       backup_run "$@" ;;
        snapshots) backup_snapshots "$@" ;;
        pull)      backup_pull "$@" ;;
        auto)      backup_auto "$@" ;;
        forget)    backup_forget ;;
        check)     backup_check "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown backup action: $action"
            fi
            backup_menu
            ;;
    esac
}

backup_menu() {
    echo ""
    print_subheader "Backup & Restore"
    echo ""

    local options=(
        "Backup Domain (Source + Database)"
        "Backup Database Only"
        "Restore Domain"
        "Restore Database"
        "List Backups"
        "Cloud Backup Setup (rclone)"
        "Scheduled Backup Settings"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") backup_create ;;
            "${options[1]}") backup_db_only ;;
            "${options[2]}") backup_restore ;;
            "${options[3]}") backup_restore_db ;;
            "${options[4]}") backup_list ;;
            "${options[5]}") backup_cloud_setup ;;
            "${options[6]}") backup_schedule ;;
            *) return ;;
        esac
    done
}

backup_create() {
    local domain="${1:-}"

    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    load_config
    load_domain_config "$domain"

    local username=$(get_username "$domain")
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_dir="$DKVPS_BACKUP_DIR/source"
    local backup_file="${backup_dir}/${domain}_${timestamp}.tar.gz"

    print_info "Backing up $domain..."

    # Backup database
    if [[ -n "$db_name" ]]; then
        local db_file="/tmp/${db_name}_${timestamp}.sql.gz"
        MYSQL_PWD="$db_admin_password" mysqldump -u "$db_admin_user" --single-transaction "$db_name" | gzip > "$db_file" || { print_error "mysqldump failed"; return 1; }
        cp "$db_file" "/home/$username/$domain/public_html/.database.sql.gz"
    fi

    # Backup source + config
    mkdir -p "/home/$username/$domain/public_html/.backup"
    cp "$DKVPS_USER_DIR/.$domain.conf" "/home/$username/$domain/public_html/.backup/"
    cp "/etc/nginx/conf.d/$domain.conf" "/home/$username/$domain/public_html/.backup/" 2>/dev/null
    cp "$PHP_POOL_DIR/$domain.conf" "/home/$username/$domain/public_html/.backup/" 2>/dev/null

    # Create archive
    tar -czf "$backup_file" -C "/home/$username" "$domain"
    local rc=$?
    chmod 600 "$backup_file" 2>/dev/null

    # Cleanup temp files
    rm -rf "/home/$username/$domain/public_html/.backup"
    rm -f "/home/$username/$domain/public_html/.database.sql.gz"
    rm -f "/tmp/${db_name}_${timestamp}.sql.gz" 2>/dev/null

    if [[ $rc -ne 0 ]]; then print_error "tar failed ($rc)"; return 1; fi
    local size=$(du -sh "$backup_file" | cut -f1)
    print_success "Backup created: $backup_file ($size)"
}

backup_db_only() {
    local domain="${1:-}"

    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    load_config
    load_domain_config "$domain"

    if [[ -z "$db_name" ]]; then
        print_error "No database configured for $domain"
        return 1
    fi

    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="$DKVPS_BACKUP_DIR/db/${db_name}_${timestamp}.sql.gz"

    print_info "Backing up database $db_name..."
    set -o pipefail
    if ! MYSQL_PWD="$db_admin_password" mysqldump -u "$db_admin_user" --single-transaction "$db_name" | gzip > "$backup_file"; then
        rm -f "$backup_file"; set +o pipefail
        print_error "mysqldump failed"; return 1
    fi
    set +o pipefail
    chmod 600 "$backup_file"

    print_success "Database backup: $backup_file"
}

backup_restore() {
    echo ""
    print_subheader "Restore Domain"
    echo ""
    read -p "Enter backup file path: " backup_file

    if [[ ! -f "$backup_file" ]]; then
        print_error "Backup file not found: $backup_file"
        return 1
    fi

    print_warning "This will restore domain data from backup."
    if confirm "Continue?"; then
        print_info "Restoring from $backup_file..."
        local out; out=$(mktemp -d /root/dkvps-restore.XXXXXX)
        if tar -xzf "$backup_file" -C "$out"; then
            print_success "Backup extracted. Manual configuration may be needed."
            echo "  Extracted to: $out/$(ls "$out" | head -1)"
            print_info "For a full automatic restore use: dkvps backup pull / dkvps migrate import"
        else
            rm -rf "$out"; print_error "Could not extract $backup_file"; return 1
        fi
    fi
}

backup_restore_db() {
    load_config
    read -p "Database name: " db_name
    read -p "Backup file path (.sql or .sql.gz): " backup_file

    if [[ ! -f "$backup_file" ]]; then
        print_error "File not found."
        return 1
    fi

    local rc
    if [[ "$backup_file" == *.gz ]]; then
        set -o pipefail
        zcat "$backup_file" | MYSQL_PWD="$db_admin_password" mysql -u "$db_admin_user" "$db_name"; rc=$?
        set +o pipefail
    else
        MYSQL_PWD="$db_admin_password" mysql -u "$db_admin_user" "$db_name" < "$backup_file"; rc=$?
    fi
    if [[ $rc -eq 0 ]]; then print_success "Database $db_name restored."; else print_error "Restore failed."; return 1; fi
}

backup_list() {
    echo ""
    print_subheader "Available Backups"
    echo ""
    echo "Source backups:"
    ls -lh "$DKVPS_BACKUP_DIR/source/" 2>/dev/null || echo "  No backups found."
    echo ""
    echo "Database backups:"
    ls -lh "$DKVPS_BACKUP_DIR/db/" 2>/dev/null || echo "  No backups found."
}

backup_cloud_setup() {
    echo ""
    print_subheader "Cloud Backup Setup (rclone)"
    echo ""

    if ! command -v rclone &>/dev/null; then
        print_info "Installing rclone..."
        curl https://rclone.org/install.sh | bash
    fi

    print_info "Run 'rclone config' to set up cloud storage."
    print_info "Supported: Google Drive, S3, Backblaze, OneDrive, etc."
    echo ""
    rclone config
}

backup_schedule() {
    echo ""
    print_subheader "Scheduled Backup Settings"
    echo ""
    echo "Current cron backup schedules:"
    crontab -l 2>/dev/null | grep backup
    echo ""
    print_info "Edit crontab to modify backup schedules."
}
