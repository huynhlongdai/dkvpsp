#!/bin/bash
#
# DKVPS - Shared Functions Library
# Common utilities used across all modules
#

source "$(dirname "${BASH_SOURCE[0]}")/config.sh"
source "$(dirname "${BASH_SOURCE[0]}")/colors.sh"
source "$(dirname "${BASH_SOURCE[0]}")/platform.sh"

# ============================================================
# System Information
# ============================================================

get_public_ip() {
    curl -s https://api.ipify.org 2>/dev/null || \
    curl -s https://ifconfig.me 2>/dev/null || \
    hostname -I | awk '{print $1}'
}

get_os_name() {
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        echo "$ID"
    fi
}

get_os_version() {
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        echo "$VERSION_ID"
    fi
}

get_cpu_usage() {
    grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {printf "%.1f%%", usage}'
}

get_ram_total() {
    awk '/MemTotal/ {print $2}' /proc/meminfo
}

get_ram_available() {
    awk '/MemAvailable/ {print $2}' /proc/meminfo
}

get_swap_total() {
    awk '/SwapTotal/ {print $2}' /proc/meminfo
}

get_swap_free() {
    awk '/SwapFree/ {print $2}' /proc/meminfo
}

get_disk_info() {
    df -hP / | tail -1 | awk '{print $2 "|" $3 "|" $4 "|" $5}'
}

human_readable() {
    local -i bytes=$1
    if [[ $bytes -lt 1024 ]]; then
        echo "${bytes}B"
    elif [[ $bytes -lt 1048576 ]]; then
        echo "$(( (bytes + 1023)/1024 ))MB"
    else
        echo "$(( (bytes + 1048575)/1048576 ))GB"
    fi
}

# ============================================================
# Service Management
# ============================================================

service_status() {
    local service="$(svc_name "$1")"
    systemctl is-active "$service" 2>/dev/null || true
}

# unit installed on this server? (memcached is skipped on the Lite profile)
service_installed() {
    local u; u="$(svc_name "$1")"
    [[ -n "$(systemctl list-unit-files "$u.service" --no-legend 2>/dev/null)" ]]
}

service_restart() {
    local service="$(svc_name "$1")"
    if ! service_installed "$1"; then print_info "$service is not installed, skipped"; return 0; fi
    systemctl restart "$service" 2>/dev/null
    if [[ $? -eq 0 ]]; then
        print_success "$service restarted successfully"
    else
        print_error "Failed to restart $service"
    fi
}

service_start() {
    local service="$(svc_name "$1")"
    service_installed "$1" || { print_info "$service is not installed, skipped"; return 0; }
    systemctl start "$service" 2>/dev/null
    systemctl enable "$service" 2>/dev/null
}

service_stop() {
    local service="$(svc_name "$1")"
    service_installed "$1" || return 0
    systemctl stop "$service" 2>/dev/null
}

# ============================================================
# Domain Helpers
# ============================================================

# Generate username from domain (strip special chars, max 32 chars)
get_username() {
    local domain="$1"
    local u="${domain//[-._]/}"
    u="${u,,}"
    [[ "$u" =~ ^[a-z] ]] || u="u${u}"
    echo "$u" | cut -c1-32
}

# Check if domain exists in config
domain_exists() {
    local domain="$1"
    [[ -f "$DKVPS_USER_DIR/.$domain.conf" ]]
}

# List all domains
list_domains() {
    if [[ -d "$DKVPS_USER_DIR" ]] && [[ "$(ls -A "$DKVPS_USER_DIR" 2>/dev/null)" ]]; then
        local i=1
        for entry in $(ls -A "$DKVPS_USER_DIR"); do
            local domain=$(echo "$entry" | sed 's/^\.//' | sed 's/\.conf$//')
            if [[ "$domain" == *"."* ]]; then
                echo "$i) $domain"
                i=$((i + 1))
            fi
        done
        echo "---"
        echo "Total: $((i - 1))"
    else
        echo "No domains found."
    fi
}

# Interactive domain chooser
choose_domain() {
    local domains=()
    if [[ -d "$DKVPS_USER_DIR" ]] && [[ "$(ls -A "$DKVPS_USER_DIR" 2>/dev/null)" ]]; then
        for entry in $(ls -A "$DKVPS_USER_DIR"); do
            local d=$(echo "$entry" | sed 's/^\.//' | sed 's/\.conf$//')
            if [[ "$d" == *"."* ]]; then
                domains+=("$d")
            fi
        done
    fi

    if [[ ${#domains[@]} -eq 0 ]]; then
        print_warning "No domains found on this server."
        return 1
    fi

    echo ""
    local PS3=$'\n'"Select domain [0=Cancel]: "
    select domain in "${domains[@]}"; do
        if [[ -n "$domain" ]]; then
            SELECTED_DOMAIN="$domain"
            return 0
        else
            return 1
        fi
    done
}

# Check if domain is a subdomain
is_subdomain() {
    # true when the name has a label left of its registrable domain.
    # Two-level public suffixes (com.vn, web.id, co.uk...) count as one label.
    local domain="${1,,}" n
    local parts=(${domain//./ })
    n=${#parts[@]}
    if [[ $n -ge 3 ]] && _is_sld_suffix "${parts[n-2]}.${parts[n-1]}"; then
        [[ $n -ge 4 ]] && echo "yes" || echo "no"
    elif [[ $n -ge 3 ]]; then
        echo "yes"
    else
        echo "no"
    fi
}

_is_sld_suffix() {
    case "$1" in
        com.vn|net.vn|org.vn|edu.vn|gov.vn|biz.vn|info.vn|name.vn|pro.vn|health.vn|int.vn|ac.vn|id.vn|io.vn|\
        web.id|co.id|my.id|biz.id|or.id|ac.id|sch.id|\
        co.uk|org.uk|me.uk|ltd.uk|plc.uk|ac.uk|com.au|net.au|org.au|co.nz|co.jp|ne.jp|or.jp|co.kr|or.kr|\
        com.sg|com.my|com.ph|co.th|in.th|com.cn|com.hk|com.tw|co.in|com.br|com.mx|co.za|com.tr) return 0 ;;
    esac
    return 1
}

# Validate domain format
validate_domain() {
    local domain="$1"
    if [[ -z "$domain" ]]; then
        print_error "Domain cannot be empty."
        return 1
    fi
    if [[ ! "$domain" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$ ]]; then
        print_error "Invalid domain format: $domain"
        return 1
    fi
    if [[ "$domain" == www.* ]]; then
        print_error "Please enter root domain without www prefix."
        return 1
    fi
    return 0
}

# ============================================================
# Password Generation
# ============================================================

generate_password() {
    local length="${1:-32}"
    openssl rand -base64 48 | tr -dc 'a-zA-Z0-9' | head -c "$length"
}

generate_password_simple() {
    local length="${1:-24}"
    openssl rand -base64 48 | tr -dc 'a-z0-9' | head -c "$length"
}

# ============================================================
# Nginx Helpers
# ============================================================

restart_nginx() {
    if nginx -t 2>&1; then
        systemctl restart nginx.service
        print_success "Nginx restarted"
    else
        print_error "Nginx config error. Run: nginx -t"; return 1
    fi
}

reload_nginx() {
    nginx -t 2>&1
    if [[ $? -eq 0 ]]; then
        systemctl reload nginx.service
    else
        print_error "Nginx config error. Run: nginx -t"
    fi
}

restart_php() {
    # sites with cgroup limits run their own FPM master (dkvps-fpm@<domain>)
    # graceful reload (re-reads pools, no dropped requests, no start-limit hits
    # when many sites change in a row); a real restart only if it is down
    systemctl list-units --plain --no-legend 'dkvps-fpm@*' 2>/dev/null | awk '{print $1}' | xargs -r systemctl reload-or-restart 2>/dev/null
    systemctl reset-failed "$PHP_FPM_SERVICE" 2>/dev/null
    if systemctl reload-or-restart "$PHP_FPM_SERVICE"; then
        print_success "PHP-FPM reloaded"
    else
        print_error "PHP-FPM failed to restart ($PHP_FPM_SERVICE)"; return 1
    fi
}

# Find next available PHP-FPM port
find_available_fpm_port() {
    for (( n = $DKVPS_PHP_FPM_PORT_START; n <= $DKVPS_PHP_FPM_PORT_END; n++ )); do
        if ! grep -rnw "$PHP_POOL_DIR/" -e "$n" >> /dev/null 2>&1; then
            echo "$n"
            return 0
        fi
    done
    print_error "No available PHP-FPM ports (${DKVPS_PHP_FPM_PORT_START}-${DKVPS_PHP_FPM_PORT_END})"
    return 1
}

# ============================================================
# Firewall Helpers
# ============================================================

firewall_open_port() {
    local port="$1"
    local protocol="${2:-tcp}"
    fw_open "$port" "$protocol"
}

firewall_close_port() {
    local port="$1"
    local protocol="${2:-tcp}"
    fw_close "$port" "$protocol"
}

# ============================================================
# Validation Helpers
# ============================================================

require_root() {
    if [[ "$EUID" -ne 0 ]]; then
        print_error "This command requires root privileges."
        echo "Run: sudo dkvps"
        exit 1
    fi
}

check_services() {
    local nginx_status=$(service_status nginx)
    local php_status=$(service_status php-fpm)
    local mariadb_status=$(service_status mariadb)

    if [[ "$nginx_status" != "active" ]] || [[ "$php_status" != "active" ]] || [[ "$mariadb_status" != "active" ]]; then
        print_warning "Some services are not running:"
        echo "  Nginx:   $nginx_status"
        echo "  PHP-FPM: $php_status"
        echo "  MariaDB: $mariadb_status"
        return 1
    fi
    return 0
}

# ============================================================
# JSON Output (for Web UI API)
# ============================================================

json_status() {
    cat <<EOF
{
  "ip": "$(get_public_ip)",
  "cpu_usage": "$(get_cpu_usage)",
  "ram_total": $(get_ram_total),
  "ram_available": $(get_ram_available),
  "swap_total": $(get_swap_total),
  "swap_free": $(get_swap_free),
  "disk": "$(get_disk_info)",
  "services": {
    "nginx": "$(service_status nginx)",
    "php_fpm": "$(service_status php-fpm)",
    "mariadb": "$(service_status mariadb)",
    "redis": "$(service_status redis)",
    "memcached": "$(service_status memcached)",
    "fail2ban": "$(service_status fail2ban)"
  },
  "uptime": "$(uptime -p 2>/dev/null || uptime)",
  "os": "$(get_os_name) $(get_os_version)",
  "version": "$DKVPS_VERSION"
}
EOF
}

json_domains() {
    echo "["
    local first=true
    if [[ -d "$DKVPS_USER_DIR" ]]; then
        for entry in $(ls -A "$DKVPS_USER_DIR" 2>/dev/null); do
            local domain=$(echo "$entry" | sed 's/^\.//' | sed 's/\.conf$//')
            if [[ "$domain" == *"."* ]]; then
                source "$DKVPS_USER_DIR/$entry"
                if [[ "$first" != true ]]; then echo ","; fi
                cat <<EOF
  {
    "domain": "$domain",
    "username": "$username",
    "db_name": "${db_name:-}",
    "public_html": "/home/$username/$domain/public_html",
    "status": "${status:-active}",
    "php_version": "${php_version:-8.1}",
    "created_at": "${created_at:-}"
  }
EOF
                first=false
            fi
        done
    fi
    echo "]"
}

# Wait for Enter before the main menu clears the screen (no-op when not interactive)
pause_menu() {
    [[ -t 0 ]] || return 0
    echo ""
    read -rsp "  Press Enter to return to the menu..." _ </dev/tty
    echo ""
}
