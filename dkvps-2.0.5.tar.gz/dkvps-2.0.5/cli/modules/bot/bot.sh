#!/bin/bash
#
# DKVPS - Telegram admin bot
#
#   dkvps bot setup          token (hidden prompt) + auto-detect your chat id, then start
#   dkvps bot start|stop|status|uninstall
#   dkvps bot run            the long-poll loop (systemd unit dkvps-bot)
#
# Security model
#   - answers only the chat id(s) in /etc/dkvps/notify.conf (tg_chat, tg_admins)
#   - a fixed command list, never a shell; every argument is validated
#   - anything that changes the server asks for a button press, valid 2 minutes
#   - token never on a command line (curl config on stdin), conf is root 0600
# Cost: one bash loop + one curl waiting on Telegram (~5 MB), no open port.
#

DKVPS_BOT_STATE=/var/lib/dkvps/bot
DKVPS_BOT_PENDING=/run/dkvps-bot
TG_API="${DKVPS_TG_API:-https://api.telegram.org}"

_tg_conf() { grep -E "^$1=" "$DKVPS_NOTIFY_CONF" 2>/dev/null | cut -d= -f2-; }

# tg <method> [curl args...]  -> JSON on stdout
tg() {
    local m="$1"; shift
    printf 'url = "%s/bot%s/%s"\n' "$TG_API" "$(_tg_conf tg_token)" "$m" | curl -s --max-time "${TG_TIMEOUT:-15}" -K - "$@"
}

_html() { sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
_nocolor() { sed -e 's/\x1b\[[0-9;]*m//g'; }

tg_send() {   # chat text [reply_markup_json]
    tg sendMessage --data-urlencode "chat_id=$1" --data-urlencode "text=$2" \
        --data-urlencode "parse_mode=HTML" --data-urlencode "disable_web_page_preview=true" \
        ${3:+--data-urlencode "reply_markup=$3"} >/dev/null
}
tg_pre() { tg_send "$1" "${2:+<b>$2</b>
}<pre>$(cat | _nocolor | head -c 3500 | _html)</pre>"; }

_bot_allowed() {
    local id="$1" a
    [[ -n "$id" && "$id" == "$(_tg_conf tg_chat)" ]] && return 0
    for a in $(_tg_conf tg_admins | tr ',' ' '); do [[ "$id" == "$a" ]] && return 0; done
    return 1
}

# ------------------------------------------------------------------
# read-only commands
# ------------------------------------------------------------------
_bot_status() {
    local s out
    out="$(hostname)  up $(uptime -p | sed 's/^up //')
load $(cut -d' ' -f1-3 /proc/loadavg)   cpu $(nproc)
$(free -m | awk '/Mem:/{printf "RAM  %d/%d MB (free %d)\n",$3,$2,$7} /Swap:/{printf "Swap %d/%d MB\n",$3,$2}')
$(df -h / | awk 'NR==2{print "Disk "$3"/"$2" ("$5")"}')
"
    for s in nginx "${PHP_FPM_SERVICE:-php-fpm}" mariadb redis-server fail2ban; do
        systemctl list-unit-files "$s.service" >/dev/null 2>&1 || continue
        out+="$(printf '%-16s %s' "$s" "$(systemctl is-active "$s" 2>/dev/null)")
"
    done
    echo "$out"
}

_bot_sites() {
    local d code days
    for d in $(list_domain_configs); do
        code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 -H "Host: $d" http://127.0.0.1/)
        days=$(_ssl_cert_days "$(_ssl_crt "$d")" 2>/dev/null)
        printf '%-26s %s  %s\n' "$d" "$code" "${days:+ssl ${days}d}"
    done
}

_bot_top() { ps -eo rss,comm --sort=-rss | awk 'NR>1 && NR<=9 {printf "%6d MB  %s\n",$1/1024,$2}'; }

# ------------------------------------------------------------------
# actions (need a button press)
# ------------------------------------------------------------------
_bot_validate() {   # action args -> 0 if allowed
    local a="$1" x="${2:-}"
    case "$a" in
        restart) [[ "$x" =~ ^(nginx|php|mariadb|redis)$ ]] ;;
        purge|renew) [[ -n "$x" ]] && validate_domain "$x" >/dev/null 2>&1 && domain_exists "$x" ;;
        backupnow) [[ -z "$x" ]] ;;
        deploy) [[ -n "$x" ]] && validate_domain "$x" >/dev/null 2>&1 && [[ "$(site_get "$x" app)" =~ ^(node|bun|python|static)$ ]] ;;
        attack|calm) [[ -n "$x" ]] && validate_domain "$x" >/dev/null 2>&1 && domain_exists "$x" ;;
        rollback) [[ -n "$x" ]] && validate_domain "$x" >/dev/null 2>&1 && [[ "$(site_get "$x" app)" =~ ^(node|bun|python|static)$ ]] ;;
        ban|unban) [[ "$x" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}(/([12]?[0-9]|3[0-2]))?$ ]] ;;
        *) return 1 ;;
    esac
}

_bot_do() {
    local a="$1" x="${2:-}"
    case "$a" in
        restart)
            case "$x" in
                nginx) nginx -t 2>&1 | tail -1 && systemctl restart nginx && echo "nginx restarted" ;;
                php) restart_php 2>&1 | tail -2 ;;
                mariadb) systemctl restart mariadb && echo "mariadb restarted" ;;
                redis) systemctl restart redis-server 2>/dev/null || systemctl restart redis; echo "redis restarted" ;;
            esac ;;
        purge) site_cache_purge "$x" && echo "cache of $x purged" ;;
        deploy) timeout 900 /usr/bin/dkvps app deploy "$x" 2>&1 | tail -6 ;;
        rollback) /usr/bin/dkvps app rollback "$x" 2>&1 | tail -3 ;;
        attack) /usr/bin/dkvps cf attack "$x" on 2>&1 | tail -2 ;;
        calm) /usr/bin/dkvps cf attack "$x" off 2>&1 | tail -2 ;;
        renew) /usr/bin/dkvps ssl renew "$x" 2>&1 | tail -3 ;;
        backupnow)
            ( /usr/bin/dkvps backup run --all >>/var/log/dkvps-backup.log 2>&1 \
                && notify_send ok "Backup finished" || notify_send crit "Backup FAILED, see /var/log/dkvps-backup.log" ) &
            echo "backup started, you will get a message when it ends" ;;
        ban)
            if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then ufw insert 1 deny from "$x" 2>&1
            else iptables -I INPUT -s "$x" -j DROP && echo "dropped $x (iptables)"; fi ;;
        unban)
            if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then ufw delete deny from "$x" 2>&1
            else iptables -D INPUT -s "$x" -j DROP 2>&1 && echo "removed $x"; fi
            command -v fail2ban-client >/dev/null && fail2ban-client unban "$x" >/dev/null 2>&1; true ;;
    esac
}

_bot_ask() {   # chat action arg
    local chat="$1" a="$2" x="${3:-}" n
    n=$(head -c 9 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 12)
    mkdir -p "$DKVPS_BOT_PENDING"; chmod 0700 "$DKVPS_BOT_PENDING"
    printf '%s\n%s\n%s\n%s\n' "$chat" "$a" "$x" "$(date +%s)" > "$DKVPS_BOT_PENDING/$n"
    tg_send "$chat" "Xác nhận: <b>/$a ${x}</b> trên $(hostname)?" \
        "{\"inline_keyboard\":[[{\"text\":\"✅ Làm\",\"callback_data\":\"ok:$n\"},{\"text\":\"❌ Hủy\",\"callback_data\":\"no:$n\"}]]}"
}

_bot_callback() {   # callback_id chat message_id data
    local cid="$1" chat="$2" mid="$3" data="$4"
    local verb="${data%%:*}" n="${data#*:}" f
    [[ "$n" =~ ^[A-Za-z0-9]{6,16}$ ]] || return
    f="$DKVPS_BOT_PENDING/$n"
    tg answerCallbackQuery --data-urlencode "callback_query_id=$cid" >/dev/null
    if [[ ! -f "$f" ]]; then tg_send "$chat" "Yêu cầu này đã hết hạn hoặc đã xử lý."; return; fi
    local pchat pa px pt; { read -r pchat; read -r pa; read -r px; read -r pt; } < "$f"; rm -f "$f"
    [[ "$pchat" == "$chat" ]] || return
    if (( $(date +%s) - pt > 120 )); then tg_send "$chat" "Hết hạn 2 phút, gửi lại lệnh nhé."; return; fi
    if [[ "$verb" != "ok" ]]; then
        tg editMessageText --data-urlencode "chat_id=$chat" --data-urlencode "message_id=$mid" --data-urlencode "text=Đã hủy /$pa $px" >/dev/null; return
    fi
    _bot_validate "$pa" "$px" || return
    tg editMessageText --data-urlencode "chat_id=$chat" --data-urlencode "message_id=$mid" --data-urlencode "text=Đang chạy /$pa $px ..." >/dev/null
    logger -t dkvps-bot "action /$pa $px by chat $chat"
    _bot_do "$pa" "$px" 2>&1 | tg_pre "$chat" "/$pa $px"
}

_bot_help() {
    cat <<'EOF'
<b>DKVPS bot</b>
/status – CPU, RAM, disk, dịch vụ
/sites – mã HTTP + ngày SSL còn lại của từng site
/ssl – danh sách chứng chỉ
/backup – nhật ký backup gần nhất
/alerts – cảnh báo gần đây
/top – tiến trình tốn RAM nhất
/apps – app Node/Python/static

<b>Cần bấm xác nhận</b>
/restart nginx|php|mariadb|redis
/purge &lt;domain&gt; – xóa cache trang
/renew &lt;domain&gt; – gia hạn SSL
/backupnow – backup ngay
/ban &lt;ip&gt; · /unban &lt;ip&gt;
/deploy &lt;app&gt; · /rollback &lt;app&gt; – app vibe code
/attack &lt;domain&gt; · /calm &lt;domain&gt; – Cloudflare Under Attack
EOF
}

_bot_message() {   # chat text
    local chat="$1" text="$2"
    local cmd args; cmd=$(awk '{print $1}' <<<"$text" | sed 's/@.*//' | tr 'A-Z' 'a-z'); args=$(awk '{print $2}' <<<"$text")
    case "$cmd" in
        /start|/help) tg_send "$chat" "$(_bot_help)" ;;
        /status) _bot_status | tg_pre "$chat" "Trạng thái" ;;
        /sites)  _bot_sites | tg_pre "$chat" "Sites" ;;
        /ssl)    ssl_list | tg_pre "$chat" "SSL" ;;
        /backup) { tail -n 8 /var/log/dkvps-backup.log 2>/dev/null || echo "chưa có backup"; } | tg_pre "$chat" "Backup" ;;
        /alerts) { tail -n 10 "$DKVPS_ALERT_LOG" 2>/dev/null || echo "không có cảnh báo"; } | tg_pre "$chat" "Cảnh báo" ;;
        /top)    _bot_top | tg_pre "$chat" "RAM theo tiến trình" ;;
        /apps)   /usr/bin/dkvps app list 2>&1 | tg_pre "$chat" "Apps" ;;
        /restart|/purge|/renew|/backupnow|/ban|/unban|/deploy|/rollback|/attack|/calm)
            if _bot_validate "${cmd#/}" "$args"; then _bot_ask "$chat" "${cmd#/}" "$args"
            else tg_send "$chat" "Sai tham số. Gõ /help để xem cú pháp."; fi ;;
        *) tg_send "$chat" "Không hiểu lệnh. Gõ /help." ;;
    esac
}

bot_run() {
    [[ -n "$(_tg_conf tg_token)" && -n "$(_tg_conf tg_chat)" ]] || { echo "not configured: dkvps bot setup"; exit 1; }
    mkdir -p "$DKVPS_BOT_STATE"; chmod 0700 "$DKVPS_BOT_STATE"
    source "${CLI_DIR}/modules/ssl/ssl.sh"
    # update ids belong to one bot: a new token (another bot) starts from 0
    local bid; bid=$(_tg_conf tg_token); bid="${bid%%:*}"; bid="${bid//[^0-9]/}"
    local offf="$DKVPS_BOT_STATE/offset.${bid:-0}"
    local off; off=$(cat "$offf" 2>/dev/null); off=${off:-0}
    while true; do
        local resp
        resp=$(TG_TIMEOUT=65 tg getUpdates --data-urlencode "timeout=50" --data-urlencode "offset=$off" \
                --data-urlencode 'allowed_updates=["message","callback_query"]')
        if [[ "$(jq -r '.ok' <<<"$resp" 2>/dev/null)" != "true" ]]; then sleep 10; continue; fi
        local u
        while IFS= read -r u; do
            [[ -z "$u" ]] && continue
            off=$(( $(jq -r '.update_id' <<<"$u") + 1 )); echo "$off" > "$offf"
            if [[ "$(jq -r 'has("callback_query")' <<<"$u")" == "true" ]]; then
                local cid chat mid data from
                IFS=$'\t' read -r cid chat mid data from < <(jq -r '.callback_query | [.id, (.message.chat.id|tostring), (.message.message_id|tostring), .data, (.from.id|tostring)] | @tsv' <<<"$u")
                _bot_allowed "$chat" || { logger -t dkvps-bot "ignored callback from $from"; continue; }
                _bot_callback "$cid" "$chat" "$mid" "$data"
            else
                local chat text from
                IFS=$'\t' read -r chat from text < <(jq -r '.message | [(.chat.id|tostring), (.from.id|tostring), (.text // "" | gsub("[\t\n]"; " "))] | @tsv' <<<"$u")
                if ! _bot_allowed "$chat"; then logger -t dkvps-bot "ignored message from chat $chat"; continue; fi
                [[ "$text" == /* ]] && _bot_message "$chat" "$text"
            fi
        done < <(jq -c '.result[]' <<<"$resp")
    done
}

bot_setup() {
    local token="${1:-}"
    if [[ -z "$token" ]]; then
        echo "1) In Telegram open @BotFather, send /newbot, copy the token."
        read -rsp "Bot token: " token; echo
    fi
    [[ "$token" =~ ^[0-9]+:[A-Za-z0-9_-]+$ ]] || { print_error "That does not look like a bot token"; return 1; }
    mkdir -p /etc/dkvps
    (umask 077; printf 'tg_token=%s\n' "$token" > "$DKVPS_NOTIFY_CONF.new")
    local me; me=$(DKVPS_NOTIFY_CONF="$DKVPS_NOTIFY_CONF.new" bash -c "$(declare -f tg _tg_conf); TG_API='$TG_API'; tg getMe" | jq -r '.result.username // empty')
    [[ -n "$me" ]] || { rm -f "$DKVPS_NOTIFY_CONF.new"; print_error "Telegram rejected the token"; return 1; }
    echo "2) Open t.me/$me and send /start (waiting 120 s)..."
    local chat="" i resp
    for i in $(seq 1 12); do
        resp=$(DKVPS_NOTIFY_CONF="$DKVPS_NOTIFY_CONF.new" bash -c "$(declare -f tg _tg_conf); TG_API='$TG_API'; TG_TIMEOUT=15 tg getUpdates --data-urlencode timeout=10")
        chat=$(jq -r '[.result[] | select(.message.text != null and (.message.text|startswith("/start"))) | .message.chat.id][-1] // empty' <<<"$resp")
        [[ -n "$chat" ]] && break
    done
    [[ -n "$chat" ]] || { rm -f "$DKVPS_NOTIFY_CONF.new"; print_error "No /start received"; return 1; }
    printf 'tg_chat=%s\n' "$chat" >> "$DKVPS_NOTIFY_CONF.new"; mv "$DKVPS_NOTIFY_CONF.new" "$DKVPS_NOTIFY_CONF"
    bot_start
    tg_send "$chat" "✅ Đã kết nối $(hostname). Chỉ chat này điều khiển được server. Gõ /help."
    print_success "Bot @$me linked to chat $chat (alerts + admin)"
}

bot_start() {
    cat > /etc/systemd/system/dkvps-bot.service <<EOF
[Unit]
Description=DKVPS Telegram admin bot
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/bin/dkvps bot run
Restart=always
RestartSec=10
Nice=10
MemoryMax=64M
OOMScoreAdjust=500

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload; systemctl enable --now dkvps-bot >/dev/null 2>&1
    systemctl is-active --quiet dkvps-bot && print_success "Bot running"
}

bot_handler() {
    local action="${1:-status}"; shift 2>/dev/null
    case "$action" in
        setup) bot_setup "$@" ;;
        start) bot_start ;;
        stop) systemctl disable --now dkvps-bot >/dev/null 2>&1; print_success "Bot stopped (alerts still sent)" ;;
        run) bot_run ;;
        uninstall) systemctl disable --now dkvps-bot >/dev/null 2>&1; rm -f /etc/systemd/system/dkvps-bot.service; systemctl daemon-reload; print_success "Bot removed" ;;
        status|*) systemctl is-active dkvps-bot 2>/dev/null; [[ -f "$DKVPS_NOTIFY_CONF" ]] && echo "chat: $(_tg_conf tg_chat)" ;;
    esac
}
