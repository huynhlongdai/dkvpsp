#!/bin/bash
#
# DKVPS - apps (vibe-code projects): node, bun, python, static
#
#   dkvps app create <domain> --type node|bun|python|static [--repo <git url>] [--branch main]
#                    [--start "<cmd>"] [--build "<cmd>"] [--dir <static output dir>]
#                    [--ram 256M] [--cpu 50%] [--health /path] [--node lts|24|22]
#   dkvps app node <domain> <lts|major>    switch Node.js version (official build in /opt/dkvps/node)
#   dkvps app deploy <domain> [--ref <branch|tag|sha>]   git pull -> install -> build -> switch -> health check, auto rollback
#   dkvps app upload <domain> <dir|.tar.gz|.zip>         deploy without git (files from SFTP/AI tool)
#   dkvps app rollback <domain>     previous release
#   dkvps app env <domain> [set K=V ...|unset K|list]
#   dkvps app start|stop|restart|status|logs <domain>
#   dkvps app persist <domain> [add|del <path>|list]   files/dirs kept across releases (sqlite db, uploads)
#   dkvps app list
#
# Layout  /home/<user>/<domain>/app/{releases/<ts>,current -> releases/<ts>,shared/.env,repo}
# Process systemd unit dkvps-app-<domain> as the site user, own cgroup (MemoryMax/CPUQuota),
#         read-only system, writes only to its app + logs dirs; nginx proxies to 127.0.0.1:<port>.
# Static  no process at all: nginx serves current/<dir> with SPA fallback.
#

APP_PORT_BASE=3100

app_handler() {
    local action="${1:-list}"; shift 2>/dev/null
    case "$action" in
        create|add) app_create "$@" ;;
        deploy)     app_deploy "$@" ;;
        upload)     app_upload "$@" ;;
        rollback)   app_rollback "$@" ;;
        env)        app_env "$@" ;;
        start|stop|restart) [[ -n "${1:-}" ]] && systemctl "$action" "dkvps-app-$1" && print_success "$action $1" ;;
        status)     app_status "$@" ;;
        logs)       journalctl -u "dkvps-app-$1" -n "${2:-80}" --no-pager ;;
        list|ls)    app_list ;;
        persist)    app_persist "$@" ;;
        node)       app_node "$@" ;;
        *) sed -n '3,15p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; return 1 ;;
    esac
}

_app_conf()  { echo "$DKVPS_USER_DIR/.$1.conf"; }
_app_get()   { site_get "$1" "$2"; }
_app_set()   { set_config "$2" "$3" "$(_app_conf "$1")"; }
_app_base()  { echo "/home/$(get_username "$1")/$1/app"; }
_app_is()    { [[ "$(_app_get "$1" app)" =~ ^(node|bun|python|static)$ ]]; }
_as_user()   { local u="$1"; shift; sudo -u "$u" -H env HOME="/home/$u/${APP_DOMAIN}/tmp" PATH="${APP_NODE_BIN:+$APP_NODE_BIN:}/usr/local/bin:/usr/bin:/bin" COREPACK_ENABLE_DOWNLOAD_PROMPT=0 CI=1 "$@"; }

# ---- Node.js versions: official tarballs (verified), one dir per major, shared by apps
APP_NODE_ROOT=/opt/dkvps/node
_app_node_install() {   # lts|<major> -> echo bin dir
    local want="${1:-lts}" arch idx ver
    case "$(uname -m)" in x86_64) arch=x64 ;; aarch64|arm64) arch=arm64 ;; *) print_error "Unsupported CPU for Node builds"; return 1 ;; esac
    if [[ "$want" =~ ^[0-9]+$ && -x "$APP_NODE_ROOT/$want/bin/node" ]]; then echo "$APP_NODE_ROOT/$want/bin"; return 0; fi
    idx=$(curl -fsSL --max-time 30 https://nodejs.org/dist/index.json) || { print_error "Cannot reach nodejs.org"; return 1; }
    if [[ "$want" == lts ]]; then ver=$(jq -r '[.[] | select(.lts != false)][0].version' <<<"$idx")
    else ver=$(jq -r --arg m "v$want." '[.[] | select(.version | startswith($m))][0].version' <<<"$idx"); fi
    [[ "$ver" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]] || { print_error "Unknown Node.js version: $want"; return 1; }
    local major="${ver#v}"; major="${major%%.*}"
    if [[ ! -x "$APP_NODE_ROOT/$major/bin/node" || "$("$APP_NODE_ROOT/$major/bin/node" -v 2>/dev/null)" != "$ver" ]]; then
        local f="node-$ver-linux-$arch.tar.xz" tmp; tmp=$(mktemp -d)
        print_info "Installing Node.js $ver..." >&2
        if curl -fsSL --max-time 300 -o "$tmp/$f" "https://nodejs.org/dist/$ver/$f" \
           && curl -fsSL --max-time 30 -o "$tmp/SHASUMS256.txt" "https://nodejs.org/dist/$ver/SHASUMS256.txt" \
           && (cd "$tmp" && grep " $f\$" SHASUMS256.txt | sha256sum -c --quiet -); then
            mkdir -p "$APP_NODE_ROOT"; rm -rf "$APP_NODE_ROOT/$ver"
            mkdir -p "$APP_NODE_ROOT/$ver" && tar -xJf "$tmp/$f" --strip-components=1 -C "$APP_NODE_ROOT/$ver" --no-same-owner
            ln -sfn "$APP_NODE_ROOT/$ver" "$APP_NODE_ROOT/$major"
            # keep only the newest patch of each major
            ls -1d "$APP_NODE_ROOT"/v"$major".* 2>/dev/null | grep -vx "$APP_NODE_ROOT/$ver" | xargs -r rm -rf
        else rm -rf "$tmp"; print_error "Node.js download or checksum failed"; return 1; fi
        rm -rf "$tmp"
    fi
    echo "$APP_NODE_ROOT/$major/bin"
}
_app_node_bin() {   # domain -> bin dir of its Node (empty = system node)
    local v; v=$(_app_get "$1" app_node); [[ -n "$v" ]] || return 0
    [[ -x "$APP_NODE_ROOT/$v/bin/node" ]] || _app_node_install "$v" >/dev/null || return 0
    echo "$APP_NODE_ROOT/$v/bin"
}
app_node() {
    local domain="$1" want="${2:-}"
    _app_is "$domain" || { print_error "$domain is not an app"; return 1; }
    [[ -n "$want" ]] || { echo "node: $(_app_get "$domain" app_node || true) ($("$(_app_node_bin "$domain")/node" -v 2>/dev/null || node -v))"; return 0; }
    [[ "$want" == lts || "$want" =~ ^[0-9]{2}$ ]] || { print_error "Usage: dkvps app node <domain> lts|24|22"; return 1; }
    local bin; bin=$(_app_node_install "$want") || return 1
    _app_set "$domain" app_node "$(basename "$(dirname "$bin")")"
    print_success "$domain uses Node.js $("$bin/node" -v); redeploying"
    if [[ -n "$(_app_get "$domain" app_repo)" ]]; then app_deploy "$domain"; else app_write_unit "$domain"; systemctl restart "dkvps-app-$domain" 2>/dev/null; fi
}

_app_free_port() {
    local p=$APP_PORT_BASE used
    used=$(grep -h '^app_port=' "$DKVPS_USER_DIR"/.*.conf 2>/dev/null | cut -d= -f2)
    while grep -qx "$p" <<<"$used" || ss -ltn "( sport = :$p )" 2>/dev/null | grep -q LISTEN; do p=$((p+1)); done
    echo "$p"
}

_app_runtime() {   # make sure the runtime exists (installed once, shared)
    case "$1" in
        node) return 0 ;;   # managed Node.js is installed per app (app_node)
        bun)  [[ -x /usr/local/bin/bun ]] && return 0
              print_info "Installing bun..."
              curl -fsSL https://bun.sh/install | BUN_INSTALL=/usr/local bash >/dev/null 2>&1
              [[ -x /usr/local/bin/bun ]] || { print_error "bun install failed"; return 1; } ;;
        python) python3 -c 'import ensurepip' 2>/dev/null && return 0
                print_info "Installing python3-venv..."
                if command -v apt-get >/dev/null; then
                    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3-venv >/dev/null 2>&1 \
                    || { apt-get update -qq >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3-venv >/dev/null 2>&1; }
                else dnf -y -q install python3 >/dev/null 2>&1; fi
                python3 -c 'import ensurepip' 2>/dev/null || { print_error "python3-venv missing"; return 1; } ;;
        static) return 0 ;;
    esac
}

# ------------------------------------------------------------------
# nginx body for app sites (server blocks + SSL come from site_write_vhost)
# ------------------------------------------------------------------
app_write_inc() {
    local domain="$1" username="$2"
    local root="/home/$username/$domain" type port dir
    type=$(_app_get "$domain" app); port=$(_app_get "$domain" app_port); dir=$(_app_get "$domain" app_dir)
    local common="access_log $root/logs/access.log;
error_log $root/logs/error.log warn;
include /etc/dkvps/nginx/headers.conf;
include $DKVPS_SITE_INC_DIR/$domain.custom;
location ^~ /.well-known/acme-challenge/ { root $root/public_html; default_type text/plain; try_files \$uri =404; }
location ~ /\.(?!well-known) { deny all; }"
    if [[ "$type" == "static" ]]; then
        cat > "$DKVPS_SITE_INC_DIR/$domain.inc" <<EOF
# DKVPS static app $domain (generated)
root $root/app/current/${dir:-.};
index index.html;
$common
location ~* \.(?:css|js|mjs|jpg|jpeg|gif|png|webp|avif|ico|svg|woff2?|ttf|wasm|map)\$ {
    expires 30d; access_log off;
    include /etc/dkvps/nginx/headers.conf;
    add_header Cache-Control "public";
    try_files \$uri =404;
}
location / { try_files \$uri \$uri/ \$uri.html /index.html; }
EOF
    else
        cat > "$DKVPS_SITE_INC_DIR/$domain.inc" <<EOF
# DKVPS $type app $domain (generated) -> 127.0.0.1:$port
$common
client_max_body_size 64m;
location / {
    proxy_pass http://127.0.0.1:$port;
    proxy_http_version 1.1;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection \$dkvps_conn_upgrade;
    proxy_read_timeout 300s;
    proxy_buffering on;
}
EOF
    fi
    [[ -f "$DKVPS_SITE_INC_DIR/$domain.custom" ]] || echo "# custom nginx rules for $domain (server context)" > "$DKVPS_SITE_INC_DIR/$domain.custom"
}

app_write_unit() {
    local domain="$1" username; username=$(get_username "$domain")
    local base; base=$(_app_base "$domain")
    local type port start ram cpu
    type=$(_app_get "$domain" app); port=$(_app_get "$domain" app_port)
    start=$(_app_get "$domain" app_start); ram=$(_app_get "$domain" app_ram); cpu=$(_app_get "$domain" app_cpu)
    local nodebin; nodebin=$(_app_node_bin "$domain")
    [[ "$type" == "static" ]] && { rm -f "/etc/systemd/system/dkvps-app-$domain.service"; return 0; }
    cat > "/etc/systemd/system/dkvps-app-$domain.service" <<EOF
# DKVPS app $domain ($type) - generated by dkvps app
[Unit]
Description=DKVPS app $domain
After=network.target

[Service]
User=$username
Group=$username
WorkingDirectory=$base/current
Environment=PORT=$port HOST=127.0.0.1 NODE_ENV=production PYTHONUNBUFFERED=1
Environment=PATH=$base/current/node_modules/.bin:$base/current/.venv/bin:${nodebin:+$nodebin:}/usr/local/bin:/usr/bin:/bin
Environment=HOME=$base/home
EnvironmentFile=-$base/shared/.env
ExecStart=/bin/sh -c 'exec $start'
Restart=always
RestartSec=3
MemoryMax=${ram:-256M}
MemoryHigh=$(( $(numfmt --from=iec "${ram:-256M}") * 85 / 100 ))
CPUQuota=${cpu:-100%}
TasksMax=128
Nice=5
OOMScoreAdjust=300
NoNewPrivileges=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectSystem=strict
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictSUIDSGID=yes
LockPersonality=yes
ReadWritePaths=$base /home/$username/$domain/logs
StandardOutput=append:/home/$username/$domain/logs/app.log
StandardError=append:/home/$username/$domain/logs/app.log

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
}

_app_default_start() {   # type release_dir
    local t="$1" d="$2"
    case "$t" in
        node)
            if [[ -f "$d/package.json" ]] && jq -e '.scripts.start' "$d/package.json" >/dev/null 2>&1; then
                # "node x.js" runs without npm staying resident (~50 MB saved)
                # the unit PATH has node_modules/.bin, so "next start", "node x.js" run without npm
                local s; s=$(jq -r '.scripts.start' "$d/package.json")
                if [[ "$s" =~ ^[A-Za-z0-9_./@:=\ -]+$ && ! "$s" =~ (^|\ )(npm|npx|yarn|pnpm|bun|cd)(\ |$) ]]; then echo "$s"
                else echo "npm start"; fi
            else local f; for f in server.js index.js app.js main.js dist/index.js build/index.js; do [[ -f "$d/$f" ]] && { echo "node $f"; return; }; done; echo "node index.js"; fi ;;
        bun)
            if [[ -f "$d/package.json" ]] && jq -e '.scripts.start' "$d/package.json" >/dev/null 2>&1; then echo "bun run start"
            else local f; for f in index.ts server.ts src/index.ts index.js; do [[ -f "$d/$f" ]] && { echo "bun $f"; return; }; done; echo "bun index.ts"; fi ;;
        python)
            if grep -qi '^fastapi\|^uvicorn' "$d/requirements.txt" 2>/dev/null; then
                local m=main; [[ -f "$d/app.py" && ! -f "$d/main.py" ]] && m=app; echo "uvicorn $m:app --host 127.0.0.1 --port \$PORT"
            elif grep -qi '^gunicorn' "$d/requirements.txt" 2>/dev/null; then
                local m=app; [[ -f "$d/wsgi.py" ]] && m=wsgi; echo "gunicorn -w 2 -b 127.0.0.1:\$PORT $m:app"
            else echo "python app.py"; fi ;;
    esac
}

# ------------------------------------------------------------------
# create
# ------------------------------------------------------------------
app_create() {
    declare -F license_require >/dev/null || source "${CLI_DIR}/modules/license/license.sh"
    license_require "Apps (Node/Bun/Python)" || return 1
    local domain="" type="" repo="" branch="main" start="" build="" dir="" ram="" cpu="" health="/" nodev="lts"
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --type) type="$2"; shift ;; --repo) repo="$2"; shift ;; --branch) branch="$2"; shift ;;
            --start) start="$2"; shift ;; --build) build="$2"; shift ;; --dir) dir="$2"; shift ;;
            --ram) ram="$2"; shift ;; --cpu) cpu="$2"; shift ;; --health) health="$2"; shift ;; --node) nodev="$2"; shift ;;
            -*) print_error "Unknown option $1"; return 1 ;;
            *) domain="$1" ;;
        esac; shift
    done
    [[ -n "$domain" && "$type" =~ ^(node|bun|python|static)$ ]] || { print_error "Usage: dkvps app create <domain> --type node|bun|python|static [--repo url]"; return 1; }
    [[ -z "$ram" || "$ram" =~ ^[0-9]+[MG]$ ]] || { print_error "--ram like 256M or 1G"; return 1; }
    [[ -z "$cpu" || "$cpu" =~ ^[0-9]+%$ ]] || { print_error "--cpu like 50%"; return 1; }
    [[ -z "$repo" || "$repo" =~ ^(https://|git@|ssh://|file:///|/)[A-Za-z0-9._@:/~+-]+$ ]] || { print_error "Bad repo URL"; return 1; }
    [[ "$branch" =~ ^[A-Za-z0-9._/-]+$ && "$health" =~ ^/[A-Za-z0-9._/?=-]*$ ]] || { print_error "Bad branch or health path"; return 1; }
    [[ -z "$dir" || "$dir" =~ ^[A-Za-z0-9._/-]+$ && "$dir" != *..* ]] || { print_error "Bad --dir"; return 1; }
    _app_runtime "$type" || return 1

    if ! domain_exists "$domain"; then
        declare -F domain_add >/dev/null || source "${CLI_DIR}/modules/domain/domain.sh"
        DKVPS_ASSUME_YES=1 domain_add "$domain" --no-app >/dev/null || { print_error "Could not create site $domain"; return 1; }
    fi
    local username; username=$(get_username "$domain")
    local base; base=$(_app_base "$domain")
    mkdir -p "$base"/{releases,shared,home}
    touch "$base/shared/.env"; chmod 0600 "$base/shared/.env"
    chown -R "$username:$username" "$base"; chmod 0750 "$base"

    _app_set "$domain" app "$type"
    _app_set "$domain" fcgi_cache 0
    [[ "$type" != "static" ]] && { [[ -n "$(_app_get "$domain" app_port)" ]] || _app_set "$domain" app_port "$(_app_free_port)"; }
    _app_set "$domain" app_repo "$repo"; _app_set "$domain" app_branch "$branch"
    _app_set "$domain" app_start "$start"; _app_set "$domain" app_start_auto "$([[ -n $start ]] && echo 0 || echo 1)"; _app_set "$domain" app_build "$build"; _app_set "$domain" app_dir "$dir"
    if [[ "$type" == node || "$type" == static ]] && [[ "$nodev" != system ]]; then
        local nb; nb=$(_app_node_install "$nodev") && _app_set "$domain" app_node "$(basename "$(dirname "$nb")")"
    fi
    _app_set "$domain" app_ram "${ram:-256M}"; _app_set "$domain" app_cpu "${cpu:-100%}"; _app_set "$domain" app_health "$health"

    # PHP pool is useless for an app site
    rm -f "$PHP_POOL_DIR/$domain.conf"; restart_php >/dev/null 2>&1
    print_success "App $domain ($type) created${repo:+, deploying from $repo}"
    if [[ -n "$repo" ]]; then app_deploy "$domain"
    else print_info "Next: dkvps app upload $domain <dir|archive>   or set a repo: dkvps app create $domain --type $type --repo <url>"; fi
}

# ------------------------------------------------------------------
# deploy = new release dir -> install -> build -> switch -> health -> keep or roll back
# ------------------------------------------------------------------
_app_release_new() { local base="$1"; echo "$base/releases/$(date +%Y%m%d-%H%M%S)"; }

_app_build_release() {   # domain release_dir
    local domain="$1" rel="$2" username; username=$(get_username "$domain")
    local type build base; type=$(_app_get "$domain" app); build=$(_app_get "$domain" app_build); base=$(_app_base "$domain")
    APP_DOMAIN="$domain"; APP_NODE_BIN=$(_app_node_bin "$domain")
    # .env for runtime and for build-time vars (VITE_*, NEXT_PUBLIC_*); dotfiles are never served
    [[ -e "$rel/.env" && ! -L "$rel/.env" ]] && mv -f "$rel/.env" "$rel/.env.repo"
    ln -sfn "$base/shared/.env" "$rel/.env" 2>/dev/null
    chown -R "$username:$username" "$rel"
    local run=(nice -n 15 ionice -c3)
    (
        cd "$rel" || exit 1
        set -o pipefail
        case "$type" in
            node|static)
                if [[ -f package.json ]]; then
                    local pm; pm=$(_app_pm .)
                    local cp=(corepack)   # Node 25+ ships without corepack
                    [[ -x "${APP_NODE_BIN:-/nonexistent}/corepack" ]] || { [[ -z "${APP_NODE_BIN:-}" ]] && command -v corepack >/dev/null; } || cp=(npx -y)
                    echo "== install ($pm)"
                    _deps() {
                    case "$pm" in
                        pnpm) _as_user "$username" "${run[@]}" "${cp[@]}" pnpm install --frozen-lockfile \
                              || _as_user "$username" "${run[@]}" "${cp[@]}" pnpm install ;;
                        yarn) _as_user "$username" "${run[@]}" "${cp[@]}" yarn install --frozen-lockfile \
                              || _as_user "$username" "${run[@]}" "${cp[@]}" yarn install ;;
                        bun)  _as_user "$username" "${run[@]}" /usr/local/bin/bun install ;;
                        npm-ci)  # AI tools often commit a lockfile that is out of sync
                              _as_user "$username" "${run[@]}" npm ci --no-audit --no-fund \
                              || { echo "npm ci failed, retrying with npm install"; rm -rf node_modules
                                   _as_user "$username" "${run[@]}" npm install --no-audit --no-fund; } ;;
                        *)    _as_user "$username" "${run[@]}" npm install --no-audit --no-fund ;;
                    esac
                    }
                    local tl; tl=$(mktemp)
                    if ! _deps >"$tl" 2>&1; then
                        cat "$tl"
                        # native modules (better-sqlite3, bcrypt, sharp...) without a prebuilt binary
                        if grep -qE 'node-gyp|gyp ERR|make: not found|not found: make|g\+\+' "$tl" && ! command -v g++ >/dev/null; then
                            echo "== native module needs a compiler: installing build tools, retrying"
                            _app_build_tools || exit 1
                            rm -rf node_modules; _deps || exit 1
                        else rm -f "$tl"; exit 1; fi
                    else cat "$tl"; fi
                    rm -f "$tl"
                    if [[ -z "$build" ]] && jq -e '.scripts.build' package.json >/dev/null 2>&1; then
                        case "$pm" in pnpm) build="${cp[*]} pnpm run build" ;; yarn) build="${cp[*]} yarn build" ;;
                                      bun) build="/usr/local/bin/bun run build" ;; *) build="npm run build" ;; esac
                    fi
                fi ;;
            bun) _as_user "$username" "${run[@]}" /usr/local/bin/bun install || exit 1
                 [[ -z "$build" ]] && jq -e '.scripts.build' package.json >/dev/null 2>&1 && build="bun run build" ;;
            python)
                _as_user "$username" python3 -m venv .venv || exit 1
                if [[ -f requirements.txt ]]; then _as_user "$username" "${run[@]}" .venv/bin/pip install -q -r requirements.txt || exit 1; fi ;;
        esac
        if [[ -n "$build" ]]; then
            _as_user "$username" env PATH="$rel/node_modules/.bin:$rel/.venv/bin:${APP_NODE_BIN:+$APP_NODE_BIN:}/usr/local/bin:/usr/bin:/bin" NODE_ENV=production "${run[@]}" sh -c "$build" || exit 1
        fi
    ) >> "/home/$username/$domain/logs/deploy.log" 2>&1
}

_app_detect_static_dir() {
    local rel="$1" d
    for d in dist build out public _site .output/public; do [[ -f "$rel/$d/index.html" ]] && { echo "$d"; return; }; done
    [[ -f "$rel/index.html" ]] && echo "."
}

_app_health() {   # domain -> 0 when it answers (any status < 500)
    local domain="$1" type port path code i
    type=$(_app_get "$domain" app); port=$(_app_get "$domain" app_port); path=$(_app_get "$domain" app_health)
    for i in $(seq 1 30); do
        if [[ "$type" == "static" ]]; then
            code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 -H "Host: $domain" "http://127.0.0.1${path:-/}")
        else
            code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "http://127.0.0.1:$port${path:-/}")
        fi
        [[ "$code" =~ ^[1-4][0-9][0-9]$ ]] && return 0
        sleep 1
    done
    return 1
}

_app_activate() {   # domain release_dir  -> switch + restart + health, roll back on failure
    local domain="$1" rel="$2" username; username=$(get_username "$domain")
    local base type; base=$(_app_base "$domain"); type=$(_app_get "$domain" app)
    local prev; prev=$(readlink "$base/current" 2>/dev/null)

    if [[ "$type" == "static" && -z "$(_app_get "$domain" app_dir)" ]]; then
        local sd; sd=$(_app_detect_static_dir "$rel")
        [[ -n "$sd" ]] || { print_error "No index.html found (dist/, build/, out/ ...)"; return 1; }
        _app_set "$domain" app_dir "$sd"
    fi
    # start command: auto-detected ones follow package.json on every deploy,
    # one given with --start stays as given
    local cur_start; cur_start=$(_app_get "$domain" app_start)
    if [[ "$type" != "static" ]] && { local auto; auto=$(_app_get "$domain" app_start_auto)
          [[ -z "$cur_start" || "$auto" == "1" ]] || [[ -z "$auto" && "$cur_start" =~ ^(npm\ start|bun\ run\ start)$ ]]; }; then
        _app_set "$domain" app_start "$(_app_default_start "$type" "$rel")"
        _app_set "$domain" app_start_auto 1
    fi

    _app_persist_link "$domain" "$prev" "$rel"
    ln -sfn "$rel" "$base/current.new" && mv -Tf "$base/current.new" "$base/current"
    chown -h "$username:$username" "$base/current"
    load_domain_config "$domain"
    site_write_vhost "$domain" "$username" "$type" || return 1
    app_write_unit "$domain"
    if [[ "$type" != "static" ]]; then
        systemctl enable "dkvps-app-$domain" >/dev/null 2>&1
        systemctl restart "dkvps-app-$domain"
    fi
    reload_nginx >/dev/null 2>&1
    sleep 1   # let the reloaded nginx workers take over before probing

    if _app_health "$domain"; then
        _app_set "$domain" app_release "$(basename "$rel")"
        # keep the 3 newest releases
        ls -1dt "$base"/releases/*/ 2>/dev/null | tail -n +4 | grep -v "$(basename "$rel")" | xargs -r rm -rf
        return 0
    fi
    print_error "Health check failed for $domain (see: dkvps app logs $domain)"
    if [[ -n "$prev" && -d "$prev" ]]; then
        ln -sfn "$prev" "$base/current.new" && mv -Tf "$base/current.new" "$base/current"
        [[ "$type" != "static" ]] && systemctl restart "dkvps-app-$domain"
        _app_health "$domain" || true
        print_warning "Rolled back to $(basename "$prev")"
        notify_send warn "Deploy of $domain failed health check, rolled back to $(basename "$prev")"
    fi
    return 1
}

_app_build_tools() {   # once per server, only when a project needs to compile
    command -v g++ >/dev/null && command -v make >/dev/null && return 0
    if command -v apt-get >/dev/null; then
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends build-essential python3 >/dev/null 2>&1 \
        || { apt-get update -qq >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends build-essential python3 >/dev/null 2>&1; }
    else dnf -y -q install gcc-c++ make python3 >/dev/null 2>&1; fi
    command -v g++ >/dev/null
}

_app_pm() {   # package manager from the lockfile the project ships
    local d="$1"
    if   [[ -f "$d/package-lock.json" ]]; then echo npm-ci
    elif [[ -f "$d/pnpm-lock.yaml" ]]; then echo pnpm
    elif [[ -f "$d/yarn.lock" ]]; then echo yarn
    elif [[ -f "$d/bun.lockb" || -f "$d/bun.lock" ]] && _app_runtime bun >/dev/null 2>&1; then echo bun
    else echo npm; fi
}

# runtime data must survive a new release: sqlite files, uploads, storage dirs
APP_PERSIST_DEFAULT="data .data uploads storage data.db database.db db.sqlite db.sqlite3 database.sqlite sqlite.db app.db dev.db prisma/dev.db instance"
_app_persist_list() { local l; l=$(_app_get "$1" app_persist); echo "$APP_PERSIST_DEFAULT ${l//,/ }"; }
_app_persist_link() {   # domain prev_release new_release
    local domain="$1" prev="$2" rel="$3" username p sp; username=$(get_username "$domain")
    local sd; sd="$(_app_base "$domain")/shared/persist"
    [[ "$(_app_get "$domain" app)" == "static" ]] && return 0
    mkdir -p "$sd"; chown "$username:" "$sd"
    for p in $(_app_persist_list "$domain"); do
        sp="$sd/$p"
        # first time: adopt what the running release created
        if [[ ! -e "$sp" && -n "$prev" && -e "$prev/$p" && ! -L "$prev/$p" ]] && ! git -C "$prev" ls-files --error-unmatch "$p" >/dev/null 2>&1; then
            mkdir -p "$(dirname "$sp")"; cp -a "$prev/$p" "$sp"
        fi
        [[ -e "$sp" ]] || continue
        mkdir -p "$(dirname "$rel/$p")"; rm -rf "${rel:?}/$p"; ln -s "$sp" "$rel/$p"; chown -h "$username:" "$rel/$p"
    done
}

app_persist() {
    local domain="$1" op="${2:-list}" path="${3:-}"
    _app_is "$domain" || { print_error "$domain is not an app"; return 1; }
    case "$op" in
        list) echo "default: $APP_PERSIST_DEFAULT"; echo "extra:   $(_app_get "$domain" app_persist | tr , ' ')"
              ls -la "$(_app_base "$domain")/shared/persist" 2>/dev/null | tail -n +4 ;;
        add|del)
            [[ "$path" =~ ^[A-Za-z0-9_.-]+(/[A-Za-z0-9_.-]+)*$ && "$path" != *..* ]] || { print_error "Path relative to the app, like data/app.db or public/uploads"; return 1; }
            local cur; cur=$(_app_get "$domain" app_persist | tr , '\n' | grep -vx "$path" | grep -v '^$' | paste -sd, -)
            [[ "$op" == add ]] && cur="${cur:+$cur,}$path"
            _app_set "$domain" app_persist "$cur"; print_success "persist: ${cur:-<defaults only>} (applies on next deploy)" ;;
        *) print_error "Usage: dkvps app persist <domain> [add|del <path>|list]"; return 1 ;;
    esac
}

app_deploy() {
    local domain="" ref=""
    while [[ $# -gt 0 ]]; do case "$1" in --ref) ref="$2"; shift ;; *) domain="$1" ;; esac; shift; done
    _app_is "$domain" || { print_error "$domain is not an app (dkvps app create)"; return 1; }
    local repo branch username base; repo=$(_app_get "$domain" app_repo); branch=$(_app_get "$domain" app_branch)
    username=$(get_username "$domain"); base=$(_app_base "$domain"); APP_DOMAIN="$domain"
    [[ -n "$repo" ]] || { print_error "No repo set for $domain (use dkvps app upload)"; return 1; }
    ref="${ref:-$branch}"; [[ "$ref" =~ ^[A-Za-z0-9._/-]+$ ]] || { print_error "Bad ref"; return 1; }

    exec 9>"/run/dkvps-app-$domain.lock"; flock -n 9 || { print_error "A deploy of $domain is already running"; return 1; }
    print_info "Fetching $repo ($ref)..."
    if [[ ! -d "$base/repo/.git" ]]; then
        _as_user "$username" git clone -q --filter=blob:none "$repo" "$base/repo" >>"/home/$username/$domain/logs/deploy.log" 2>&1 \
            || { print_error "git clone failed (private repo? add a deploy key for user $username)"; return 1; }
    fi
    _as_user "$username" git -C "$base/repo" fetch -q --all --tags --prune >>"/home/$username/$domain/logs/deploy.log" 2>&1 || { print_error "git fetch failed"; return 1; }
    local sha; sha=$(_as_user "$username" git -C "$base/repo" rev-parse --verify -q "origin/$ref" || _as_user "$username" git -C "$base/repo" rev-parse --verify -q "$ref")
    [[ -n "$sha" ]] || { print_error "Ref $ref not found"; return 1; }

    local rel; rel=$(_app_release_new "$base"); mkdir -p "$rel"; chown "$username:$username" "$rel"
    _as_user "$username" sh -c "git -C '$base/repo' archive '$sha' | tar -x -C '$rel'" || { print_error "Checkout failed"; rm -rf "$rel"; return 1; }
    echo "$sha" > "$rel/.dkvps-commit"

    print_info "Installing and building ${sha:0:8} (low priority)..."
    local t0=$SECONDS
    if ! _app_build_release "$domain" "$rel"; then
        print_error "Build failed, site untouched. Last lines:"; tail -n 15 "/home/$username/$domain/logs/deploy.log"
        rm -rf "$rel"; notify_send warn "Build of $domain (${sha:0:8}) failed, live version untouched"; return 1
    fi
    _app_activate "$domain" "$rel" || { rm -rf "$rel"; return 1; }
    print_success "Deployed $domain ${sha:0:8} in $((SECONDS - t0))s"
}

app_upload() {
    local domain="$1" src="$2"
    _app_is "$domain" || { print_error "$domain is not an app"; return 1; }
    [[ -e "$src" ]] || { print_error "Usage: dkvps app upload <domain> <dir|.tar.gz|.zip>"; return 1; }
    local base username; base=$(_app_base "$domain"); username=$(get_username "$domain"); APP_DOMAIN="$domain"
    local rel; rel=$(_app_release_new "$base"); mkdir -p "$rel"
    case "$src" in
        *.tar.gz|*.tgz) tar -xzf "$src" -C "$rel" ;;
        *.zip) unzip -q "$src" -d "$rel" ;;
        *) [[ -d "$src" ]] && cp -a "$src/." "$rel/" ;;
    esac || { print_error "Could not unpack $src"; rm -rf "$rel"; return 1; }
    # an archive with a single top folder: use its content
    local entries; entries=$(ls -A "$rel")
    if [[ $(wc -l <<<"$entries") -eq 1 && -d "$rel/$entries" ]]; then mv "$rel/$entries"/{.,}* "$rel"/ 2>/dev/null; rmdir "$rel/$entries" 2>/dev/null; fi
    rm -rf "$rel/node_modules" "$rel/.venv" "$rel/.git"
    _app_build_release "$domain" "$rel" || { print_error "Build failed:"; tail -n 15 "/home/$username/$domain/logs/deploy.log"; rm -rf "$rel"; return 1; }
    _app_activate "$domain" "$rel" || { rm -rf "$rel"; return 1; }
    print_success "Deployed $domain from $(basename "$src")"
}

app_rollback() {
    local domain="$1"; _app_is "$domain" || { print_error "$domain is not an app"; return 1; }
    local base cur prev; base=$(_app_base "$domain"); cur=$(readlink -f "$base/current")
    prev=$(ls -1dt "$base"/releases/*/ | sed 's#/$##' | grep -vx "$cur" | head -1)
    [[ -n "$prev" ]] || { print_error "No previous release"; return 1; }
    _app_activate "$domain" "$prev" && print_success "Rolled back $domain to $(basename "$prev")"
}

app_env() {
    local domain="$1" op="${2:-list}"; shift 2 2>/dev/null
    _app_is "$domain" || { print_error "$domain is not an app"; return 1; }
    local f; f="$(_app_base "$domain")/shared/.env"
    case "$op" in
        list) sed -E 's/=(.{0,3}).*/=\1*** /' "$f" ;;
        set)  local kv k
              for kv in "$@"; do
                  k="${kv%%=*}"; [[ "$k" =~ ^[A-Za-z_][A-Za-z0-9_]*$ && "$kv" == *=* ]] || { print_error "Bad: $kv"; return 1; }
                  sed -i "/^$k=/d" "$f"; printf '%s\n' "$kv" >> "$f"
              done
              chmod 0600 "$f"; chown "$(get_username "$domain"):" "$f"
              if [[ "$(_app_get "$domain" app)" != "static" ]] && systemctl cat "dkvps-app-$domain" >/dev/null 2>&1; then
                  systemctl restart "dkvps-app-$domain"; print_success "Env updated, app restarted"
              else print_success "Env saved (applied on next deploy)"; fi ;;
        unset) local k; for k in "$@"; do sed -i "/^$k=/d" "$f"; done; systemctl cat "dkvps-app-$domain" >/dev/null 2>&1 && systemctl restart "dkvps-app-$domain"; print_success "Removed" ;;
        *) print_error "dkvps app env <domain> [list|set K=V ...|unset K ...]" ;;
    esac
}

app_status() {
    local domain="$1"; _app_is "$domain" || { print_error "$domain is not an app"; return 1; }
    local type; type=$(_app_get "$domain" app)
    echo "type:     $type"
    echo "release:  $(_app_get "$domain" app_release) ($(cat "$(_app_base "$domain")/current/.dkvps-commit" 2>/dev/null | cut -c1-8))"
    if [[ "$type" != "static" ]]; then
        echo "port:     $(_app_get "$domain" app_port)"
        echo "start:    $(_app_get "$domain" app_start)"
        echo "state:    $(systemctl is-active "dkvps-app-$domain")"
        local mem; mem=$(systemctl show "dkvps-app-$domain" -p MemoryCurrent --value)
        [[ "$mem" =~ ^[0-9]+$ ]] && echo "memory:   $((mem/1024/1024)) MB / $(_app_get "$domain" app_ram)"
    fi
}

app_list() {
    printf '%-28s %-7s %-6s %-9s %8s  %s\n' DOMAIN TYPE PORT STATE RAM RELEASE
    local d t mem st
    for d in $(list_domain_configs); do
        t=$(site_get "$d" app); [[ "$t" =~ ^(node|bun|python|static)$ ]] || continue
        if [[ "$t" == "static" ]]; then st="-"; mem="0 MB"
        else st=$(systemctl is-active "dkvps-app-$d" 2>/dev/null); mem=$(systemctl show "dkvps-app-$d" -p MemoryCurrent --value 2>/dev/null)
             [[ "$mem" =~ ^[0-9]+$ ]] && mem="$((mem/1024/1024)) MB" || mem="-"; fi
        printf '%-28s %-7s %-6s %-9s %8s  %s\n' "$d" "$t" "$(site_get "$d" app_port)" "$st" "$mem" "$(site_get "$d" app_release)"
    done
}
