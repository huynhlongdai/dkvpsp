#!/bin/bash
#
# DKVPS - Admin Panel Management Module
#

app_admin_handler() {
    local action="$1"
    shift
    case "$action" in
        port)     admin_change_port "$@" ;;
        list)     admin_list_users ;;
        add)      admin_add_user "$@" ;;
        password) admin_change_password "$@" ;;
        delete)   admin_delete_user "$@" ;;
        open)     admin_temp_open "$@" ;;
        close)    source "${CLI_DIR}/core/tempsrv.sh"; tempsrv_close pma ;;
        lock)     admin_lock on ;;
        unlock)   admin_lock off ;;
        *) app_admin_menu ;;
    esac
}

app_admin_menu() {
    load_config
    echo ""
    print_subheader "Admin Panel Management"
    echo ""
    echo "  phpMyAdmin:  http://${ip:-localhost}:${port_admin:-$DKVPS_PORT_ADMIN}/phpmyadmin"
    echo "  Port:        ${port_admin:-$DKVPS_PORT_ADMIN}"
    echo "  Username:    admin"
    echo "  Password:    ${admin_password:-N/A}"
    echo ""

    local options=(
        "Change Admin Port"
        "List Users"
        "Add User"
        "Change Password"
        "Delete User"
        "Open phpMyAdmin temporarily (random port, auto-close)"
        "Close temporary phpMyAdmin now"
        "Lock permanent admin port"
        "Unlock permanent admin port"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") admin_change_port ;;
            "${options[1]}") admin_list_users ;;
            "${options[2]}") admin_add_user ;;
            "${options[3]}") admin_change_password ;;
            "${options[4]}") admin_delete_user ;;
            "${options[5]}") admin_temp_open ;;
            "${options[6]}") source "${CLI_DIR}/core/tempsrv.sh"; tempsrv_close pma ;;
            "${options[7]}") admin_lock on ;;
            "${options[8]}") admin_lock off ;;
            *) return ;;
        esac
    done
}

admin_change_port() {
    local new_port="${1:-}"
    load_config

    if [[ -z "$new_port" ]]; then
        read -p "Enter new admin port [current: ${port_admin:-$DKVPS_PORT_ADMIN}]: " new_port
    fi

    sed -i "s/listen ${port_admin:-$DKVPS_PORT_ADMIN}/listen $new_port/" /etc/nginx/conf.d/admin.conf 2>/dev/null
    firewall_open_port "$new_port"
    set_config "port_admin" "$new_port"
    reload_nginx
    print_success "Admin port changed to $new_port"
}

admin_list_users() {
    echo ""
    print_subheader "Admin Users"
    echo ""
    if [[ -f "$DKVPS_WEB_DIR/passwd/.htpasswd" ]]; then
        cat "$DKVPS_WEB_DIR/passwd/.htpasswd" | cut -d':' -f1
    fi
}

admin_add_user() {
    local username="${1:-}"
    if [[ -z "$username" ]]; then
        read -p "Enter username: " username
    fi
    local password=$(generate_password 24)
    htpasswd -b "$DKVPS_WEB_DIR/passwd/.htpasswd" "$username" "$password" 2>/dev/null
    print_success "User $username added. Password: $password"
}

admin_change_password() {
    local username="${1:-}"
    if [[ -z "$username" ]]; then
        read -p "Enter username: " username
    fi
    local password=$(generate_password 24)
    htpasswd -b "$DKVPS_WEB_DIR/passwd/.htpasswd" "$username" "$password" 2>/dev/null
    print_success "Password changed for $username. New: $password"
}

admin_delete_user() {
    local username="${1:-}"
    if [[ -z "$username" ]]; then
        read -p "Enter username to delete: " username
    fi
    htpasswd -D "$DKVPS_WEB_DIR/passwd/.htpasswd" "$username" 2>/dev/null
    print_success "User $username deleted."
}

# phpMyAdmin on a random port with one-time credentials; closes itself after N hours
admin_temp_open() {
    local hours="${1:-2}"
    [[ "$hours" =~ ^[0-9]+$ ]] && (( hours >= 1 && hours <= 24 )) || { print_error "Usage: dkvps admin open [hours 1-24]"; return 1; }
    local pma=/usr/share/nginx/dkvps/phpmyadmin
    [[ -d "$pma" ]] || { print_error "phpMyAdmin is not installed ($pma)"; return 1; }
    local sock; sock=$(grep -m1 -oE 'fastcgi_pass[[:space:]]+unix:[^;]+' /etc/nginx/conf.d/admin.conf /etc/nginx/conf.d/admin.conf.off 2>/dev/null | head -1 | sed 's/.*unix://')
    [[ -n "$sock" ]] || sock=$(ls /run/php/php*-fpm.sock 2>/dev/null | head -1)
    [[ -S "$sock" ]] || { print_error "PHP-FPM socket not found"; return 1; }
    source "${CLI_DIR}/core/tempsrv.sh"
    local user="pma$(openssl rand -hex 2)" pass; pass=$(openssl rand -base64 18 | tr -dc 'A-Za-z0-9' | cut -c1-20)
    local ht=/var/lib/dkvps/tempsrv/pma.htpasswd     # nginx workers must reach it (/etc/dkvps is 700)
    mkdir -p /var/lib/dkvps/tempsrv; chmod 711 /var/lib/dkvps /var/lib/dkvps/tempsrv
    printf '%s:%s\n' "$user" "$(openssl passwd -apr1 "$pass")" > "$ht"
    chown root:"${NGINX_USER:-www-data}" "$ht"; chmod 640 "$ht"
    local port; port=$(tempsrv_open pma $(( hours * 60 )) "    root $pma;
    index index.php;
    client_max_body_size 256m;
    auth_basic \"DKVPS temporary phpMyAdmin\";
    auth_basic_user_file $ht;
    location ~ /(libraries|setup|templates|vendor|sql)/ { deny all; }
    location / { try_files \$uri \$uri/ =404; }
    location ~ \\.php\$ {
        try_files \$uri =404;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_read_timeout 300s;
        fastcgi_pass unix:$sock;
    }") || return 1
    tempsrv_cleanup_add pma "$ht"
    print_success "phpMyAdmin is open for $hours hour(s):"
    echo "  URL:      http://$(get_public_ip):$port/"
    echo "  Login:    $user / $pass   (then your MariaDB user)"
    print_info "Closes itself at $(date -d "+$hours hour" '+%H:%M'). Close now: dkvps admin close"
    [[ -f /etc/nginx/conf.d/admin.conf ]] && print_info "The permanent admin port ${port_admin:-8080} is still open; lock it: dkvps admin lock"
}

# keep the permanent admin vhost (port 8080) off; temporary access stays available
admin_lock() {
    load_config
    local p="${port_admin:-${DKVPS_PORT_ADMIN:-8080}}" c=/etc/nginx/conf.d/admin.conf
    if [[ "$1" == on ]]; then
        [[ -f "$c" ]] && mv -f "$c" "$c.off"
        fw_close "$p" tcp >/dev/null 2>&1
        nginx -t >/dev/null 2>&1 && systemctl reload nginx
        print_success "Permanent admin port $p locked. Temporary access: dkvps admin open"
    else
        [[ -f "$c.off" ]] && mv -f "$c.off" "$c"
        fw_open "$p" tcp >/dev/null 2>&1
        nginx -t >/dev/null 2>&1 && systemctl reload nginx
        print_success "Permanent admin port $p unlocked"
    fi
}
