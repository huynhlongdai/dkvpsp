#!/bin/bash
#
# DKVPS - doctor: one-shot health check of the whole server
#
#   dkvps doctor               checks with OK / WARN / FAIL and a hint for each problem
#   dkvps doctor --md [FILE]   also write a Markdown report (default /root/dkvps-doctor-<date>.md)
#                              with recent errors, ready to paste to an AI or to support
#   dkvps --json doctor        machine-readable result
#
# Exit: 0 all OK, 1 warnings, 2 failures. Read-only: doctor never changes anything.
#

DOC_R=()   # "level|title|detail|hint"

_doc() { DOC_R+=("$1|$2|$3|$4"); }

_doc_svc() {   # unit label
    local u="$1"
    systemctl list-unit-files "$u.service" --no-legend 2>/dev/null | grep -q . || return 0
    systemctl is-enabled --quiet "$u" 2>/dev/null || return 0
    if systemctl is-active --quiet "$u"; then _doc ok "Service $u" "running" ""
    else _doc fail "Service $u" "$(systemctl is-active "$u" 2>/dev/null)" "journalctl -u $u -n 50 ; systemctl restart $u"; fi
}

doctor_collect() {
    DOC_R=()
    local v pct
    # services
    _doc_svc nginx; _doc_svc "${PHP_FPM_SERVICE:-php-fpm}"; _doc_svc mariadb; _doc_svc redis-server; _doc_svc fail2ban
    local failed; failed=$(systemctl --failed --plain --no-legend 2>/dev/null | awk '{print $1}' | tr '\n' ' ')
    [[ -z "$failed" ]] && _doc ok "Failed units" "none" "" || _doc warn "Failed units" "$failed" "systemctl status <unit> ; systemctl reset-failed"
    # configs
    if command -v nginx >/dev/null; then
        if nginx -t >/dev/null 2>&1; then _doc ok "nginx config" "valid" ""
        else _doc fail "nginx config" "$(nginx -t 2>&1 | grep -m1 -E 'emerg|error' | cut -c1-160)" "fix the file named above, then nginx -t"; fi
    fi
    local fpm; fpm=$(ls /usr/sbin/php-fpm* 2>/dev/null | sort -V | tail -1)
    if [[ -n "$fpm" ]]; then
        if "$fpm" -t >/dev/null 2>&1; then _doc ok "PHP-FPM config" "valid ($(basename "$fpm"))" ""
        else _doc fail "PHP-FPM config" "$("$fpm" -t 2>&1 | grep -m1 -i error | cut -c1-160)" "$(basename "$fpm") -t"; fi
    fi
    if command -v mysqladmin >/dev/null; then
        mysqladmin ping >/dev/null 2>&1 && _doc ok "MariaDB" "answers ping" "" || _doc fail "MariaDB" "no answer" "systemctl status mariadb ; tail /var/log/mysql/error.log"
    fi
    # resources
    pct=$(df --output=pcent / | tail -1 | tr -dc 0-9)
    if (( pct >= 95 )); then _doc fail "Disk /" "${pct}% used" "dkvps util ; journalctl --vacuum-size=100M ; clear old backups"
    elif (( pct >= 85 )); then _doc warn "Disk /" "${pct}% used" "free space soon (old backups, logs)"
    else _doc ok "Disk /" "${pct}% used" ""; fi
    pct=$(df --output=ipcent / | tail -1 | tr -dc 0-9)
    (( ${pct:-0} >= 90 )) && _doc warn "Inodes /" "${pct}% used" "many small files: cache/session dirs" || _doc ok "Inodes /" "${pct:-?}% used" ""
    local avail total sw swf
    avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo); total=$(awk '/MemTotal/{print $2}' /proc/meminfo)
    pct=$(( avail * 100 / total ))
    if (( pct < 5 )); then _doc fail "RAM" "$((avail/1024)) MB free of $((total/1024)) MB" "too many PHP workers/sites: dkvps domain limit, enable swap"
    elif (( pct < 15 )); then _doc warn "RAM" "$((avail/1024)) MB free of $((total/1024)) MB" "watch memory; consider swap/zram"
    else _doc ok "RAM" "$((avail/1024)) MB free of $((total/1024)) MB" ""; fi
    sw=$(awk '/SwapTotal/{print $2}' /proc/meminfo); swf=$(awk '/SwapFree/{print $2}' /proc/meminfo)
    if (( sw == 0 )); then (( total < 2100000 )) && _doc warn "Swap" "none" "dkvps swap create 1024 (or dkvps swap zram on)" || _doc ok "Swap" "none" ""
    elif (( (sw - swf) * 100 / sw > 80 )); then _doc warn "Swap" "$(((sw-swf)/1024)) of $((sw/1024)) MB used" "RAM pressure: reduce workers or add RAM"
    else _doc ok "Swap" "$(((sw-swf)/1024)) of $((sw/1024)) MB used" ""; fi
    local l5 cores; l5=$(awk '{print $2}' /proc/loadavg); cores=$(nproc)
    if awk -v l="$l5" -v c="$cores" 'BEGIN{exit !(l > c*2)}'; then _doc warn "Load (5 min)" "$l5 on $cores CPU" "dkvps monitor ; top"
    else _doc ok "Load (5 min)" "$l5 on $cores CPU" ""; fi
    local oom; oom=$(journalctl -k --since "-24h" --no-pager 2>/dev/null | grep -ciE 'out of memory|oom-kill|killed process')
    (( ${oom:-0} > 0 )) && _doc fail "OOM kills (24 h)" "$oom" "dkvps guard on ; lower PHP workers ; add swap" || _doc ok "OOM kills (24 h)" "0" ""
    # time, reboot, firewall
    v=$(timedatectl show -p NTPSynchronized --value 2>/dev/null)
    [[ "$v" == no ]] && _doc warn "Clock sync" "not synchronized" "timedatectl set-ntp true" || _doc ok "Clock sync" "${v:-unknown}" ""
    [[ -f /var/run/reboot-required ]] && _doc warn "Reboot" "required (kernel/libs updated)" "reboot at a quiet time" || _doc ok "Reboot" "not needed" ""
    if command -v ufw >/dev/null; then
        ufw status 2>/dev/null | grep -q "Status: active" && _doc ok "Firewall" "ufw active" "" || _doc warn "Firewall" "ufw inactive" "dkvps firewall"
    fi
    # sites
    local d code crt end days ip; ip=$(get_public_ip 2>/dev/null)
    for d in $(list_domain_configs); do
        [[ -f "/etc/nginx/conf.d/$d.conf" ]] || { _doc ok "Site $d" "suspended" ""; continue; }
        code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -H "Host: $d" -H "User-Agent: dkvps-doctor" http://127.0.0.1/ 2>/dev/null)
        if [[ "$code" =~ ^[1-4][0-9][0-9]$ ]]; then _doc ok "Site $d" "HTTP $code" ""
        else _doc fail "Site $d" "HTTP $code" "tail /home/*/$d/logs/error.log ; dkvps domain harden $d"; fi
        crt=$(grep -m1 -oE 'ssl_certificate[[:space:]]+[^;]+' "/etc/nginx/conf.d/$d.conf" 2>/dev/null | awk '{print $2}')
        if [[ -n "$crt" && -f "$crt" ]]; then
            end=$(openssl x509 -enddate -noout -in "$crt" 2>/dev/null | cut -d= -f2)
            days=$(( ( $(date -d "$end" +%s) - $(date +%s) ) / 86400 ))
            if (( days < 0 )); then _doc fail "SSL $d" "expired $(( -days )) day(s) ago" "dkvps ssl install $d --force"
            elif (( days < 14 )); then _doc warn "SSL $d" "expires in $days day(s)" "dkvps ssl check"
            else _doc ok "SSL $d" "$days day(s) left" ""; fi
        fi
        if [[ -n "$ip" ]]; then
            local res; res=$(timeout 4 getent ahostsv4 "$d" 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ')
            if [[ -z "$res" ]]; then _doc warn "DNS $d" "no A record" "point $d to $ip"
            elif [[ " $res " != *" $ip "* ]]; then _doc warn "DNS $d" "points to ${res% } (server $ip)" "fine behind Cloudflare/proxy; otherwise fix the A record"
            else _doc ok "DNS $d" "points here" ""; fi
        fi
    done
    # DKVPS itself
    local tier; tier=$( { declare -F license_tier >/dev/null || source "${CLI_DIR}/modules/license/license.sh"; } ; license_tier 2>/dev/null)
    _doc ok "DKVPS" "v${DKVPS_VERSION} ($tier)" ""
    if [[ -f /etc/cron.d/dkvps-backup ]]; then
        local age; age=$(( ( $(date +%s) - $(stat -c %Y /var/log/dkvps-backup.log 2>/dev/null || echo 0) ) / 86400 ))
        (( age > 2 )) && _doc warn "Backups" "last log entry ${age} day(s) ago" "tail /var/log/dkvps-backup.log ; dkvps backup check" || _doc ok "Backups" "ran within 2 days" ""
    else _doc warn "Backups" "no scheduled backup" "dkvps backup repo ... ; dkvps backup auto daily"; fi
}

doctor_run() {
    local md="" want_md=0
    while [[ $# -gt 0 ]]; do
        case "$1" in --md) want_md=1; [[ -n "${2:-}" && "$2" != -* ]] && { md="$2"; shift; } ;; esac; shift
    done
    doctor_collect
    local r lvl t det hint nw=0 nf=0
    for r in "${DOC_R[@]}"; do IFS='|' read -r lvl t det hint <<<"$r"; [[ $lvl == warn ]] && nw=$((nw+1)); [[ $lvl == fail ]] && nf=$((nf+1)); done
    local rc=0; (( nw )) && rc=1; (( nf )) && rc=2
    if [[ "${JSON_MODE:-false}" == true ]]; then
        for r in "${DOC_R[@]}"; do IFS='|' read -r lvl t det hint <<<"$r"; jq -cn --arg l "$lvl" --arg t "$t" --arg d "$det" --arg h "$hint" '{level:$l,check:$t,detail:$d,hint:$h}'; done \
            | jq -cs --argjson w "$nw" --argjson f "$nf" '{warnings:$w, failures:$f, checks:.}'
        return $rc
    fi
    echo ""; print_subheader "DKVPS doctor - $(hostname)"; echo ""
    for r in "${DOC_R[@]}"; do
        IFS='|' read -r lvl t det hint <<<"$r"
        case "$lvl" in
            ok)   printf "  ${GREEN}%-5s${NC} %-28s %s\n" OK "$t" "$det" ;;
            warn) printf "  ${YELLOW}%-5s${NC} %-28s %s\n" WARN "$t" "$det"; [[ -n "$hint" ]] && printf "        %-28s ${CYAN}-> %s${NC}\n" "" "$hint" ;;
            fail) printf "  ${RED}%-5s${NC} %-28s %s\n" FAIL "$t" "$det"; [[ -n "$hint" ]] && printf "        %-28s ${CYAN}-> %s${NC}\n" "" "$hint" ;;
        esac
    done
    echo ""
    echo -e "  Result: ${GREEN}$(( ${#DOC_R[@]} - nw - nf )) OK${NC}, ${YELLOW}$nw warning(s)${NC}, ${RED}$nf failure(s)${NC}"
    if (( want_md )); then
        [[ -n "$md" ]] || md="/root/dkvps-doctor-$(date +%Y%m%d-%H%M).md"
        doctor_markdown > "$md"; chmod 600 "$md"
        print_success "Report: $md  (paste it to an AI assistant or support)"
    fi
    return $rc
}

doctor_markdown() {
    local r lvl t det hint
    echo "# DKVPS doctor report"
    echo ""
    echo "- Host: $(hostname) | $(. /etc/os-release; echo "$PRETTY_NAME") | kernel $(uname -r)"
    echo "- DKVPS: ${DKVPS_VERSION} | $(nproc) CPU | RAM $(( $(awk '/MemTotal/{print $2}' /proc/meminfo) / 1024 )) MB | uptime $(uptime -p 2>/dev/null)"
    echo "- Sites: $(list_domain_configs | wc -l) | generated $(date '+%F %T %Z')"
    echo ""
    echo "## Checks"
    echo ""
    echo "| Status | Check | Detail | Suggested fix |"
    echo "|---|---|---|---|"
    for r in "${DOC_R[@]}"; do IFS='|' read -r lvl t det hint <<<"$r"; echo "| ${lvl^^} | $t | ${det//|//} | ${hint//|//} |"; done
    echo ""
    echo "## Memory (top processes)"
    echo '```'
    ps -eo rss,comm --sort=-rss | head -12 | awk 'NR==1{print "RSS_MB COMMAND"; next}{printf "%6d %s\n", $1/1024, $2}'
    echo '```'
    echo "## nginx errors (last 20)"
    echo '```'
    tail -n 20 /var/log/nginx/error.log 2>/dev/null | sed -E 's/[0-9]{1,3}(\.[0-9]{1,3}){3}/x.x.x.x/g'
    echo '```'
    echo "## System errors, last 24 h (journal, priority err)"
    echo '```'
    journalctl -p err --since "-24h" --no-pager -n 30 2>/dev/null | cut -c1-220
    echo '```'
    echo "## DKVPS alerts (last 15)"
    echo '```'
    tail -n 15 /var/log/dkvps-alerts.log 2>/dev/null
    echo '```'
    echo ""
    echo "_Secrets are not included. IP addresses in nginx logs are masked._"
}

doctor_handler() { doctor_run "$@"; }
