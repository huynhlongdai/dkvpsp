#!/bin/bash
#
# DKVPS - malware / webshell scan
#
#   dkvps scan [<domain>|--all] [--quarantine] [--days N] [--quiet]
#        signatures of common PHP webshells/backdoors, PHP files inside upload dirs,
#        WordPress core files that differ from wordpress.org (wp core verify-checksums),
#        and (--days N) PHP files changed in the last N days
#   dkvps scan auto on|off       daily scan of every site at night, alert on findings (Pro)
#   dkvps scan quarantine        list quarantined files
#   dkvps scan restore <id>      put a quarantined file back
#
# Exit: 0 clean, 1 findings. Quarantine moves files to /var/lib/dkvps/quarantine (mode 000).
#

SCAN_Q=/var/lib/dkvps/quarantine
SCAN_LOG=/var/log/dkvps-scan.log
SCAN_CRON=/etc/cron.d/dkvps-scan

# extended regexes, matched case-insensitively against PHP-like files
SCAN_SIGS=(
    'eval[[:space:]]*\([[:space:]]*(base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13|strrev|rawurldecode|hex2bin)[[:space:]]*\('
    '(eval|assert|create_function)[[:space:]]*\([[:space:]]*@?\$_(POST|GET|REQUEST|COOKIE|SERVER|FILES)'
    '(system|shell_exec|passthru|exec|popen|proc_open|pcntl_exec)[[:space:]]*\([[:space:]]*@?\$_(POST|GET|REQUEST|COOKIE|SERVER)'
    'preg_replace[[:space:]]*\([[:space:]]*["'\''][^"'\'']{1,60}/[a-z]*e[a-z]*["'\''][[:space:]]*,'
    '(FilesMan|c99shell|r57shell|b374k|IndoXploit|WSO[[:space:]]?[0-9]|Alfa[[:space:]]?Shell|Hacked[[:space:]]by|Sh3ll|wso_version|uname[[:space:]]-a.{0,40}passthru)'
    '\\x65\\x76\\x61\\x6c|\\x62\\x61\\x73\\x65\\x36\\x34|\\145\\166\\141\\154'
    'base64_decode[[:space:]]*\([[:space:]]*["'\''][A-Za-z0-9+/=]{3000,}'
    '\$[a-z0-9_]+[[:space:]]*=[[:space:]]*@?\$_(POST|GET|REQUEST|COOKIE)\[[^]]+\][[:space:]]*;[[:space:]]*@?\$[a-z0-9_]+[[:space:]]*\('
    '@?(include|require)(_once)?[[:space:]]*\(?[[:space:]]*["'\''][^"'\'']*\.(ico|png|jpg|gif|txt)["'\'']'
)

scan_handler() {
    case "${1:-}" in
        auto)       shift; scan_auto "$@" ;;
        quarantine) scan_q_list ;;
        restore)    shift; scan_restore "$@" ;;
        -h|--help|help) sed -n '3,15p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//' ;;
        *)          scan_run "$@" ;;
    esac
}

_scan_out() { [[ "$SCAN_QUIET" == 1 ]] || echo -e "$@"; }

_scan_quarantine() {   # domain file reason
    local id; id="$(date +%Y%m%d%H%M%S)-$(openssl rand -hex 3)"
    mkdir -p "$SCAN_Q/$id"; chmod 700 "$SCAN_Q" "$SCAN_Q/$id"
    printf 'domain=%s\npath=%s\nreason=%s\nowner=%s\nmode=%s\n' "$1" "$2" "$3" "$(stat -c %U:%G "$2")" "$(stat -c %a "$2")" > "$SCAN_Q/$id/info"
    mv -f -- "$2" "$SCAN_Q/$id/file" && chmod 000 "$SCAN_Q/$id/file" && echo "$id"
}

# prints "reason<TAB>file" lines for one site
_scan_site() {   # domain days
    local d="$1" days="$2" u root f sig
    u=$(get_username "$d" 2>/dev/null); [[ -n "$u" ]] || u=$(site_get "$d" username)
    root="/home/$u/$d/public_html"
    [[ -d "$root" ]] || return 0
    local -a inc=(--include='*.php' --include='*.php[0-9]' --include='*.phtml' --include='*.phar' --include='*.inc' --include='*.ico' --include='.htaccess')
    for sig in "${SCAN_SIGS[@]}"; do
        grep -rlIEi "${inc[@]}" --exclude-dir=node_modules --exclude-dir=.git -e "$sig" "$root" 2>/dev/null | sed 's/^/signature\t/'
    done | sort -u -t$'\t' -k2,2
    find "$root" -type f \( -path '*/uploads/*' -o -path '*/wp-content/upgrade/*' -o -path '*/storage/app/public/*' \) \
        -regextype posix-extended -iregex '.*\.(php[0-9]?|phtml|phar|pl|py|cgi|sh)$' 2>/dev/null | sed 's/^/php-in-uploads\t/'
    if [[ -f "$root/wp-config.php" || -f "$root/wp-includes/version.php" ]] && command -v wp >/dev/null 2>&1; then
        timeout 90 sudo -u "$u" -- wp core verify-checksums --path="$root" --skip-plugins --skip-themes 2>&1 \
            | grep -E "File doesn't verify|File should not exist" | sed -E "s#.*: (.*)#wp-core-modified\t$root/\1#"
    fi
    if [[ -n "$days" ]]; then
        find "$root" -type f -regextype posix-extended -iregex '.*\.(php[0-9]?|phtml)$' -mtime "-$days" \
            -not -path '*/cache/*' 2>/dev/null | sed 's/^/changed-recently\t/'
    fi
}

scan_run() {
    local target="" quarantine=0 days="" d all=()
    SCAN_QUIET=0
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --all) target="--all" ;;
            --quarantine) quarantine=1 ;;
            --days) days="${2:-}"; shift ;;
            --quiet|-q) SCAN_QUIET=1 ;;
            -*) print_error "Unknown option $1"; return 2 ;;
            *) target="$1" ;;
        esac; shift
    done
    [[ -z "$days" || "$days" =~ ^[0-9]+$ ]] || { print_error "--days needs a number"; return 2; }
    if [[ -z "$target" ]]; then
        if [[ -t 0 && "$SCAN_QUIET" != 1 ]]; then choose_domain || return; target="$SELECTED_DOMAIN"; else target="--all"; fi
    fi
    if [[ "$target" == "--all" ]]; then mapfile -t all < <(list_domain_configs)
    else domain_exists "$target" || { print_error "Domain $target not found"; return 2; }; all=("$target"); fi

    local total=0 serious=0 line reason file id summary=""
    for d in "${all[@]}"; do
        _scan_out "${CYAN}Scanning $d ...${NC}"
        local n=0
        while IFS=$'\t' read -r reason file; do
            [[ -n "$file" ]] || continue
            n=$((n+1)); total=$((total+1))
            [[ "$reason" == changed-recently ]] || serious=$((serious+1))
            local act=""
            if (( quarantine )) && [[ "$reason" == signature || "$reason" == php-in-uploads ]] && [[ -f "$file" ]]; then
                id=$(_scan_quarantine "$d" "$file" "$reason") && act="  -> quarantined ($id)"
            fi
            local col="$RED"; [[ "$reason" == changed-recently ]] && col="$YELLOW"; [[ "$reason" == wp-core-modified ]] && col="$YELLOW"
            _scan_out "  ${col}[$reason]${NC} ${file}${act}"
            printf '%s %s %s %s%s\n' "$(date '+%F %T')" "$d" "$reason" "$file" "$act" >> "$SCAN_LOG"
        done < <(_scan_site "$d" "$days")
        (( n == 0 )) && _scan_out "  ${GREEN}clean${NC}"
        (( n > 0 )) && summary+="$d: $n; "
    done
    if (( serious > 0 )); then
        notify_send crit "scan: $serious suspicious file(s) found. ${summary% ; } Details: $SCAN_LOG"
        _scan_out ""
        print_warning "$serious suspicious file(s). Review them; quarantine with: dkvps scan ${target} --quarantine"
        [[ "$SCAN_QUIET" == 1 ]] || print_info "WordPress core mismatches: reinstall core with 'wp core download --force --skip-content' as the site user."
        return 1
    fi
    _scan_out ""; [[ "$SCAN_QUIET" == 1 ]] || print_success "No suspicious files${days:+ (plus $total changed recently)}"
    return 0
}

scan_auto() {
    case "${1:-}" in
        on)
            declare -F license_require >/dev/null || source "${CLI_DIR}/modules/license/license.sh"
            license_require "Scheduled malware scan" || return 1
            printf 'SHELL=/bin/bash\nPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n%s 2 * * * root /usr/bin/dkvps scan --all --quiet --days 1 >/dev/null 2>&1\n' "$(( RANDOM % 60 ))" > "$SCAN_CRON"
            print_success "Daily scan at 02:xx enabled (alerts go to dkvps notify)" ;;
        off) rm -f "$SCAN_CRON"; print_success "Daily scan disabled" ;;
        *) [[ -f "$SCAN_CRON" ]] && echo "Daily scan: on" || echo "Daily scan: off"; echo "Usage: dkvps scan auto on|off" ;;
    esac
}

scan_q_list() {
    local i any=0
    for i in "$SCAN_Q"/*/info; do
        [[ -f "$i" ]] || continue; any=1
        printf '  %-24s %-20s %s (%s)\n' "$(basename "$(dirname "$i")")" "$(grep ^domain= "$i" | cut -d= -f2)" "$(grep ^path= "$i" | cut -d= -f2-)" "$(grep ^reason= "$i" | cut -d= -f2)"
    done
    (( any )) || echo "  Quarantine is empty"
}

scan_restore() {
    local id="${1:-}" q
    [[ "$id" =~ ^[0-9]{14}-[0-9a-f]{6}$ && -f "$SCAN_Q/$id/info" ]] || { print_error "Usage: dkvps scan restore <id>  (see dkvps scan quarantine)"; return 1; }
    q="$SCAN_Q/$id"
    local path owner mode; path=$(grep ^path= "$q/info" | cut -d= -f2-); owner=$(grep ^owner= "$q/info" | cut -d= -f2); mode=$(grep ^mode= "$q/info" | cut -d= -f2)
    [[ -e "$path" ]] && { print_error "$path exists again; not overwriting"; return 1; }
    mv -f "$q/file" "$path" && chown "$owner" "$path" && chmod "$mode" "$path" && rm -rf "$q"
    print_success "Restored $path"
}

scan_menu() {
    local options=("Scan one site" "Scan all sites" "Scan all + quarantine findings" "Quarantine list" "Daily scan on (Pro)" "Daily scan off")
    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") scan_run ;;
            "${options[1]}") scan_run --all --days 3 ;;
            "${options[2]}") confirm "Move suspicious files to quarantine?" && scan_run --all --quarantine ;;
            "${options[3]}") scan_q_list ;;
            "${options[4]}") scan_auto on ;;
            "${options[5]}") scan_auto off ;;
            *) return ;;
        esac
    done
}
