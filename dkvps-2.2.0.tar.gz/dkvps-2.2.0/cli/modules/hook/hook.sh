#!/bin/bash
#
# DKVPS - webhook deploy (GitHub / GitLab / Gitea / any POST with a shared secret)
#
#   dkvps hook on <domain> [--branch main]   enable: prints the URL + secret to paste into the git host (Pro)
#   dkvps hook off <domain>
#   dkvps hook show <domain>
#   dkvps hook deploy <domain>               what a push runs (also usable by hand)
#   dkvps hook log <domain>
#
# URL: https://<domain>/.dkvps-hook   nginx -> 127.0.0.1:9092 (systemd socket, no resident process)
# Checks X-Hub-Signature-256 (GitHub/Gitea HMAC-SHA256) or X-Gitlab-Token / X-DKVPS-Token.
# Deploy: `dkvps app deploy` for apps; otherwise git pull --ff-only (+ composer install) as the site user.
#

HOOK_PORT=9092

hook_handler() {
    local a="${1:-}"; shift 2>/dev/null
    case "$a" in
        on)     hook_on "$@" ;;
        off)    hook_off "$@" ;;
        show)   hook_show "$@" ;;
        deploy) hook_deploy "$@" ;;
        log)    local u; u=$(get_username "$1"); tail -n 40 "/home/$u/$1/logs/deploy.log" 2>/dev/null ;;
        serve)  hook_serve ;;
        *) sed -n '3,15p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; return 1 ;;
    esac
}

hook_install_units() {
    mkdir -p /etc/dkvps/nginx
    printf '%s\n' \
        '# DKVPS webhook deploy endpoint (dkvps hook on <domain>)' \
        'location = /.dkvps-hook {' \
        '    limit_except POST { deny all; }' \
        '    client_max_body_size 5m;' \
        "    proxy_pass http://127.0.0.1:$HOOK_PORT;" \
        '    proxy_set_header Host $host;' \
        '    proxy_set_header X-DKVPS-Domain $host;' \
        '    proxy_set_header Connection close;' \
        '    proxy_read_timeout 20s;' \
        '}' > /etc/dkvps/nginx/hook.conf
    printf '%s\n' '[Unit]' 'Description=DKVPS webhook listener (socket activated)' '' \
        '[Socket]' "ListenStream=127.0.0.1:$HOOK_PORT" 'Accept=yes' 'MaxConnections=8' '' \
        '[Install]' 'WantedBy=sockets.target' > /etc/systemd/system/dkvps-hook.socket
    printf '%s\n' '[Unit]' 'Description=DKVPS webhook request' '' \
        '[Service]' 'ExecStart=/usr/bin/dkvps hook serve' 'StandardInput=socket' 'StandardOutput=socket' \
        'StandardError=journal' 'TimeoutSec=30' > /etc/systemd/system/dkvps-hook@.service
    systemctl daemon-reload
    systemctl enable --now dkvps-hook.socket >/dev/null 2>&1
}

hook_on() {
    local domain="" branch="main"
    while [[ $# -gt 0 ]]; do case "$1" in --branch) branch="${2:-main}"; shift ;; *) domain="$1" ;; esac; shift; done
    [[ -n "$domain" ]] || { choose_domain || return; domain="$SELECTED_DOMAIN"; }
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    [[ "$branch" =~ ^[A-Za-z0-9._/-]{1,100}$ ]] || { print_error "Bad branch name"; return 1; }
    declare -F license_require >/dev/null || source "${CLI_DIR}/modules/license/license.sh"
    license_require "Webhook deploy" || return 1
    local u root app; u=$(get_username "$domain"); root="/home/$u/$domain"; app=$(site_get "$domain" app)
    if [[ ! "$app" =~ ^(node|bun|python|static)$ && ! -d "$root/public_html/.git" ]]; then
        print_error "$domain is not a git checkout. Clone your repo into $root/public_html first (as $u), or use dkvps app create."
        return 1
    fi
    local conf="$DKVPS_USER_DIR/.$domain.conf" secret
    secret=$(site_get "$domain" hook_secret); [[ -n "$secret" ]] || secret=$(openssl rand -hex 24)
    set_config hook_secret "$secret" "$conf"; set_config hook_branch "$branch" "$conf"
    hook_install_units
    site_write_vhost "$domain" "$u" >/dev/null 2>&1
    nginx -t >/dev/null 2>&1 && systemctl reload nginx && sleep 1   # let the new workers take over
    hook_show "$domain"
}

hook_off() {
    local domain="$1" conf="$DKVPS_USER_DIR/.$1.conf"
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    sed -i '/^hook_secret=/d;/^hook_branch=/d' "$conf"
    site_write_vhost "$domain" "$(get_username "$domain")" >/dev/null 2>&1
    nginx -t >/dev/null 2>&1 && systemctl reload nginx
    grep -qs '^hook_secret=' "$DKVPS_USER_DIR"/.*.conf || systemctl disable --now dkvps-hook.socket >/dev/null 2>&1
    print_success "Webhook deploy off for $domain"
}

hook_show() {
    local domain="$1" secret scheme=http
    secret=$(site_get "$domain" hook_secret); [[ -n "$secret" ]] || { echo "Webhook deploy is off for $domain"; return 1; }
    grep -q 'listen 443' "/etc/nginx/conf.d/$domain.conf" 2>/dev/null && scheme=https
    print_success "Webhook deploy for $domain (branch $(site_get "$domain" hook_branch))"
    echo "  Payload URL:  $scheme://$domain/.dkvps-hook"
    echo "  Secret:       $secret"
    echo "  GitHub:       Settings > Webhooks > Add: content type application/json, the secret above, event 'push'"
    echo "  GitLab:       Settings > Webhooks: URL above, Secret token = the secret, Push events"
    echo "  Manual:       curl -X POST -H 'X-DKVPS-Token: <secret>' $scheme://$domain/.dkvps-hook"
}

_hook_reply() {   # "code text" message
    local ok=false; [[ "$1" == 2* ]] && ok=true
    local body="{\"ok\":$ok,\"message\":\"$2\"}"
    printf 'HTTP/1.1 %s\r\nContent-Type: application/json\r\nContent-Length: %s\r\nConnection: close\r\n\r\n%s' "$1" "${#body}" "$body"
}

# one HTTP request on stdin/stdout (systemd Accept=yes)
hook_serve() {
    local line k v len=0 dom="" sig="" tok="" event="" body
    IFS= read -r -t 10 line || return 0
    [[ "$line" == "POST /.dkvps-hook"* ]] || { _hook_reply "404 Not Found" "not found"; return 0; }
    while IFS= read -r -t 10 line; do
        line="${line%$'\r'}"; [[ -z "$line" ]] && break
        k="${line%%:*}"; v="${line#*:}"; v="${v# }"; k="${k,,}"
        case "$k" in
            content-length) len="${v//[^0-9]/}" ;;
            x-dkvps-domain) dom="${v,,}"; dom="${dom%%:*}" ;;
            x-hub-signature-256) sig="${v#sha256=}" ;;
            x-gitlab-token|x-dkvps-token) tok="$v" ;;
            x-github-event|x-gitea-event|x-gitlab-event) event="${v,,}" ;;
        esac
    done
    len="${len:-0}"
    (( len <= 5242880 )) || { _hook_reply "413 Payload Too Large" "too large"; return 0; }
    { validate_domain "$dom" >/dev/null 2>&1 && domain_exists "$dom"; } || { _hook_reply "404 Not Found" "unknown site"; return 0; }
    local secret; secret=$(site_get "$dom" hook_secret)
    [[ -n "$secret" ]] || { _hook_reply "404 Not Found" "webhook off"; return 0; }
    body=$(mktemp)
    (( len > 0 )) && head -c "$len" > "$body"
    local ok=0
    if [[ -n "$sig" ]]; then
        local mac; mac=$(openssl dgst -sha256 -hmac "$secret" -r < "$body" | awk '{print $1}')
        [[ "${sig,,}" == "$mac" ]] && ok=1
    elif [[ -n "$tok" && "$tok" == "$secret" ]]; then ok=1; fi
    if (( ! ok )); then
        rm -f "$body"; notify_send warn "hook: rejected request for $dom (bad signature)"
        _hook_reply "401 Unauthorized" "bad signature"; return 0
    fi
    [[ "$event" == ping ]] && { rm -f "$body"; _hook_reply "200 OK" "pong"; return 0; }
    local want ref; want=$(site_get "$dom" hook_branch); ref=$(jq -r '.ref // empty' < "$body" 2>/dev/null); rm -f "$body"
    if [[ -n "$ref" && -n "$want" && "$ref" != "refs/heads/$want" ]]; then _hook_reply "200 OK" "ignored $ref"; return 0; fi
    systemd-run --quiet --no-block --unit "dkvps-deploy-${dom//./-}-$(date +%s)" /usr/bin/dkvps hook deploy "$dom" >/dev/null 2>&1 \
        || ( setsid /usr/bin/dkvps hook deploy "$dom" >/dev/null 2>&1 & )
    _hook_reply "202 Accepted" "deploy started"
}

hook_deploy() {
    local domain="$1"
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    local u root app log rc=0; u=$(get_username "$domain"); root="/home/$u/$domain"; app=$(site_get "$domain" app)
    log="$root/logs/deploy.log"; touch "$log"; chown "$u:" "$log" 2>/dev/null
    exec 9>"/run/dkvps-deploy-$domain.lock"; flock -w 300 9 || { print_error "Another deploy is running"; return 1; }
    echo "=== $(date '+%F %T') deploy $domain ===" >> "$log"
    if [[ "$app" =~ ^(node|bun|python|static)$ ]]; then
        /usr/bin/dkvps app deploy "$domain" >> "$log" 2>&1 || rc=$?
    else
        local br; br=$(site_get "$domain" hook_branch)
        ( cd "$root/public_html" && sudo -u "$u" -H git pull --ff-only origin "${br:-main}" ) >> "$log" 2>&1 || rc=$?
        if (( rc == 0 )) && [[ -f "$root/public_html/composer.json" ]] && command -v composer >/dev/null; then
            ( cd "$root/public_html" && sudo -u "$u" -H composer install --no-dev --no-interaction --optimize-autoloader ) >> "$log" 2>&1 || rc=$?
        fi
        (( rc == 0 )) && site_cache_purge "$domain" >/dev/null 2>&1
    fi
    if (( rc == 0 )); then echo "OK" >> "$log"; notify_send ok "deploy: $domain updated"; print_success "Deployed $domain"
    else echo "FAILED rc=$rc" >> "$log"; notify_send crit "deploy: $domain FAILED (see $log)"; print_error "Deploy failed (log: $log)"; fi
    return $rc
}
