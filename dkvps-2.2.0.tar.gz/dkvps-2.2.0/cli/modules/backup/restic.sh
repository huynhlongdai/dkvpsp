#!/bin/bash
#
# DKVPS - incremental, encrypted, deduplicated backups with restic
#
#   dkvps backup repo <repository> [KEY=VALUE ...]   set/init repo (local path,
#        sftp:user@host:/path, s3:https://..., b2:bucket:path, rclone:remote:path)
#   dkvps backup run [domain|--all]                  back up site(s) + server config
#   dkvps backup snapshots [domain]
#   dkvps backup pull <domain> [snapshot|latest] [--as other.domain]
#   dkvps backup auto daily [HH] | off               cron + retention (7d/4w/3m)
#   dkvps backup check
#
# The same repo + password restores on ANY server running DKVPS, so a backup
# is also a migration path ("pull" creates the site if it does not exist).
#

RESTIC_DIR=/etc/dkvps/backup
RESTIC_ENV=$RESTIC_DIR/restic.env

_restic_ready() {
    command -v restic >/dev/null 2>&1 || { print_info "Installing restic..."; apt-get install -y -qq restic >/dev/null 2>&1 || dnf install -y -q restic >/dev/null 2>&1; }
    command -v restic >/dev/null 2>&1 || { print_error "restic not available"; return 1; }
}

_rclone_ready() {
    command -v rclone >/dev/null 2>&1 && return 0
    print_info "Installing rclone..."
    apt-get install -y -qq rclone >/dev/null 2>&1 || dnf install -y -q rclone >/dev/null 2>&1
    command -v rclone >/dev/null 2>&1 || { print_error "rclone not available"; return 1; }
}

# low-RAM friendly restic: 1 core, aggressive GC, lowest CPU/IO priority
_restic() {
    [[ -f "$RESTIC_ENV" ]] || { print_error "No backup repo. Run: dkvps backup repo <repository>"; return 1; }
    ( set -a; source "$RESTIC_ENV"; set +a
      export GOMAXPROCS=1 GOGC=25 RESTIC_CACHE_DIR=/var/cache/dkvps-restic
      nice -n 19 ionice -c3 restic "$@" )
}

backup_repo() {
    local repo="${1:-}"; shift || true
    [[ -n "$repo" ]] || { [[ -f "$RESTIC_ENV" ]] && grep RESTIC_REPOSITORY "$RESTIC_ENV"; echo "Usage: dkvps backup repo <repository> [KEY=VALUE ...]"; return 0; }
    declare -F license_require >/dev/null || source "${CLI_DIR}/modules/license/license.sh"
    license_require "Encrypted cloud backup (restic)" || return 1
    _restic_ready || return 1
    if [[ "$repo" == rclone:* ]]; then
        _rclone_ready || return 1
        local remote="${repo#rclone:}"; remote="${remote%%:*}"
        rclone listremotes 2>/dev/null | grep -qx "$remote:" || { print_error "rclone remote '$remote' not configured. Run: rclone config"; return 1; }
    fi
    mkdir -p "$RESTIC_DIR"; chmod 700 "$RESTIC_DIR"
    if [[ ! -s "$RESTIC_DIR/restic.pass" ]]; then
        if [[ -n "${DKVPS_RESTIC_PASSWORD:-}" ]]; then printf '%s' "$DKVPS_RESTIC_PASSWORD" > "$RESTIC_DIR/restic.pass"
        else openssl rand -base64 32 | tr -d '\n' > "$RESTIC_DIR/restic.pass"; fi
        chmod 600 "$RESTIC_DIR/restic.pass"
    fi
    {
        echo "RESTIC_REPOSITORY=$repo"
        echo "RESTIC_PASSWORD_FILE=$RESTIC_DIR/restic.pass"
        local kv
        for kv in "$@"; do [[ "$kv" =~ ^[A-Z_][A-Z0-9_]*=.+$ ]] && echo "$kv"; done
    } > "$RESTIC_ENV"
    chmod 600 "$RESTIC_ENV"
    [[ "$repo" != *:* ]] && mkdir -p "$repo"
    if _restic cat config >/dev/null 2>&1; then
        print_success "Using existing repository $repo"
    else
        _restic init >/dev/null || { print_error "restic init failed (check repo/credentials)"; return 1; }
        print_success "Initialised repository $repo"
    fi
    print_warning "Repository password: $RESTIC_DIR/restic.pass  - copy it somewhere safe, without it the backups cannot be read."
}

backup_run() {
    local target="${1:---all}" domains=() d rc=0
    if [[ "$target" == "--all" ]]; then mapfile -t domains < <(list_domain_names); else domains=("$target"); fi
    for d in "${domains[@]}"; do
        [[ -n "$d" ]] || continue
        domain_exists "$d" || { print_error "Domain $d not found."; rc=1; continue; }
        local u; u=$(get_username "$d")
        local t0=$SECONDS
        site_pack_prepare "$d" || { rc=1; continue; }
        if _restic backup --quiet --tag "site=$d" --host "$(hostname)" \
             --exclude "/home/$u/$d/tmp" --exclude "/home/$u/$d/logs" \
             --exclude "/home/$u/$d/public_html/wp-content/cache" \
             "/home/$u/$d"; then
            print_success "Backed up $d ($((SECONDS - t0))s)"
        else
            print_error "Backup failed for $d"; rc=1
        fi
        site_pack_cleanup "$d"
    done
    if [[ "$target" == "--all" ]]; then
        _restic backup --quiet --tag server --host "$(hostname)" /etc/dkvps /etc/nginx /etc/cron.d 2>/dev/null \
            && print_success "Backed up server config"
    fi
    return $rc
}

backup_snapshots() {
    local d="${1:-}"
    if [[ -n "$d" ]]; then _restic snapshots --compact --tag "site=$d"; else _restic snapshots --compact; fi
}

backup_pull() {
    local domain="" snap="latest" as=""
    while [[ $# -gt 0 ]]; do
        case "$1" in --as) as="$2"; shift ;; -*) ;; *) [[ -z "$domain" ]] && domain="$1" || snap="$1" ;; esac
        shift
    done
    [[ -n "$domain" ]] || { print_error "Usage: dkvps backup pull <domain> [snapshot|latest] [--as new.domain]"; return 1; }
    [[ "$snap" =~ ^(latest|[0-9a-f]{8,64})$ ]] || { print_error "Bad snapshot id"; return 1; }
    local into="${as:-$domain}"
    if domain_exists "$into" && [[ "${DKVPS_ASSUME_YES:-0}" != "1" ]]; then
        confirm "Replace files and database of $into with backup $snap?" || return 1
    fi
    local work=/var/lib/dkvps/restore/$domain.$$
    rm -rf "$work"; mkdir -p "$work"; chmod 700 /var/lib/dkvps/restore "$work" 2>/dev/null
    _restic restore "$snap" --tag "site=$domain" --target "$work" >/dev/null || { print_error "restic restore failed"; rm -rf "$work"; return 1; }
    local src; src=$(dirname "$(find "$work" -path "*/.dkvps/meta.conf" -print -quit)")
    src=$(dirname "$src")
    [[ -f "$src/.dkvps/meta.conf" ]] || { print_error "Snapshot has no DKVPS metadata"; rm -rf "$work"; return 1; }
    site_import "$into" "$src"; local rc=$?
    rm -rf "$work"
    return $rc
}

backup_auto() {
    local mode="${1:-daily}" hour="${2:-3}"
    declare -F license_require >/dev/null || source "${CLI_DIR}/modules/license/license.sh"
    if [[ "$mode" != off ]]; then license_require "Scheduled cloud backup" || return 1; fi
    case "$mode" in
        off) rm -f /etc/cron.d/dkvps-backup; print_success "Scheduled backups off" ;;
        daily)
            [[ "$hour" =~ ^([01]?[0-9]|2[0-3])$ ]] || { print_error "Hour 0-23"; return 1; }
            [[ -f "$RESTIC_ENV" ]] || { print_error "Set a repo first: dkvps backup repo <repository>"; return 1; }
            cat > /etc/cron.d/dkvps-backup <<CRON
# DKVPS restic backup: all sites + server config, then retention
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
$(( RANDOM % 50 )) $hour * * * root { /usr/bin/dkvps backup run --all && /usr/bin/dkvps backup forget; } >>/var/log/dkvps-backup.log 2>&1 || /usr/bin/dkvps notify send crit "Nightly backup FAILED, see /var/log/dkvps-backup.log"
# weekly integrity check: structure + read back 5% of the stored data
30 $(( (hour + 2) % 24 )) * * 0 root /usr/bin/dkvps backup check >>/var/log/dkvps-backup.log 2>&1 || /usr/bin/dkvps notify send crit "Backup repository integrity check FAILED"
CRON
            print_success "Daily backup at ${hour}h (server time), keep 7 daily / 4 weekly / 3 monthly, weekly integrity check" ;;
        *) print_error "Usage: dkvps backup auto daily [hour] | off"; return 1 ;;
    esac
}

backup_forget() { _restic forget --quiet --group-by host,tags --keep-daily 7 --keep-weekly 4 --keep-monthly 3 --prune; }
# default: verify structure + read back 5% of the data; --full reads everything
backup_check()  {
    if [[ "${1:-}" == "--full" ]]; then _restic check --read-data; else _restic check --read-data-subset=5%; fi
}
