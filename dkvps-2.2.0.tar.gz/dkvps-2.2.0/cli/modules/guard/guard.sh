#!/bin/bash
#
# DKVPS - guard: who the kernel kills first when RAM runs out, and fast restarts
#
#   dkvps guard on|off|status
#
# on: nginx (-900) and MariaDB (-800) are protected, PHP workers / apps go first (+300/+500),
#     nginx / MariaDB / PHP-FPM restart on failure within seconds. Applied live, no restart needed.
#     dkvps watch (every minute) still restarts anything that stays down and alerts.
#

guard_handler() {
    case "${1:-status}" in
        on) guard_on ;; off) guard_off ;; status) guard_status ;;
        *) echo "Usage: dkvps guard on|off|status"; return 1 ;;
    esac
}

_guard_dropin() {   # unit adj
    local d="/etc/systemd/system/$1.service.d"
    mkdir -p "$d"
    printf '# DKVPS guard\n[Service]\nOOMScoreAdjust=%s\nRestart=on-failure\nRestartSec=3s\n' "$2" > "$d/dkvps-guard.conf"
}

guard_on() {
    local u
    for u in nginx:-900 mariadb:-800 redis-server:-500 "${PHP_FPM_SERVICE:-php-fpm}:300"; do
        systemctl cat "${u%%:*}.service" >/dev/null 2>&1 && _guard_dropin "${u%%:*}" "${u##*:}"
    done
    [[ -f /etc/systemd/system/dkvps-fpm@.service ]] && _guard_dropin "dkvps-fpm@" 300
    systemctl daemon-reload
    _guard_live
    mkdir -p /etc/dkvps; touch /etc/dkvps/guard.on
    print_success "Guard on: nginx/MariaDB protected from the OOM killer, PHP/apps go first, auto-restart on failure"
}

# apply the scores to the processes running right now
_guard_live() {
    local p u
    for p in $(pgrep -x nginx 2>/dev/null); do echo -900 > "/proc/$p/oom_score_adj" 2>/dev/null; done
    for p in $(pgrep -x mariadbd 2>/dev/null) $(pgrep -x mysqld 2>/dev/null); do echo -800 > "/proc/$p/oom_score_adj" 2>/dev/null; done
    for p in $(pgrep -x redis-server 2>/dev/null); do echo -500 > "/proc/$p/oom_score_adj" 2>/dev/null; done
    for p in $(pgrep -f '^php-fpm' 2>/dev/null); do echo 300 > "/proc/$p/oom_score_adj" 2>/dev/null; done
    for u in $(systemctl list-units --plain --no-legend 'dkvps-app-*' 2>/dev/null | awk '{print $1}'); do
        for p in $(systemctl show -p MainPID --value "$u" 2>/dev/null); do
            [[ "$p" =~ ^[1-9][0-9]*$ ]] && echo 500 > "/proc/$p/oom_score_adj" 2>/dev/null
        done
    done
    return 0
}

guard_off() {
    rm -f /etc/systemd/system/*.service.d/dkvps-guard.conf /etc/dkvps/guard.on
    systemctl daemon-reload
    print_success "Guard off (takes full effect after services restart)"
}

guard_status() {
    [[ -f /etc/dkvps/guard.on ]] && echo "Guard: on" || echo "Guard: off"
    local n p
    for n in nginx mariadbd redis-server; do
        p=$(pgrep -o -x "$n" 2>/dev/null) || continue
        printf '  %-14s oom_score_adj %s\n' "$n" "$(cat "/proc/$p/oom_score_adj" 2>/dev/null)"
    done
    p=$(pgrep -o -f '^php-fpm' 2>/dev/null) && printf '  %-14s oom_score_adj %s\n' php-fpm "$(cat "/proc/$p/oom_score_adj" 2>/dev/null)"
    return 0
}
