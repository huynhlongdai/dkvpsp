#!/bin/bash
#
# DKVPS - check license + version (online)
#
#   dkvps check            refresh the license with the hub and look for a new DKVPS release
#   dkvps check -q         quiet (cron): only refreshes the cached state
#   dkvps --json check     {"version":{...},"license":{...}} for the Web UI / DKVPS Hub
#   dkvps check banner     one-line summary, used by the menu
#
# Exit: 0 all good, 10 update available, 20 license not valid, 30 both
# No cron / login hook: the check runs only when the user opens `dkvps` (once per launch,
# capped at a few seconds) or runs `dkvps check`. It never updates anything.
#

check_handler() {
    case "${1:-}" in
        banner) check_banner ;;
        -q|--quiet|"") check_run "${1:-}" ;;
        *) sed -n '3,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; return 2 ;;
    esac
}

_chk_src() {
    source "${CLI_DIR}/modules/update/update.sh"
    source "${CLI_DIR}/modules/license/license.sh"
}

check_run() {
    _chk_src
    local quiet=0; [[ "$1" == -q || "$1" == --quiet ]] && quiet=1
    local rc=0 cur latest="" upd="unknown" lic_state="none" lic_plan="" lic_until="" lic_msg=""

    # version
    cur=$(_upd_current)
    local out ur
    out=$(update_check -q 2>/dev/null); ur=$?
    case $ur in
        0)  upd="latest"; latest="$cur" ;;
        10) upd="available"; latest=$(cat "$DKVPS_UPD_STATE/available" 2>/dev/null); rc=$((rc + 10)) ;;
        *)  upd="unknown" ;;
    esac

    # license: ask the hub (refresh), fall back to the offline token
    local key; key=$(get_config key "$LICENSE_CONF" 2>/dev/null)
    if [[ -n "$key" ]]; then
        lic_msg=$(LICENSE_QUIET=1 license_refresh --quiet 2>&1 | sed 's/\x1b\[[0-9;]*m//g' | tail -1)
    fi
    local js; js=$(JSON_MODE=true license_status 2>/dev/null)
    lic_state=$(jq -r '.state // "none"' <<<"$js" 2>/dev/null); lic_state=${lic_state:-none}
    lic_plan=$(jq -r '.plan // empty' <<<"$js" 2>/dev/null)
    lic_until=$(jq -r '.valid_until // empty' <<<"$js" 2>/dev/null)
    local lic_tier; lic_tier=$(jq -r '.tier // "free"' <<<"$js" 2>/dev/null)
    # Free (no key) is a normal state, not a license problem
    [[ "$lic_state" == valid || "$lic_state" == none ]] || rc=$((rc + 20))
    mkdir -p "$DKVPS_UPD_STATE"; date +%s > "$DKVPS_UPD_STATE/checked"

    if [[ "${JSON_MODE:-false}" == true ]]; then
        jq -cn --arg cur "$cur" --arg latest "$latest" --arg upd "$upd" --argjson lic "${js:-null}" --arg msg "$lic_msg" \
            '{version:{current:$cur, latest:(if $latest=="" then null else $latest end), status:$upd, update_available:($upd=="available")},
              license:($lic + {message:(if $msg=="" then null else $msg end)})}'
        return $rc
    fi
    (( quiet )) && return $rc

    echo ""
    print_subheader "DKVPS check"
    echo ""
    case "$upd" in
        latest)    print_status_line "Version" "$cur (latest)" "$GREEN" ;;
        available) print_status_line "Version" "$cur -> $latest available" "$YELLOW" ;;
        *)         print_status_line "Version" "$cur (could not reach the release mirror)" "$YELLOW" ;;
    esac
    if [[ "$lic_state" == valid ]]; then
        local lbl="$lic_plan"; [[ "$lic_tier" == trial ]] && lbl="Pro trial"
        print_status_line "License" "$lbl, valid until $(date -d "@$lic_until" '+%Y-%m-%d %H:%M')" "$GREEN"
    elif [[ "$lic_state" == none ]]; then
        print_status_line "License" "Free (1 domain + basic features)" "$GREEN"
    else
        print_status_line "License" "$lic_state (running as Free)" "$RED"
    fi
    [[ -n "$lic_msg" && "$lic_state" != valid ]] && echo "  $lic_msg"
    echo ""
    [[ "$upd" == available ]] && print_info "Update: dkvps update  (menu: Update DKVPS)"
    [[ "$lic_state" != valid && "$lic_state" != none ]] && print_info "License: dkvps -> License  (or: dkvps license activate <KEY>)"
    return $rc
}

# one line for the menu. The first draw of each `dkvps` launch runs the online check
# (version + license, at most ~6 s); later redraws reuse that result.
check_banner() {
    _chk_src
    if [[ -z "${DKVPS_BANNER_CHECKED:-}" ]]; then
        export DKVPS_BANNER_CHECKED=1
        echo -ne "  Checking version + license...\r"
        timeout 6 "${CLI_DIR}/dkvps" check -q >/dev/null 2>&1
        echo -ne "                              \r"
    fi
    local cur avail plan line
    cur=$(_upd_current); avail=$(cat "$DKVPS_UPD_STATE/available" 2>/dev/null)
    if [[ -n "$avail" ]] && _upd_newer "$avail" "$cur"; then
        line="Version: ${cur} ${YELLOW}(update ${avail} available: menu Update DKVPS)${NC}"
    else
        line="Version: ${cur}"
    fi
    local tier; tier=$(license_tier 2>/dev/null)
    case "$tier" in
        pro|agency) line+=" | License: ${GREEN}${tier}${NC}" ;;
        trial) line+=" | License: ${YELLOW}Pro trial, $(license_days_left) day(s) left${NC}" ;;
        *) if [[ -n "$(get_config key "$LICENSE_CONF" 2>/dev/null)" ]]; then line+=" | License: ${RED}key invalid/expired${NC} (Free)"
           else line+=" | License: Free (1 domain)"; fi ;;
    esac
    echo -e "  $line"
}
