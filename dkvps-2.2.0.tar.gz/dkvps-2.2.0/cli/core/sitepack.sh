#!/bin/bash
#
# DKVPS - site packages: the one format used by restic backups and migrations
#
# A package of <domain> is a directory that mirrors /home/<user>/<domain>
# (public_html, ssl, private ...) plus .dkvps/ holding:
#   meta.conf  - the domain config (credentials, app, cache/redis/limit flags)
#   db.sql     - mariadb-dump of the site database (if any)
# tmp/, logs/ and cache dirs are never packaged.
#

DKVPS_PACK_EXCLUDES=(--exclude=./tmp --exclude=./logs --exclude=./.dkvps-cache --exclude=./public_html/wp-content/cache)

_db_admin() { load_config; mysql -u "$db_admin_user" -p"$db_admin_password" "$@"; }
_db_dump_admin() { load_config; mariadb-dump -u "$db_admin_user" -p"$db_admin_password" "$@" 2>/dev/null || mysqldump -u "$db_admin_user" -p"$db_admin_password" "$@"; }

# Write .dkvps/{meta.conf,db.sql} inside the live site dir (root-only 0700)
site_pack_prepare() {
    local domain="$1"
    local username; username=$(get_username "$domain")
    local root="/home/$username/$domain"
    local m="$root/.dkvps"
    load_domain_config "$domain" || return 1
    mkdir -p "$m"; chown root:root "$m"; chmod 0700 "$m"
    cp "$DKVPS_USER_DIR/.$domain.conf" "$m/meta.conf"; chmod 0600 "$m/meta.conf"
    rm -f "$m/db.sql"
    # acme.sh renewal state travels with the site, so the target keeps renewing
    rm -rf "$m/acme"
    local a
    for a in "/root/.acme.sh/${domain}_ecc" "/root/.acme.sh/${domain}"; do
        [[ -f "$a/$domain.conf" ]] && { mkdir -p "$m/acme"; cp -a "$a" "$m/acme/"; }
    done
    # the issued certs stay behind: a renewal that names them ("replaces", RFC 9773)
    # is refused for the target server's ACME account
    rm -rf "$m"/acme/*/*.cer "$m"/acme/*/backup
    if [[ -n "${db_name:-}" ]]; then
        _db_dump_admin --single-transaction --quick --routines --triggers --hex-blob \
            --default-character-set=utf8mb4 "$db_name" > "$m/db.sql" || { print_error "DB dump failed for $domain"; return 1; }
        chmod 0600 "$m/db.sql"
    fi
}

site_pack_cleanup() {
    local domain="$1"
    local username; username=$(get_username "$domain")
    rm -f "/home/$username/$domain/.dkvps/db.sql"
}

# Stream a package as tar on stdout
site_pack_export() {
    local domain="$1"
    domain_exists "$domain" || { print_error "Domain $domain not found." >&2; return 1; }
    local username; username=$(get_username "$domain")
    site_pack_prepare "$domain" >&2 || return 1
    tar -C "/home/$username/$domain" "${DKVPS_PACK_EXCLUDES[@]}" --numeric-owner -cf - .
    local rc=$?
    site_pack_cleanup "$domain"
    return $rc
}

# Import a package directory as <domain>: creates or replaces the site,
# keeping the original DB name/user/password so app configs work unchanged.
site_import() {
    local domain="$1" src="$2"
    local meta="$src/.dkvps/meta.conf"
    [[ -f "$meta" ]] || { print_error "Not a DKVPS package (missing .dkvps/meta.conf)"; return 1; }
    validate_domain "$domain" || return 1
    if ! domain_exists "$domain"; then
        declare -F license_domain_quota >/dev/null || source "${CLI_DIR}/modules/license/license.sh"
        license_domain_quota || return 1
    fi

    local m_user m_db m_dbu m_dbp m_auth m_sftp
    m_user=$(grep -E '^username=' "$meta" | cut -d= -f2-)
    m_db=$(grep -E '^db_name=' "$meta" | cut -d= -f2-)
    m_dbu=$(grep -E '^db_user=' "$meta" | cut -d= -f2-)
    m_dbp=$(grep -E '^db_password=' "$meta" | cut -d= -f2-)
    m_auth=$(grep -E '^password=' "$meta" | cut -d= -f2-)
    m_sftp=$(grep -E '^password_sftp=' "$meta" | cut -d= -f2-)
    local m_domain; m_domain=$(grep -E '^domain=' "$meta" | cut -d= -f2-)
    local username; username=$(get_username "$domain")
    local renamed=0
    if [[ -n "$m_domain" && "$m_domain" != "$domain" ]]; then
        # imported under another name (clone/staging): never reuse the source
        # site's database, give the copy its own DB + credentials
        renamed=1
        if domain_exists "$domain"; then
            # over an existing site (staging push): keep that site's DB + logins
            local t="$DKVPS_USER_DIR/.$domain.conf"
            [[ -n "$m_db" ]] && { m_db=$(get_config db_name "$t"); m_dbu=$(get_config db_user "$t"); m_dbp=$(get_config db_password "$t"); }
            [[ -n "$m_db" ]] || { m_db="${username}_db"; m_dbu="${username}_user"; m_dbp=$(generate_password 32); }
            m_sftp=$(get_config password_sftp "$t"); m_auth=$(get_config password "$t")
            # and its own settings (SSL, cache, redis, limits, Cloudflare)
            grep -E '^(ssl_[a-z_]+|fcgi_cache|redis|redis_mem|limit|limit_[a-z]+|cf_[a-z_]+)=' "$t" > "/tmp/.dkvps-keep-$domain" 2>/dev/null
        elif [[ -n "$m_db" ]]; then
            m_db="${username}_db"; m_dbu="${username}_user"; m_dbp=$(generate_password 32)
        fi
        if ! domain_exists "$domain"; then m_sftp=$(generate_password 32); m_auth=$(generate_password 24); fi
    fi
    [[ "$m_user" =~ ^[a-z_][a-z0-9_-]*$ ]] || { print_error "Bad username in package"; return 1; }
    [[ -z "$m_db" || "$m_db" =~ ^[A-Za-z0-9_]+$ ]] || { print_error "Bad db_name in package"; return 1; }
    [[ -z "$m_dbu" || "$m_dbu" =~ ^[A-Za-z0-9_]+$ ]] || { print_error "Bad db_user in package"; return 1; }
    [[ "$m_dbp" != *"'"* && "$m_dbp" != *'\\'* ]] || { print_error "Unsupported characters in db password"; return 1; }

    local root="/home/$username/$domain"
    if domain_exists "$domain"; then
        print_info "Replacing existing site $domain"
    else
        print_info "Creating site $domain from package"
        if ! id "$username" >/dev/null 2>&1; then
            if getent group "$username" >/dev/null; then
                useradd -M -d "/home/$username" -s /usr/sbin/nologin -g "$username" "$username"
            else
                useradd -M -U -d "/home/$username" -s /usr/sbin/nologin "$username"
            fi
        fi
        # a pool for a missing user would take the whole PHP-FPM down
        id "$username" >/dev/null 2>&1 || { print_error "Could not create user $username"; return 1; }
        [[ -n "$m_sftp" ]] && echo "$username:$m_sftp" | chpasswd
        usermod -aG sftp_users "$username" 2>/dev/null
        if command -v htpasswd &>/dev/null && [[ -n "$m_auth" ]]; then
            htpasswd -b "$DKVPS_WEB_DIR/passwd/.htpasswd" "$username" "$m_auth" 2>/dev/null
        fi
    fi

    # config: package values, but paths/username of this server
    sed -e "s|^username=.*|username=$username|" -e "s|^domain=.*|domain=$domain|" \
        -e "s|^public_html=.*|public_html=$root/public_html|" \
        -e "s|^php_version=.*|php_version=${DKVPS_PHP_VERSION:-${php_default_version:-8.3}}|" \
        -e "s|^db_name=.*|db_name=$m_db|" -e "s|^db_user=.*|db_user=$m_dbu|" \
        -e "s|^db_password=.*|db_password=$m_dbp|" \
        -e "s|^password=.*|password=$m_auth|" -e "s|^password_sftp=.*|password_sftp=$m_sftp|" \
        "$meta" > "$DKVPS_USER_DIR/.$domain.conf"
    chmod 600 "$DKVPS_USER_DIR/.$domain.conf"

    # files
    mkdir -p "$root"
    if command -v rsync >/dev/null 2>&1; then
        local xs=(); [[ "$renamed" == "1" ]] && xs=(--exclude=/ssl)   # never ship another name's certs
        rsync -a --delete --exclude=/.dkvps --exclude=/tmp --exclude=/logs "${xs[@]}" "$src/" "$root/"
    else
        local keep=(); [[ "$renamed" == "1" ]] && keep=(! -name ssl)
        find "$root" -mindepth 1 -maxdepth 1 ! -name tmp ! -name logs ! -name .dkvps "${keep[@]}" -exec rm -rf {} +
        (cd "$src" && tar --exclude=./.dkvps $([[ "$renamed" == "1" ]] && echo --exclude=./ssl) -cf - .) | tar -C "$root" -xf -
    fi
    rm -rf "$root/.dkvps"

    # SSL: same name -> keep cert + renewal; new name -> the old cert is useless
    if [[ "$renamed" == "1" ]]; then
        rm -f "$root/ssl/$m_domain".{key,crt,fullchain.crt}
        local k; for k in ssl_mode ssl_redirect ssl_hsts ssl_names ssl_challenge ssl_provider ssl_staging staging_of cf_shield_auto; do
            sed -i "/^$k=/d" "$DKVPS_USER_DIR/.$domain.conf"; done
        if [[ -s "/tmp/.dkvps-keep-$domain" ]]; then
            local kv; while IFS= read -r kv; do set_config "${kv%%=*}" "${kv#*=}" "$DKVPS_USER_DIR/.$domain.conf"; done < "/tmp/.dkvps-keep-$domain"
        fi
        rm -f "/tmp/.dkvps-keep-$domain"
    elif [[ -d "$src/.dkvps/acme" ]]; then
        rm -rf "/root/.acme.sh/${domain}_ecc" "/root/.acme.sh/${domain}"
        if [[ -x /root/.acme.sh/acme.sh ]]; then
            cp -a "$src/.dkvps/acme/." /root/.acme.sh/
        else
            # acme.sh comes later (dkvps ssl check installs it and re-adopts)
            mkdir -p /root/.acme.sh.pending && cp -a "$src/.dkvps/acme/." /root/.acme.sh.pending/
        fi
    fi

    # database
    if [[ -n "$m_db" ]]; then
        _db_admin -e "DROP DATABASE IF EXISTS \`$m_db\`; CREATE DATABASE \`$m_db\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" || return 1
        _db_admin -e "CREATE USER IF NOT EXISTS '$m_dbu'@'localhost' IDENTIFIED BY '$m_dbp'; ALTER USER '$m_dbu'@'localhost' IDENTIFIED BY '$m_dbp'; GRANT ALL PRIVILEGES ON \`$m_db\`.* TO '$m_dbu'@'localhost'; FLUSH PRIVILEGES;" || return 1
        if [[ -s "$src/.dkvps/db.sql" ]]; then
            _db_admin "$m_db" < "$src/.dkvps/db.sql" || { print_error "DB import failed"; return 1; }
        fi
    fi

    # isolation, pool, vhost, optional private redis / cgroup limits
    local app; app=$(site_get "$domain" app)
    site_apply "$domain" "$username" "${app:-php}"

    # WordPress under a new name: point wp-config at the new DB, rewrite URLs
    local wp="$root/public_html"
    if [[ "$renamed" == "1" && -f "$wp/wp-config.php" ]] && command -v wp >/dev/null 2>&1; then
        local wpc=(sudo -u "$username" HOME="$root/tmp" wp --path="$wp" --skip-plugins --skip-themes)
        chmod 0600 "$wp/wp-config.php"
        if [[ -n "$m_db" ]]; then
            "${wpc[@]}" config set DB_NAME "$m_db" >/dev/null 2>&1
            "${wpc[@]}" config set DB_USER "$m_dbu" >/dev/null 2>&1
            "${wpc[@]}" config set DB_PASSWORD "$m_dbp" >/dev/null 2>&1
        fi
        chmod 0400 "$wp/wp-config.php"
        "${wpc[@]}" search-replace "//$m_domain" "//$domain" --all-tables-with-prefix --skip-columns=guid --quiet >/dev/null 2>&1
        print_info "Rewrote URLs $m_domain -> $domain"
    fi
    # Laravel under a new name: its own DB credentials, APP_URL and scheduler
    if [[ -f "$wp/artisan" && -f "$wp/.env" ]]; then
        if [[ "$renamed" == "1" ]]; then
            chmod 0600 "$wp/.env"
            sed -i -E "s|^APP_URL=.*|APP_URL=http://$domain|" "$wp/.env"
            if [[ -n "$m_db" ]] && grep -q '^DB_CONNECTION=mysql' "$wp/.env"; then
                sed -i -E -e "s|^DB_DATABASE=.*|DB_DATABASE=$m_db|" -e "s|^DB_USERNAME=.*|DB_USERNAME=$m_dbu|" -e "s|^DB_PASSWORD=.*|DB_PASSWORD=\"$m_dbp\"|" "$wp/.env"
            fi
            chown "$username:$username" "$wp/.env"; chmod 0400 "$wp/.env"
            ( cd "$wp" && sudo -u "$username" HOME="$root/tmp" "php${DKVPS_PHP_VERSION}" artisan optimize:clear -q ) >/dev/null 2>&1
            print_info "Laravel: APP_URL and DB set for $domain"
        fi
        printf 'SHELL=/bin/bash\n* * * * * %s cd %s && %s artisan schedule:run >/dev/null 2>&1\n' \
            "$username" "$wp" "$(command -v "php${DKVPS_PHP_VERSION}" || command -v php)" > "/etc/cron.d/dkvps-laravel-${domain//./-}"
    fi
    if site_flag "$domain" redis; then
        site_redis_enable "$domain" "$username" "$(site_get "$domain" redis_mem)"
        site_write_pool "$domain" "$username"
    fi
    site_flag "$domain" limit && site_php_restart "$domain"
    restart_php >/dev/null 2>&1
    reload_nginx >/dev/null 2>&1 || restart_nginx >/dev/null 2>&1
    site_cache_purge "$domain" >/dev/null 2>&1 || true
    print_success "Imported $domain (user $username${m_db:+, db $m_db})"
}

# plain list of domain names (one per line)
list_domain_names() {
    local f d
    for f in "$DKVPS_USER_DIR"/.*.conf; do
        [[ -f "$f" ]] || continue
        d=$(basename "$f" .conf); d="${d#.}"
        [[ "$d" == *.* ]] && echo "$d"
    done
}
