#!/bin/bash
#
# DKVPS - Site kit: resource profile, per-site isolation, PHP-FPM pool,
# Nginx vhost and FastCGI page cache. Every module that creates or rewrites
# a site goes through these helpers so the security model stays in one place.
#
# Isolation model (per site):
#   /home/<user>                  root:<user> 0750  (SFTP chroot, nginx traverses via group)
#   /home/<user>/<domain>         <user>:<user> 2750
#     public_html                 <user>:<user> 2750, files 0640, dirs 2750
#     tmp, session                <user>:<user> 0700  (private temp, never /tmp)
#     logs                        <user>:<user> 0750
#   nginx user is added to the <user> group (read-only); site users are NEVER
#   added to the nginx/www-data group, so site A cannot read site B's files.
#   PHP-FPM listens on a unix socket owned by nginx (0660) instead of a TCP
#   port: a compromised site cannot speak FastCGI to another site's pool.
#

DKVPS_FCGI_CACHE_DIR="${DKVPS_FCGI_CACHE_DIR:-/var/cache/nginx/dkvps}"
DKVPS_SITE_INC_DIR="${DKVPS_SITE_INC_DIR:-/etc/dkvps/nginx/sites}"
DKVPS_DISABLE_FUNCTIONS_DEFAULT="exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,proc_nice,show_source,dl,posix_kill,posix_setuid,posix_setgid,posix_mkfifo"

# ------------------------------------------------------------------
# Resource profile
# ------------------------------------------------------------------

# Effective RAM in MB: the smaller of MemTotal and a cgroup memory limit
# (containers / LXC VPS report host RAM in /proc/meminfo).
dkvps_effective_ram_mb() {
    local mem_kb limit
    mem_kb=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    local ram=$((mem_kb / 1024))
    local cg="/sys/fs/cgroup$(awk -F: '$1=="0"{print $3}' /proc/self/cgroup 2>/dev/null)"
    while [[ "$cg" == /sys/fs/cgroup* ]]; do
        limit=$(cat "$cg/memory.max" 2>/dev/null)
        if [[ "$limit" =~ ^[0-9]+$ ]] && (( limit / 1048576 < ram )); then ram=$((limit / 1048576)); fi
        [[ "$cg" == "/sys/fs/cgroup" ]] && break
        cg="${cg%/*}"
    done
    limit=$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null)
    if [[ "$limit" =~ ^[0-9]+$ ]] && (( limit / 1048576 < ram )); then ram=$((limit / 1048576)); fi
    echo "$ram"
}

# lite (<= 1.5 GB) or standard. Config key "profile" or env DKVPS_PROFILE wins.
dkvps_profile() {
    if [[ -n "${DKVPS_PROFILE:-}" ]]; then echo "$DKVPS_PROFILE"; return; fi
    if [[ -n "${profile:-}" ]]; then echo "$profile"; return; fi
    if (( $(dkvps_effective_ram_mb) <= 1536 )); then echo "lite"; else echo "standard"; fi
}

# Max PHP workers for one site. Pools are ondemand, so idle sites cost 0 MB;
# this bounds how much one flooded/hacked site can take.
site_fpm_max_children() {
    if [[ -n "${fpm_max_children:-}" ]]; then echo "$fpm_max_children"; return; fi
    case "$(dkvps_profile)" in
        lite) echo 3 ;;
        *)    echo 8 ;;
    esac
}

site_php_memory_limit() {
    case "$(dkvps_profile)" in
        lite) echo "128M" ;;
        *)    echo "256M" ;;
    esac
}

site_socket() { echo "/run/php/dkvps-$1.sock"; }

# ------------------------------------------------------------------
# Filesystem layout + permissions
# ------------------------------------------------------------------

site_secure_layout() {
    local domain="$1" username="$2"
    local home="/home/$username" root="/home/$username/$domain"
    local web_group="${NGINX_USER:-www-data}"

    mkdir -p "$root"/{public_html,logs,tmp,session,ssl,restore}

    chown root:"$username" "$home"; chmod 0750 "$home"
    chown "$username:$username" "$root"; chmod 2750 "$root"

    chown -R "$username:$username" "$root/public_html"
    find "$root/public_html" -type d -exec chmod 2750 {} + 2>/dev/null
    find "$root/public_html" -type f -exec chmod 0640 {} + 2>/dev/null

    chown -R "$username:$username" "$root"/{logs,tmp,session,restore}
    chmod 0750 "$root/logs"
    chmod 0700 "$root"/{tmp,session,restore}
    # private keys: root only (nginx master reads them as root), so a
    # compromised site cannot steal its own certificate key
    chown -R root:root "$root/ssl"; chmod 0700 "$root/ssl"

    # Secrets readable by the owner (PHP runs as the owner) only
    local f
    for f in "$root/public_html/wp-config.php" "$root/public_html/.env"; do
        [[ -f "$f" ]] && chmod 0400 "$f"
    done

    # nginx reads site files through the site group; never the other way round
    usermod -aG "$username" "$web_group" 2>/dev/null
    gpasswd -d "$username" "$web_group" >/dev/null 2>&1 || true
}

# ------------------------------------------------------------------
# PHP-FPM pool
# ------------------------------------------------------------------

site_write_pool() {
    local domain="$1" username="$2"
    local root="/home/$username/$domain"
    local sock; sock=$(site_socket "$username")
    local max_children; max_children=$(site_fpm_max_children)
    local mem; mem=$(site_php_memory_limit)
    local disable="${disable_functions:-$DKVPS_DISABLE_FUNCTIONS_DEFAULT}"
    [[ "${allow_exec:-0}" == "1" ]] && disable="show_source,dl"

    local pool_file; pool_file=$(site_pool_file "$domain")
    local redis_sock=""; site_flag "$domain" redis && redis_sock=$(site_redis_socket "$username")
    rm -f "$PHP_POOL_DIR/$domain.conf" "/etc/dkvps/fpm/$domain.pool.conf"
    mkdir -p "$(dirname "$pool_file")"
    cat > "$pool_file" <<EOF
; DKVPS pool for $domain (profile: $(dkvps_profile))
[$domain]
user = $username
group = $username
listen = $sock
listen.owner = ${NGINX_USER:-www-data}
listen.group = ${NGINX_USER:-www-data}
listen.mode = 0660

pm = ondemand
pm.max_children = $max_children
pm.process_idle_timeout = 10s
pm.max_requests = 500
pm.status_path = /fpm-status
request_terminate_timeout = 120s
request_slowlog_timeout = 10s
slowlog = $root/logs/php-fpm-slow.log
rlimit_core = 0
catch_workers_output = yes
security.limit_extensions = .php
clear_env = yes
env[TMPDIR] = $root/tmp
env[TMP] = $root/tmp
env[TEMP] = $root/tmp

php_admin_value[open_basedir] = $root/:/usr/share/php/:/dev/urandom
php_admin_value[sys_temp_dir] = $root/tmp
php_admin_value[upload_tmp_dir] = $root/tmp
php_admin_value[session.save_path] = $root/session
php_admin_value[soap.wsdl_cache_dir] = $root/tmp
php_admin_value[error_log] = $root/logs/php-error.log
php_admin_flag[log_errors] = on
php_admin_flag[display_errors] = off
php_admin_flag[allow_url_include] = off
php_admin_flag[expose_php] = off
php_admin_value[disable_functions] = $disable
php_admin_value[memory_limit] = $mem
php_value[upload_max_filesize] = 64M
php_value[post_max_size] = 64M
php_value[max_execution_time] = 120
php_value[max_input_vars] = 5000
EOF
    if [[ -n "$redis_sock" ]]; then
        cat >> "$pool_file" <<EOF
; private Redis instance of this site (dkvps domain redis)
php_admin_value[session.save_handler] = redis
php_admin_value[session.save_path] = "unix://$redis_sock?database=1"
EOF
    fi
    site_flag "$domain" limit && site_write_fpm_unit "$domain" "$username"
    return 0
}

# ------------------------------------------------------------------
# Per-site flags stored in /etc/dkvps/user/.<domain>.conf (key=1)
# ------------------------------------------------------------------
site_flag() {
    local v; v=$(grep -E "^$2=" "$DKVPS_USER_DIR/.$1.conf" 2>/dev/null | tail -1 | cut -d= -f2)
    [[ "$v" == "1" ]]
}
site_get() { grep -E "^$2=" "$DKVPS_USER_DIR/.$1.conf" 2>/dev/null | tail -1 | cut -d= -f2-; }

# Limited sites get their own FPM master in their own cgroup; others share
# the distro FPM service (cheapest: one master, ondemand pools).
site_pool_file() {
    if site_flag "$1" limit; then echo "/etc/dkvps/fpm/$1.pool.conf"; else echo "$PHP_POOL_DIR/$1.conf"; fi
}

# ------------------------------------------------------------------
# Per-site cgroup limits (CPU / RAM / tasks) via a dedicated FPM master
# ------------------------------------------------------------------
site_fpm_bin() {
    local b="/usr/sbin/php-fpm${DKVPS_PHP_VERSION}"
    [[ -x "$b" ]] || b=$(command -v php-fpm 2>/dev/null || echo /usr/sbin/php-fpm)
    echo "$b"
}

site_write_fpm_unit() {
    local domain="$1" username="$2"
    local root="/home/$username/$domain"
    local cpu ram tasks
    cpu=$(site_get "$domain" limit_cpu); ram=$(site_get "$domain" limit_ram); tasks=$(site_get "$domain" limit_tasks)
    mkdir -p /etc/dkvps/fpm
    cat > "/etc/dkvps/fpm/$domain.conf" <<EOF
; DKVPS dedicated FPM master for $domain
[global]
pid = /run/php/dkvps-fpm-$domain.pid
error_log = $root/logs/php-fpm.log
daemonize = no
include = /etc/dkvps/fpm/$domain.pool.conf
EOF
    if [[ ! -f /etc/systemd/system/dkvps-fpm@.service ]]; then
        cat > /etc/systemd/system/dkvps-fpm@.service <<EOF
[Unit]
Description=DKVPS PHP-FPM (isolated site %i)
After=network.target

[Service]
Type=notify
ExecStartPre=/bin/mkdir -p /run/php
ExecStart=$(site_fpm_bin) --nodaemonize --fpm-config /etc/dkvps/fpm/%i.conf -d opcache.memory_consumption=32
ExecReload=/bin/kill -USR2 \$MAINPID
Restart=on-failure
OOMScoreAdjust=400
Slice=dkvps-sites.slice

[Install]
WantedBy=multi-user.target
EOF
    fi
    mkdir -p "/etc/systemd/system/dkvps-fpm@$domain.service.d"
    {
        echo "[Service]"
        echo "ExecStart="
        echo "ExecStart=$(site_fpm_bin) --nodaemonize --fpm-config /etc/dkvps/fpm/%i.conf -d opcache.memory_consumption=32"
        [[ -n "$cpu" ]]   && echo "CPUQuota=${cpu}%"
        if [[ -n "$ram" ]]; then
            echo "MemoryMax=$ram"
            echo "MemorySwapMax=0"
        fi
        echo "TasksMax=${tasks:-64}"
    } > "/etc/systemd/system/dkvps-fpm@$domain.service.d/10-limits.conf"
    systemctl daemon-reload
}

# Restart whatever FPM serves this site
site_php_restart() {
    local domain="$1"
    if site_flag "$domain" limit; then
        # the shared master must let go of the site socket before the dedicated one binds it
        systemctl restart "$PHP_FPM_SERVICE"
        local sock i; sock="/run/php/dkvps-$(get_username "$domain").sock"
        for i in 1 2 3 4 5 6 7 8 9 10; do
            ss -xlpn 2>/dev/null | grep -F "$sock " | grep -qv "dkvps-fpm@" || break
            systemctl is-active --quiet "dkvps-fpm@$domain" && break
            sleep 0.5
        done
        systemctl enable "dkvps-fpm@$domain" >/dev/null 2>&1
        systemctl restart "dkvps-fpm@$domain" || { sleep 2; systemctl restart "dkvps-fpm@$domain"; }
    else
        systemctl disable --now "dkvps-fpm@$domain" >/dev/null 2>&1 || true
        systemctl restart "$PHP_FPM_SERVICE"
    fi
}

# ------------------------------------------------------------------
# Private Redis per site (object cache + sessions), unix socket only
# ------------------------------------------------------------------
# Managed block of define()s in wp-config.php, placed right after "<?php".
# site_wp_block <wp-config> <name> [php lines...]   (no lines = remove block)
# (wp config set cannot add new constants to configs without the
#  "stop editing" anchor, which silently left Redis on the shared server.)
site_wp_block() {
    local f="$1" name="$2"; shift 2
    [[ -f "$f" ]] || return 1
    local tmp; tmp=$(mktemp)
    awk -v b="// DKVPS:$name BEGIN" -v e="// DKVPS:$name END" '
        $0==b {skip=1; next} $0==e {skip=0; next} !skip {print}' "$f" > "$tmp"
    if [[ $# -gt 0 ]]; then
        local blk; blk=$(mktemp)
        { echo "// DKVPS:$name BEGIN"; printf '%s\n' "$@"; echo "// DKVPS:$name END"; } > "$blk"
        awk -v bf="$blk" 'NR==1 && /^<\?php/ {print; while ((getline l < bf) > 0) print l; next} {print}' "$tmp" > "$tmp.2" && mv "$tmp.2" "$tmp"
        rm -f "$blk"
    fi
    cat "$tmp" > "$f"; rm -f "$tmp"
    php -l "$f" >/dev/null 2>&1 || { print_error "wp-config syntax check failed: $f"; return 1; }
}

site_redis_socket() { echo "/run/dkvps-redis-$1/redis.sock"; }

site_redis_enable() {
    local domain="$1" username="$2" mem="${3:-}"
    [[ -n "$mem" ]] || { [[ "$(dkvps_profile)" == "lite" ]] && mem=24 || mem=64; }
    mkdir -p /etc/dkvps/redis
    cat > "/etc/dkvps/redis/$username.conf" <<EOF
# DKVPS private Redis for $domain
port 0
unixsocket /run/dkvps-redis-$username/redis.sock
unixsocketperm 600
daemonize no
supervised systemd
databases 2
maxmemory ${mem}mb
maxmemory-policy allkeys-lru
save ""
appendonly no
loglevel warning
logfile ""
EOF
    chown root:"$username" "/etc/dkvps/redis/$username.conf"; chmod 0640 "/etc/dkvps/redis/$username.conf"
    if [[ ! -f /etc/systemd/system/dkvps-redis@.service ]]; then
        cat > /etc/systemd/system/dkvps-redis@.service <<EOF
[Unit]
Description=DKVPS private Redis for site user %i
After=network.target

[Service]
Type=notify
User=%i
Group=%i
RuntimeDirectory=dkvps-redis-%i
RuntimeDirectoryMode=0700
ExecStart=$(command -v redis-server) /etc/dkvps/redis/%i.conf
Restart=on-failure
MemoryMax=96M
OOMScoreAdjust=600
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
Slice=dkvps-sites.slice

[Install]
WantedBy=multi-user.target
EOF
    fi
    systemctl daemon-reload
    systemctl enable --now "dkvps-redis@$username" >/dev/null 2>&1
    systemctl restart "dkvps-redis@$username"
    set_config "redis" "1" "$DKVPS_USER_DIR/.$domain.conf"
    set_config "redis_mem" "$mem" "$DKVPS_USER_DIR/.$domain.conf"

    # WordPress object cache (Redis Object Cache plugin) on the private socket
    local wp="/home/$username/$domain/public_html"
    if [[ -f "$wp/wp-config.php" ]] && command -v wp >/dev/null 2>&1; then
        local sock; sock=$(site_redis_socket "$username")
        site_wp_block "$wp/wp-config.php" redis \
            "define('WP_REDIS_SCHEME', 'unix');" \
            "define('WP_REDIS_PATH', '$sock');" \
            "define('WP_REDIS_DATABASE', 0);" \
            "define('WP_CACHE_KEY_SALT', '$domain:');"
        sudo -u "$username" HOME="/home/$username/$domain/tmp" wp --path="$wp" plugin install redis-cache --activate >/dev/null 2>&1
        sudo -u "$username" HOME="/home/$username/$domain/tmp" wp --path="$wp" redis enable --force >/dev/null 2>&1
    fi
}

site_redis_disable() {
    local domain="$1" username="$2"
    local wp="/home/$username/$domain/public_html"
    if [[ -f "$wp/wp-config.php" ]] && command -v wp >/dev/null 2>&1; then
        sudo -u "$username" HOME="/home/$username/$domain/tmp" wp --path="$wp" redis disable >/dev/null 2>&1
    fi
    [[ -f "$wp/wp-config.php" ]] && site_wp_block "$wp/wp-config.php" redis
    systemctl disable --now "dkvps-redis@$username" >/dev/null 2>&1
    rm -f "/etc/dkvps/redis/$username.conf"
    set_config "redis" "0" "$DKVPS_USER_DIR/.$domain.conf"
}

# ------------------------------------------------------------------
# Nginx: shared body include + thin http/https server blocks
# ------------------------------------------------------------------

site_cache_enabled() {
    local domain="$1"
    local c=""
    c=$(grep -E '^fcgi_cache=' "$DKVPS_USER_DIR/.$domain.conf" 2>/dev/null | cut -d= -f2)
    [[ "$c" == "1" ]]
}

site_write_vhost() {
    local domain="$1" username="$2" app="${3:-}"
    local root="/home/$username/$domain"
    local sock; sock=$(site_socket "$username")
    local zone="fc_${username}"
    local docroot="$root/public_html"
    [[ "$app" == "laravel" || -f "$docroot/artisan" ]] && docroot="$root/public_html/public"

    mkdir -p "$DKVPS_SITE_INC_DIR" "$DKVPS_FCGI_CACHE_DIR/$domain"
    chown "${NGINX_USER:-www-data}:" "$DKVPS_FCGI_CACHE_DIR/$domain" 2>/dev/null

    local cache_block=""
    if site_cache_enabled "$domain"; then
        cache_block="
        fastcgi_cache $zone;
        fastcgi_cache_valid 200 301 302 30m;
        fastcgi_cache_use_stale error timeout updating invalid_header http_500 http_503;
        fastcgi_cache_background_update on;
        fastcgi_cache_lock on;
        fastcgi_cache_bypass \$dkvps_skip_cache;
        fastcgi_no_cache \$dkvps_skip_cache;
        include /etc/dkvps/nginx/headers.conf;
        add_header X-Cache \$upstream_cache_status always;"
    fi

    local _sa; _sa=$(site_get "$domain" app)
    [[ "$_sa" =~ ^(node|bun|python|static)$ ]] && app="$_sa"
    if [[ "$app" =~ ^(node|bun|python|static)$ ]]; then
        declare -F app_write_inc >/dev/null || source "${CLI_DIR:-/etc/dkvps/menu}/modules/app/app.sh"
        app_write_inc "$domain" "$username"
    else
    cat > "$DKVPS_SITE_INC_DIR/$domain.inc" <<EOF
# DKVPS site body for $domain (generated - edit via dkvps, custom rules in $DKVPS_SITE_INC_DIR/$domain.custom)
root $docroot;
index index.php index.html index.htm;

access_log $root/logs/access.log;
error_log $root/logs/error.log warn;

include /etc/dkvps/nginx/headers.conf;

include $DKVPS_SITE_INC_DIR/$domain.custom;
include /etc/dkvps/nginx/protect.conf;

set \$dkvps_skip_cache 0;
if (\$request_method = POST) { set \$dkvps_skip_cache 1; }
if (\$query_string != "") { set \$dkvps_skip_cache 1; }
if (\$request_uri ~* "/wp-admin/|/wp-login\.php|/xmlrpc\.php|/wp-json/|/feed/|sitemap(_index)?\.xml|/cart/|/checkout/|/my-account/|preview=true") { set \$dkvps_skip_cache 1; }
if (\$http_cookie ~* "comment_author|wordpress_[a-f0-9]+|wp-postpass|wordpress_logged_in|woocommerce_items_in_cart|woocommerce_cart_hash|wp_woocommerce_session") { set \$dkvps_skip_cache 1; }

location ~* \.(?:css|js|jpg|jpeg|gif|png|webp|avif|ico|svg|woff2?|ttf|eot|mp4|webm)\$ {
    expires 30d;
    access_log off;
    include /etc/dkvps/nginx/headers.conf;
    add_header Cache-Control "public";
    try_files \$uri =404;
}

location / {
    try_files \$uri \$uri/ /index.php?\$args;
}

location = /wp-login.php {
    limit_req zone=dkvps_login burst=10 nodelay;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
    fastcgi_pass unix:$sock;
}

location ~ \.php\$ {
    try_files \$uri =404;
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
    fastcgi_param HTTP_PROXY "";
    fastcgi_index index.php;
    fastcgi_read_timeout 120s;
    fastcgi_buffer_size 32k;
    fastcgi_buffers 16 16k;
    fastcgi_pass unix:$sock;$cache_block
}
EOF
    fi
    # webhook deploy endpoint (dkvps hook on <domain>)
    [[ -n "$(site_get "$domain" hook_secret)" ]] && echo 'include /etc/dkvps/nginx/hook.conf;' >> "$DKVPS_SITE_INC_DIR/$domain.inc"
    [[ -f "$DKVPS_SITE_INC_DIR/$domain.custom" ]] || echo "# custom nginx rules for $domain (server context)" > "$DKVPS_SITE_INC_DIR/$domain.custom"

    # Redirect + SSL state survives a rewrite
    local ssl_crt="" ssl_key="" redirect=0
    if [[ -f "$root/ssl/$domain.fullchain.crt" && -f "$root/ssl/$domain.key" ]]; then
        ssl_crt="$root/ssl/$domain.fullchain.crt"; ssl_key="$root/ssl/$domain.key"
    fi
    local rflag; rflag=$(site_get "$domain" ssl_redirect)
    if [[ -n "$rflag" ]]; then [[ "$rflag" == "1" ]] && redirect=1
    else grep -q "return 301 https" "/etc/nginx/conf.d/$domain.conf" 2>/dev/null && redirect=1; fi
    # unknown names / bare-IP scans on 443 get no certificate (no domain leak)
    if [[ -n "$ssl_crt" ]] && ! grep -qs "listen 443.*default_server" /etc/nginx/conf.d/*.conf; then
        printf 'server {\n    listen 443 ssl default_server;\n    server_name _;\n    ssl_reject_handshake on;\n}\n' > /etc/nginx/conf.d/00-dkvps-ssl-default.conf
    fi

    local vconf="/etc/nginx/conf.d/$domain.conf" vbak=""
    if [[ -f "$vconf" ]]; then vbak=$(mktemp); cp -p "$vconf" "$vbak"; fi
    {
        echo "# DKVPS vhost for $domain"
        if site_cache_enabled "$domain"; then
            echo "fastcgi_cache_path $DKVPS_FCGI_CACHE_DIR/$domain levels=1:2 keys_zone=$zone:8m max_size=256m inactive=60m use_temp_path=off;"
        fi
        echo "server {"
        echo "    listen 80;"
        [[ "$redirect" == "1" && -n "$ssl_crt" ]] && echo "    return 301 https://\$host\$request_uri;"
        echo "    server_name $domain www.$domain;"
        echo "    include $DKVPS_SITE_INC_DIR/$domain.inc;"
        echo "}"
        if [[ -n "$ssl_crt" ]]; then
            cat <<EOF

server {
    listen 443 ssl http2;
    server_name $domain www.$domain;
    ssl_certificate $ssl_crt;
    ssl_certificate_key $ssl_key;
    include /etc/dkvps/nginx/ssl.conf;
    include $DKVPS_SITE_INC_DIR/$domain.inc;
}
EOF
        fi
    } > "$vconf"
    # one bad vhost must never take every site down on the next reload
    if command -v nginx >/dev/null 2>&1 && ! nginx -t >/dev/null 2>&1; then
        local err; err=$(nginx -t 2>&1 | grep -m1 emerg)
        local custom="$DKVPS_SITE_INC_DIR/$domain.custom"
        if [[ "$err" == *"$custom"* ]]; then
            # the site's own custom rules are broken: park them, keep serving
            mv "$custom" "$custom.rejected"; : > "$custom"
            if nginx -t >/dev/null 2>&1; then
                rm -f "$vbak"
                print_error "Custom nginx rules of $domain are invalid, moved to $custom.rejected: $err"
                return 0
            fi
        fi
        if [[ -n "$vbak" ]]; then cp -p "$vbak" "$vconf"; else rm -f "$vconf"; fi
        rm -f "$vbak"
        print_error "nginx rejected the new vhost for $domain, kept the previous one: $err"
        return 1
    fi
    rm -f "$vbak"
    return 0
}

# ------------------------------------------------------------------
# FastCGI cache control
# ------------------------------------------------------------------

site_cache_purge() {
    local domain="$1"
    [[ -n "$domain" && "$domain" != *"/"* && "$domain" != .* ]] || return 1
    local d="$DKVPS_FCGI_CACHE_DIR/$domain"
    [[ -d "$d" ]] && find "$d" -mindepth 1 -delete 2>/dev/null
    return 0
}

# Install the WordPress mu-plugin that requests a purge on content change
site_install_wp_purge_plugin() {
    local domain="$1" username="$2"
    local wp="/home/$username/$domain/public_html"
    [[ -f "$wp/wp-settings.php" ]] || return 0
    mkdir -p "$wp/wp-content/mu-plugins"
    cat > "$wp/wp-content/mu-plugins/dkvps-cache-purge.php" <<'EOF'
<?php
/**
 * Plugin Name: DKVPS Cache Purge
 * Description: Asks the server to purge this site's Nginx page cache when content changes.
 */
if (!defined('ABSPATH')) { exit; }
function dkvps_request_purge() {
    $flag = dirname(ABSPATH) . '/tmp/.dkvps_purge';
    @touch($flag);
}
foreach (array('save_post', 'deleted_post', 'trashed_post', 'edit_post', 'comment_post', 'wp_set_comment_status',
               'switch_theme', 'customize_save_after', 'wp_update_nav_menu', 'activated_plugin',
               'deactivated_plugin', 'upgrader_process_complete', 'woocommerce_product_set_stock') as $h) {
    add_action($h, 'dkvps_request_purge');
}
EOF
    chown -R "$username:$username" "$wp/wp-content/mu-plugins"
    chmod 2750 "$wp/wp-content/mu-plugins"; chmod 0640 "$wp/wp-content/mu-plugins/dkvps-cache-purge.php"
}

# Called every minute by /etc/cron.d/dkvps-cache (root): honour purge flags.
site_cache_purge_pending() {
    local conf domain username flag
    for conf in "$DKVPS_USER_DIR"/.*.conf; do
        [[ -f "$conf" ]] || continue
        domain=$(basename "$conf" .conf); domain="${domain#.}"
        [[ "$domain" == *"."* ]] || continue
        username=$(grep -E '^username=' "$conf" | cut -d= -f2)
        [[ -n "$username" ]] || continue
        flag="/home/$username/$domain/tmp/.dkvps_purge"
        if [[ -e "$flag" || -L "$flag" ]]; then
            rm -f -- "$flag"
            site_cache_purge "$domain"
        fi
    done
}

# The shared Redis must not listen on TCP: every site's PHP can reach
# 127.0.0.1:6379 and read/flush the others' keys. Unix socket, group redis only
# (sites get their own instance with `dkvps domain redis <d> on`).
server_harden_redis() {
    local c=/etc/redis/redis.conf; [[ -f /etc/redis.conf ]] && c=/etc/redis.conf
    [[ -f "$c" ]] || return 0
    grep -qE '^port 0$' "$c" && grep -qE '^unixsocketperm 770$' "$c" && return 0
    sed -i -E 's/^port [0-9]+/port 0/; /^unixsocket(perm)? /d' "$c"
    grep -qE '^port 0$' "$c" || echo "port 0" >> "$c"
    printf 'unixsocket /run/redis/redis-server.sock\nunixsocketperm 770\n' >> "$c"
    systemctl restart redis-server 2>/dev/null || systemctl restart redis 2>/dev/null || true
}

# Shared nginx snippets + http-level zones (idempotent, also upgrades old installs)
site_ensure_globals() {
    mkdir -p /etc/dkvps/nginx "$DKVPS_SITE_INC_DIR" "$DKVPS_FCGI_CACHE_DIR"
    cat > /etc/dkvps/nginx/headers.conf <<'EOF'
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Strict-Transport-Security $dkvps_hsts always;
EOF
    cat > /etc/dkvps/nginx/protect.conf <<'EOF'
# DKVPS shared protection rules (server context)
# a site user's symlink to another site's files is never followed
disable_symlinks if_not_owner from=$document_root;
location ^~ /.well-known/acme-challenge/ { default_type "text/plain"; try_files $uri =404; }
location ~ /\.(?!well-known/) { deny all; access_log off; log_not_found off; }
location ~* /(?:uploads|files|wp-content/uploads|storage|cache)/.*\.(?:php[0-9]?|phtml|phar|pl|py|cgi|sh)$ { return 403; }
location ~* /(?:wp-config\.php|wp-config-sample\.php|readme\.html|license\.txt|composer\.(?:json|lock)|package(?:-lock)?\.json)$ { return 404; }
location ~* \.(?:env|git|svn|sql|sql\.gz|bak|old|orig|swp|log|ini|sh)$ { return 404; }
location ^~ /vendor/ { return 404; }
location ^~ /node_modules/ { return 404; }
location = /xmlrpc.php { return 444; }
include /etc/dkvps/nginx/referer-block*.conf;
EOF
    server_harden_redis
    # TLS settings owned by DKVPS (ECDHE only, so no dhparam file is needed)
    cat > /etc/dkvps/nginx/ssl.conf <<'EOF'
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;
ssl_prefer_server_ciphers off;
ssl_session_cache shared:DKVPS_SSL:2m;
ssl_session_timeout 1d;
ssl_session_tickets off;
EOF
    local g=/etc/dkvps/nginx/global.conf
    touch "$g"
    grep -q 'dkvps_login' "$g" || echo 'limit_req_zone $binary_remote_addr zone=dkvps_login:10m rate=10r/m;' >> "$g"
    grep -q 'fastcgi_cache_key' "$g" || echo 'fastcgi_cache_key "$scheme$request_method$host$request_uri";' >> "$g"
    grep -q 'fastcgi_ignore_headers' "$g" || echo 'fastcgi_ignore_headers Cache-Control Expires;' >> "$g"
    grep -q 'dkvps_conn_upgrade' "$g" || printf 'map $http_upgrade $dkvps_conn_upgrade {\n    default upgrade;\n    "" "";\n}\n' >> "$g"
    # daily certificate audit: renew failures, migrated sites, expiry alerts
    [[ -f /etc/cron.d/dkvps-ssl ]] || printf 'SHELL=/bin/bash\nPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n%s 4 * * * root /usr/bin/dkvps ssl check >/dev/null 2>&1\n' "$(( RANDOM % 60 ))" > /etc/cron.d/dkvps-ssl
    # HSTS per site (dkvps ssl hsts <d> on): SNI name -> header value, empty = not sent
    touch /etc/dkvps/nginx/hsts.map
    grep -q 'dkvps_hsts' "$g" || printf 'map $ssl_server_name $dkvps_hsts {\n    default "";\n    include /etc/dkvps/nginx/hsts.map;\n}\n' >> "$g"
}

# One call that (re)applies the full isolation + performance model to a site.
site_apply() {
    local domain="$1" username="$2" app="${3:-}"
    site_ensure_globals
    site_secure_layout "$domain" "$username"
    [[ "$app" =~ ^(node|bun|python|static)$ ]] || site_write_pool "$domain" "$username"
    site_write_vhost "$domain" "$username" "$app"
    [[ "$app" == "wp" ]] && site_install_wp_purge_plugin "$domain" "$username"
    return 0
}
