#!/bin/bash
#
# DKVPS - temporary nginx servers on a random port that close themselves
# (temporary phpMyAdmin, one-off database download links).
#
#   tempsrv_open <name> <minutes> <server-body>   prints the port
#   tempsrv_close <name>
#   tempsrv_list
#   tempsrv_cleanup_add <name> <path>            removed when the server closes
#

TEMPSRV_DIR=/etc/dkvps/tempsrv

_tempsrv_port() {
    local p used; used=$(ss -Hltn 2>/dev/null | awk '{print $4}' | sed 's/.*://' | sort -u)
    for _ in $(seq 1 50); do
        p=$(( 20000 + RANDOM % 40000 ))
        grep -qx "$p" <<<"$used" || { echo "$p"; return 0; }
    done
    return 1
}

tempsrv_open() {   # name minutes body
    local name="$1" min="$2" body="$3" port conf
    [[ "$name" =~ ^[a-z0-9-]{1,40}$ && "$min" =~ ^[0-9]+$ ]] || { print_error "tempsrv: bad name/minutes"; return 1; }
    tempsrv_close "$name" >/dev/null 2>&1
    mkdir -p "$TEMPSRV_DIR"; chmod 750 "$TEMPSRV_DIR"
    port=$(_tempsrv_port) || { print_error "No free port"; return 1; }
    conf="/etc/nginx/conf.d/dkvps-temp-$name.conf"
    printf '# DKVPS temporary server "%s", closes %s\nserver {\n    listen %s;\n    listen [::]:%s;\n    server_name _;\n    access_log /var/log/nginx/dkvps-temp-%s.log;\n%s\n}\n' \
        "$name" "$(date -d "+$min min" '+%F %T')" "$port" "$port" "$name" "$body" > "$conf"
    if ! nginx -t >/dev/null 2>&1; then
        sed -i "s/^    listen \[::\]:$port;//" "$conf"          # host without IPv6
        nginx -t >/dev/null 2>&1 || { print_error "nginx rejected the temporary server: $(nginx -t 2>&1 | grep -m1 emerg)"; rm -f "$conf"; return 1; }
    fi
    systemctl reload nginx 2>/dev/null || nginx -s reload
    fw_open "$port" tcp >/dev/null 2>&1
    printf 'port=%s\nexpires=%s\n' "$port" "$(date -d "+$min min" +%s)" > "$TEMPSRV_DIR/$name"
    systemctl stop "dkvps-temp-$name.timer" >/dev/null 2>&1; systemctl reset-failed "dkvps-temp-$name.service" "dkvps-temp-$name.timer" >/dev/null 2>&1
    systemd-run --quiet --unit "dkvps-temp-$name" --on-active="${min}m" /usr/bin/dkvps tempsrv close "$name" >/dev/null 2>&1 \
        || echo "$(date -d "+$min min" '+%M %H %d %m') * root /usr/bin/dkvps tempsrv close $name; rm -f /etc/cron.d/dkvps-temp-$name" > "/etc/cron.d/dkvps-temp-$name"
    echo "$port"
}

tempsrv_cleanup_add() { mkdir -p "$TEMPSRV_DIR"; echo "$2" >> "$TEMPSRV_DIR/$1.cleanup"; }

tempsrv_close() {
    local name="$1" port p
    [[ "$name" =~ ^[a-z0-9-]{1,40}$ ]] || return 1
    port=$(grep -E '^port=' "$TEMPSRV_DIR/$name" 2>/dev/null | cut -d= -f2)
    rm -f "/etc/nginx/conf.d/dkvps-temp-$name.conf" "/etc/cron.d/dkvps-temp-$name"
    nginx -t >/dev/null 2>&1 && { systemctl reload nginx 2>/dev/null || nginx -s reload; }
    [[ -n "$port" ]] && fw_close "$port" tcp >/dev/null 2>&1
    if [[ -f "$TEMPSRV_DIR/$name.cleanup" ]]; then
        while read -r p; do [[ "$p" == /var/lib/dkvps/* || "$p" == /etc/dkvps/tempsrv/* ]] && rm -rf -- "$p"; done < "$TEMPSRV_DIR/$name.cleanup"
    fi
    rm -f "$TEMPSRV_DIR/$name" "$TEMPSRV_DIR/$name.cleanup"
    systemctl stop "dkvps-temp-$name.timer" >/dev/null 2>&1
    [[ -n "$port" ]] && print_success "Closed temporary access '$name' (port $port)"
}

tempsrv_list() {
    local f n
    for f in "$TEMPSRV_DIR"/*; do
        [[ -f "$f" && "$f" != *.cleanup && "$f" != *.htpasswd ]] || continue
        n=$(basename "$f")
        printf '  %-24s port %-6s closes %s\n' "$n" "$(grep ^port= "$f" | cut -d= -f2)" "$(date -d "@$(grep ^expires= "$f" | cut -d= -f2)" '+%F %T')"
    done
}

tempsrv_handler() {
    case "${1:-list}" in
        close) tempsrv_close "$2" ;;
        list)  tempsrv_list ;;
        *) echo "Usage: dkvps tempsrv list|close <name>"; return 1 ;;
    esac
}
