#!/bin/bash
# 2.2.0: Free tier (1 domain) / license key tiers, guard, no license cron
rm -f /etc/cron.d/dkvps-license
/usr/bin/dkvps guard on >/dev/null 2>&1 || true
exit 0
