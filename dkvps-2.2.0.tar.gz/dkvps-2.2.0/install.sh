#!/bin/bash
#
# DKVPS - VPS Management Tool Installer
# Supports: AlmaLinux 8/9, RockyLinux 8/9, Ubuntu 20.04/22.04/24.04, Debian 11/12/13
#
# One-line install (recommended): curl -fsSL <mirror>/get.sh | sudo bash
# Manual: run from a full checkout: sudo bash install.sh
#
# Non-interactive / advanced options (environment variables):
#   DKVPS_SSH_PORT=22          keep/change SSH port without prompting
#   DKVPS_PHP_VERSION=8.3      default PHP version (default 8.3)
#   DKVPS_SKIP_FIREWALL=1      do not touch ufw/firewalld
#   DKVPS_SKIP_SSHD=1          do not modify sshd_config (SFTP chroot, port)
#   DKVPS_NGINX_HTTPS=0        do not bind :443 default server (port already used)
#   DKVPS_AGENT_PORT=9090      agent API port
#   DKVPS_SKIP_UPGRADE=1       skip full apt/dnf upgrade
#

set -Eeuo pipefail
trap 'echo -e "\033[0;31m[ERROR]\033[0m install.sh failed at line $LINENO: $BASH_COMMAND" >&2' ERR
export DEBIAN_FRONTEND=noninteractive
# Fresh VPS often run unattended-upgrades at first boot: wait for the dpkg lock instead of failing
apt_get() { apt-get -o DPkg::Lock::Timeout=900 -o Dpkg::Options::=--force-confold "$@"; }

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DKVPS_VERSION="$(cat "$SCRIPT_DIR/cli/VERSION" 2>/dev/null || echo 1.0.0)"

echo -e "${CYAN}=========================================================================${NC}"
echo -e "${WHITE}${BOLD}          DKVPS v${DKVPS_VERSION} - VPS Management Tool Installer${NC}"
echo -e "${CYAN}=========================================================================${NC}"
echo ""

# ============================================================
# Pre-flight checks
# ============================================================

if [[ "$EUID" -ne 0 ]]; then
    echo -e "${RED}[ERROR]${NC} Please run as root: sudo bash install.sh"
    exit 1
fi

# Re-running a full install would rotate DB/admin secrets: send people to update
if [[ -f /etc/dkvps/.dkvps.conf && "${DKVPS_FORCE_REINSTALL:-0}" != "1" ]]; then
    echo -e "${YELLOW}[INFO]${NC} DKVPS is already installed here. Use: dkvps update"
    echo "       (set DKVPS_FORCE_REINSTALL=1 to reinstall anyway; secrets will be regenerated)"
    exit 0
fi

# Detect OS
if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    OS_NAME="$ID"
    OS_VERSION="$VERSION_ID"
else
    echo -e "${RED}[ERROR]${NC} Cannot detect OS."
    exit 1
fi

echo -e "${GREEN}[OK]${NC} Detected: $OS_NAME $OS_VERSION"

# Supported OS check
case "$OS_NAME" in
    almalinux|rocky|centos) PKG_MANAGER="dnf" ;;
    ubuntu|debian) PKG_MANAGER="apt-get" ;;
    *)
        echo -e "${RED}[ERROR]${NC} Unsupported OS: $OS_NAME"
        echo "Supported: AlmaLinux 8/9, RockyLinux 8/9, Ubuntu 20.04/22.04"
        exit 1
        ;;
esac

# ============================================================
# Configuration
# ============================================================

if [[ -n "${DKVPS_SSH_PORT:-}" ]]; then
    PORT_SSH="$DKVPS_SSH_PORT"
elif [[ -t 0 ]]; then
    read -p "Change SSH port? Enter new port or press Enter to keep 22: " PORT_SSH
fi
PORT_SSH=${PORT_SSH:-22}
[[ "$PORT_SSH" =~ ^[0-9]+$ ]] && (( PORT_SSH > 0 && PORT_SSH < 65536 )) || { echo "Invalid SSH port"; exit 1; }

PHP_VER="${DKVPS_PHP_VERSION:-8.3}"
PORT_AGENT="${DKVPS_AGENT_PORT:-9090}"
SKIP_FIREWALL="${DKVPS_SKIP_FIREWALL:-0}"
SKIP_SSHD="${DKVPS_SKIP_SSHD:-0}"
NGINX_HTTPS="${DKVPS_NGINX_HTTPS:-1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Resource profile: lite (<= 1.5 GB effective RAM, incl. cgroup limits) or standard.
# Override with DKVPS_PROFILE=lite|standard.
EFFECTIVE_RAM_MB=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) / 1024 ))
# cgroup v2: walk from this process' cgroup up to the root (containers/LXC VPS)
_cg="/sys/fs/cgroup$(awk -F: '$1=="0"{print $3}' /proc/self/cgroup 2>/dev/null || true)"
while [[ -n "$_cg" && "$_cg" == /sys/fs/cgroup* ]]; do
    _l=$(cat "$_cg/memory.max" 2>/dev/null || true)
    if [[ "$_l" =~ ^[0-9]+$ ]] && (( _l / 1048576 < EFFECTIVE_RAM_MB )); then EFFECTIVE_RAM_MB=$((_l / 1048576)); fi
    [[ "$_cg" == "/sys/fs/cgroup" ]] && break
    _cg="${_cg%/*}"
done
_l=$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || true)
if [[ "$_l" =~ ^[0-9]+$ ]] && (( _l / 1048576 < EFFECTIVE_RAM_MB )); then EFFECTIVE_RAM_MB=$((_l / 1048576)); fi
if [[ -n "${DKVPS_PROFILE:-}" ]]; then PROFILE="$DKVPS_PROFILE"
elif (( EFFECTIVE_RAM_MB <= 1536 )); then PROFILE="lite"; else PROFILE="standard"; fi

if [[ "$PKG_MANAGER" == "apt-get" ]]; then
    NGINX_USER="www-data"
    PHP_FPM_SERVICE="php${PHP_VER}-fpm"
    PHP_FPM_SOCK="/run/php/php${PHP_VER}-fpm.sock"
    PHP_INI="/etc/php/${PHP_VER}/fpm/php.ini"
    REDIS_SERVICE="redis-server"
else
    NGINX_USER="nginx"
    PHP_FPM_SERVICE="php-fpm"
    PHP_FPM_SOCK="/run/php-fpm/www.sock"
    PHP_INI="/etc/php.ini"
    REDIS_SERVICE="redis"
fi

PORT_ADMIN=8080
DB_ROOT_PASSWORD=$(openssl rand -base64 48 | tr -dc 'a-zA-Z0-9' | head -c 32)
ADMIN_PASSWORD=$(openssl rand -base64 48 | tr -dc 'a-zA-Z0-9' | head -c 24)
IP=$(curl -s -m 10 https://api.ipify.org 2>/dev/null || curl -s -m 10 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

echo ""
echo -e "${YELLOW}[INFO]${NC} SSH Port: $PORT_SSH"
echo -e "${YELLOW}[INFO]${NC} Admin Port: $PORT_ADMIN"
echo -e "${YELLOW}[INFO]${NC} IP: $IP"
echo ""
echo -e "${YELLOW}[INFO]${NC} PHP: $PHP_VER | Agent port: $PORT_AGENT | Profile: $PROFILE (${EFFECTIVE_RAM_MB} MB)"
echo -e "${YELLOW}[INFO]${NC} Starting installation... This may take 5-10 minutes."
sleep 2

# ============================================================
# System Setup
# ============================================================

echo -e "${CYAN}[1/12]${NC} Setting timezone & updating system..."
timedatectl set-timezone Asia/Ho_Chi_Minh || true
export LC_ALL=C.UTF-8
export LANG=C.UTF-8

if [[ "$PKG_MANAGER" == "dnf" ]]; then
    dnf -y install epel-release 2>/dev/null || true
    [[ "${DKVPS_SKIP_UPGRADE:-0}" == "1" ]] || dnf -y update
    dnf -y install psmisc lsof bc gawk wget zip unzip nano git htop jq bind-utils \
        policycoreutils-python-utils httpd-tools expect
elif [[ "$PKG_MANAGER" == "apt-get" ]]; then
    apt_get update
    [[ "${DKVPS_SKIP_UPGRADE:-0}" == "1" ]] || apt_get upgrade -y
    apt_get install -y wget zip unzip nano git htop jq dnsutils apache2-utils expect \
        curl gnupg ca-certificates lsb-release cron openssl bc psmisc lsof
    # add-apt-repository is only needed for the Ubuntu PPA; the package was dropped in Debian 13
    [[ "$OS_NAME" == "ubuntu" ]] && apt_get install -y software-properties-common
fi

# ============================================================
# Firewall
# ============================================================

echo -e "${CYAN}[2/12]${NC} Configuring firewall..."
if [[ "$SKIP_FIREWALL" == "1" ]]; then
    echo -e "${YELLOW}[SKIP]${NC} Firewall (DKVPS_SKIP_FIREWALL=1)"
elif [[ "$PKG_MANAGER" == "dnf" ]]; then
    systemctl start firewalld 2>/dev/null || true
    systemctl enable firewalld 2>/dev/null || true
    firewall-cmd --permanent --zone=public --add-service=http --add-service=https 2>/dev/null || true
    firewall-cmd --permanent --zone=public --add-port=$PORT_ADMIN/tcp 2>/dev/null || true
    firewall-cmd --permanent --zone=public --add-port=$PORT_AGENT/tcp 2>/dev/null || true
    if [[ "$PORT_SSH" != "22" ]]; then
        firewall-cmd --permanent --zone=public --add-port=$PORT_SSH/tcp 2>/dev/null || true
    fi
    firewall-cmd --reload 2>/dev/null || true
elif [[ "$PKG_MANAGER" == "apt-get" ]]; then
    apt_get install -y ufw
    ufw allow 22/tcp
    ufw allow $PORT_SSH/tcp
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow $PORT_ADMIN/tcp
    ufw allow $PORT_AGENT/tcp
    ufw --force enable
fi

# SSH port change
if [[ "$PORT_SSH" != "22" ]] && [[ "$SKIP_SSHD" != "1" ]]; then
    sed -i "s/^#*Port .*/Port $PORT_SSH/" /etc/ssh/sshd_config
    if command -v semanage &>/dev/null; then
        semanage port -a -t ssh_port_t -p tcp $PORT_SSH 2>/dev/null || true
    fi
    # Ubuntu 22.10+ uses ssh.socket activation: port comes from the socket unit
    if systemctl is-active --quiet ssh.socket 2>/dev/null; then
        mkdir -p /etc/systemd/system/ssh.socket.d
        printf "[Socket]\nListenStream=\nListenStream=%s\n" "$PORT_SSH" > /etc/systemd/system/ssh.socket.d/port.conf
        systemctl daemon-reload && systemctl restart ssh.socket
    fi
    systemctl reload sshd 2>/dev/null || systemctl reload ssh 2>/dev/null || true
fi

# ============================================================
# Fail2Ban
# ============================================================

echo -e "${CYAN}[3/12]${NC} Installing Fail2Ban..."
if [[ "$PKG_MANAGER" == "dnf" ]]; then
    dnf install -y fail2ban fail2ban-systemd
else
    apt_get install -y fail2ban python3-systemd
fi

cat > "/etc/fail2ban/jail.d/sshd.local" <<EOF
[sshd]
enabled = true
port = $PORT_SSH
backend = systemd
maxretry = 5
bantime = 3600
EOF

systemctl enable fail2ban
systemctl restart fail2ban || echo -e "${YELLOW}[WARN]${NC} fail2ban did not start"

# ============================================================
# Nginx
# ============================================================

echo -e "${CYAN}[4/12]${NC} Installing Nginx..."
if [[ "$PKG_MANAGER" == "dnf" ]]; then
    cat > "/etc/yum.repos.d/nginx.repo" <<EOF
[nginx-stable]
name=nginx stable repo
baseurl=http://nginx.org/packages/centos/\$releasever/\$basearch/
gpgcheck=1
enabled=1
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true
EOF
    dnf install -y nginx
else
    apt_get install -y nginx
fi

systemctl enable nginx
systemctl start nginx

# ============================================================
# PHP
# ============================================================

echo -e "${CYAN}[5/12]${NC} Installing PHP ${PHP_VER}..."
if [[ "$PKG_MANAGER" == "dnf" ]]; then
    dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-${OS_VERSION%%.*}.noarch.rpm 2>/dev/null || true
    dnf install -y yum-utils http://rpms.remirepo.net/enterprise/remi-release-${OS_VERSION%%.*}.rpm 2>/dev/null || true
    dnf module reset php -y 2>/dev/null || true
    dnf module enable php:remi-${PHP_VER} -y
    dnf module install php:remi-${PHP_VER} -y --allowerasing
    dnf install -y php-opcache php-fpm php-dom php-xml php-curl php-gd php-mbstring \
        php-mysqlnd php-bcmath php-zip php-json php-pecl-redis5 php-pecl-memcached \
        php-pecl-memcache php-soap php-pecl-zip 2>/dev/null
else
    if [[ "$OS_NAME" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php
    else
        curl -fsSL https://packages.sury.org/php/apt.gpg -o /usr/share/keyrings/sury-php.gpg
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] https://packages.sury.org/php/ $(lsb_release -sc) main" > /etc/apt/sources.list.d/sury-php.list
    fi
    apt_get update
    # php-fpm only: do NOT install the "phpX.Y" metapackage, it pulls in apache2
    apt_get install -y php${PHP_VER}-fpm php${PHP_VER}-cli php${PHP_VER}-common php${PHP_VER}-mysql \
        php${PHP_VER}-curl php${PHP_VER}-gd php${PHP_VER}-mbstring php${PHP_VER}-xml php${PHP_VER}-zip php${PHP_VER}-bcmath \
        php${PHP_VER}-opcache php${PHP_VER}-redis php${PHP_VER}-memcached php${PHP_VER}-soap php${PHP_VER}-intl
    # the CLI (wp-cli, cron, composer) must run the same PHP as the sites
    update-alternatives --set php "/usr/bin/php${PHP_VER}" >/dev/null 2>&1 || true
fi

# Hide PHP version
[[ -f "$PHP_INI" ]] && sed -i "s/expose_php = On/expose_php = Off/" "$PHP_INI"

systemctl enable "$PHP_FPM_SERVICE"
systemctl restart "$PHP_FPM_SERVICE"

# ============================================================
# MariaDB
# ============================================================

echo -e "${CYAN}[6/12]${NC} Installing MariaDB..."
if [[ "$PKG_MANAGER" == "dnf" ]]; then
    cat > /etc/yum.repos.d/mariadb.repo <<EOF
[mariadb]
name = MariaDB
baseurl = https://yum.mariadb.org/10.11/centos${OS_VERSION%%.*}-amd64
module_hotfixes=1
gpgkey=https://yum.mariadb.org/RPM-GPG-KEY-MariaDB
gpgcheck=1
EOF
    dnf makecache -y 2>/dev/null
    dnf install -y MariaDB-server MariaDB-client
else
    apt_get install -y mariadb-server mariadb-client
fi

systemctl enable mariadb
systemctl start mariadb

# Secure MariaDB
mysql <<EOF
USE mysql;
FLUSH PRIVILEGES;
CREATE USER IF NOT EXISTS 'admin'@'localhost' IDENTIFIED BY '$DB_ROOT_PASSWORD';
ALTER USER 'admin'@'localhost' IDENTIFIED BY '$DB_ROOT_PASSWORD';
GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
EOF

# ============================================================
# Cache (Memcached + Redis)
# ============================================================

echo -e "${CYAN}[7/12]${NC} Installing Redis$( [[ "$PROFILE" == "standard" ]] && echo " & Memcached")..."
CACHE_PKGS="redis-server"; [[ "$PKG_MANAGER" == "dnf" ]] && CACHE_PKGS="redis"
[[ "$PROFILE" == "standard" ]] && CACHE_PKGS="$CACHE_PKGS memcached"
if [[ "$PKG_MANAGER" == "dnf" ]]; then
    dnf -y install $CACHE_PKGS
else
    apt_get install -y $CACHE_PKGS
fi
if [[ "$PROFILE" == "lite" ]] && systemctl list-unit-files memcached.service >/dev/null 2>&1; then
    systemctl disable --now memcached 2>/dev/null || true
fi
systemctl enable "$REDIS_SERVICE"
systemctl start "$REDIS_SERVICE"
[[ "$PROFILE" == "standard" ]] && systemctl enable --now memcached

# ============================================================
# DKVPS Directory Structure
# ============================================================

echo -e "${CYAN}[8/12]${NC} Setting up DKVPS..."
mkdir -p /etc/dkvps/{user,cron/{backup,alert},nginx,ssl,backup/{db,source},menu}
mkdir -p /usr/share/nginx/dkvps/{passwd,backup/{db,source}}
mkdir -p /var/log/dkvps

touch /usr/share/nginx/dkvps/passwd/.htpasswd
chmod 755 /usr/share/nginx/dkvps/passwd/.htpasswd

# SFTP group
getent group sftp_users >/dev/null || groupadd sftp_users

# SFTP config
if [[ "$SKIP_SSHD" != "1" ]] && [[ -f /etc/ssh/sshd_config ]] && ! grep -q "Match Group sftp_users" /etc/ssh/sshd_config; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.dkvps.bak
    sed -i "/^\s*Subsystem/d" /etc/ssh/sshd_config
    cat >> "/etc/ssh/sshd_config" <<EOF
Subsystem sftp internal-sftp -u 022
Match Group sftp_users
 ChrootDirectory /home/%u
 ForceCommand internal-sftp
 AllowTcpForwarding no
 X11Forwarding no
EOF
    # validate before restarting so a typo can never lock us out
    if sshd -t; then
        systemctl restart sshd 2>/dev/null || systemctl restart ssh
    else
        echo -e "${RED}[ERROR]${NC} sshd config invalid, restoring backup"
        cp /etc/ssh/sshd_config.dkvps.bak /etc/ssh/sshd_config
    fi
fi

# ============================================================
# Nginx Configuration
# ============================================================

echo -e "${CYAN}[9/12]${NC} Configuring Nginx..."
PROCESS=$(grep -c ^processor /proc/cpuinfo)
MAX_CLIENT=$((1024 * PROCESS * 2))

# Global config
cat > "/etc/dkvps/nginx/global.conf" <<EOF
map \$http_accept \$webp_suffix {
    default "";
    "~*webp" ".webp";
}
EOF

# Fix PHP-FPM user
if [[ "$PKG_MANAGER" == "dnf" ]]; then
    sed -i "s/user = apache/user = nginx/" /etc/php-fpm.d/www.conf || true
    sed -i "s/group = apache/group = nginx/" /etc/php-fpm.d/www.conf || true
fi
# Ubuntu: remove the distro default vhost (we manage conf.d)
rm -f /etc/nginx/sites-enabled/default

# Nginx main config
cat > "/etc/nginx/nginx.conf" <<EOF
user $NGINX_USER;
worker_processes $PROCESS;
worker_rlimit_nofile 260000;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections $MAX_CLIENT;
    use epoll;
    multi_accept on;
}

http {
    log_format main '\$remote_addr - \$remote_user [\$time_local] "\$request" '
                    '\$status \$body_bytes_sent "\$http_referer" '
                    '"\$http_user_agent"';

    access_log off;

    add_header X-Frame-Options SAMEORIGIN;
    add_header X-XSS-Protection "1; mode=block";
    add_header X-Content-Type-Options nosniff;

    fastcgi_hide_header X-Powered-By;
    proxy_hide_header X-Powered-By;
    server_tokens off;

    sendfile on;
    tcp_nopush on;
    tcp_nodelay off;
    types_hash_max_size 2048;
    server_names_hash_bucket_size 128;
    client_max_body_size 256m;
    client_body_buffer_size 256k;
    keepalive_timeout 15;
    send_timeout 300s;

    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 2;
    gzip_min_length 256;
    gzip_types text/css text/javascript text/xml text/plain
               application/javascript application/json application/xml
               application/rss+xml image/svg+xml font/truetype font/opentype;

    include /etc/dkvps/nginx/global.conf;
    include /etc/nginx/conf.d/*.conf;
}
EOF

# SSL self-signed cert
mkdir -p /etc/nginx/ssl
openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
    -keyout /etc/nginx/ssl/nginx.key \
    -out /etc/nginx/ssl/nginx.crt \
    -subj "/C=VN/ST=DKVPS/L=DKVPS/O=DKVPS/CN=localhost" 2>/dev/null

[[ -f /etc/nginx/ssl/dhparam.pem ]] || openssl dhparam -dsaparam -out /etc/nginx/ssl/dhparam.pem 2048 2>/dev/null

# Default server config
cat > "/etc/nginx/conf.d/default.conf" <<EOF
server {
    listen 80 default_server;
    server_name _;
    return 404;
}

EOF
if [[ "$NGINX_HTTPS" == "1" ]]; then
cat >> "/etc/nginx/conf.d/default.conf" <<EOF

server {
    listen 443 ssl default_server;
    server_name _;
    ssl_certificate /etc/nginx/ssl/nginx.crt;
    ssl_certificate_key /etc/nginx/ssl/nginx.key;
    ssl_reject_handshake on;
}
EOF
fi

# Admin panel config
cat > "/etc/nginx/conf.d/admin.conf" <<EOF
server {
    listen $PORT_ADMIN;
    server_name dkvps;
    root /usr/share/nginx/dkvps;

    auth_basic "DKVPS Admin";
    auth_basic_user_file /usr/share/nginx/dkvps/passwd/.htpasswd;

    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_pass unix:$PHP_FPM_SOCK;
    }
}
EOF

# Admin htpasswd
htpasswd -bc /usr/share/nginx/dkvps/passwd/.htpasswd admin "$ADMIN_PASSWORD"

# ============================================================
# phpMyAdmin
# ============================================================

echo -e "${CYAN}[10/12]${NC} Installing phpMyAdmin..."
PMA_VERSION="5.2.2"
cd /usr/share/nginx/dkvps
if [[ ! -d phpmyadmin ]]; then
wget -q "https://files.phpmyadmin.net/phpMyAdmin/$PMA_VERSION/phpMyAdmin-$PMA_VERSION-all-languages.zip"
unzip -q "phpMyAdmin-$PMA_VERSION-all-languages.zip"
mv "phpMyAdmin-$PMA_VERSION-all-languages" phpmyadmin
rm -f "phpMyAdmin-$PMA_VERSION-all-languages.zip"
cp phpmyadmin/config.sample.inc.php phpmyadmin/config.inc.php
PMA_SECRET=$(openssl rand -base64 32)
echo "\$cfg['blowfish_secret'] = '$PMA_SECRET';" >> phpmyadmin/config.inc.php
echo "\$cfg['TempDir'] = '/var/lib/phpmyadmin/tmp';" >> phpmyadmin/config.inc.php
fi
mkdir -p /var/lib/phpmyadmin/tmp
chmod 700 /var/lib/phpmyadmin/tmp
chown -R "$NGINX_USER:$NGINX_USER" /usr/share/nginx/dkvps /var/lib/phpmyadmin
chown root:"$NGINX_USER" /usr/share/nginx/dkvps/passwd/.htpasswd
chmod 640 /usr/share/nginx/dkvps/passwd/.htpasswd
cd "$SCRIPT_DIR"

# ============================================================
# Install DKVPS CLI
# ============================================================

echo -e "${CYAN}[11/12]${NC} Installing DKVPS CLI..."

# Copy CLI scripts (symlink /usr/bin/dkvps so it finds core/ and modules/)
if [[ -d "$SCRIPT_DIR/cli" ]]; then
    cp -r "$SCRIPT_DIR/cli/"* /etc/dkvps/menu/
    find /etc/dkvps/menu -type f -exec chmod +x {} \;
    ln -sf /etc/dkvps/menu/dkvps /usr/bin/dkvps; ln -sf /etc/dkvps/menu/dkvps /usr/bin/myvps
else
    echo -e "${RED}[ERROR]${NC} cli/ not found next to install.sh - clone the full repo first"
    exit 1
fi

# WP-CLI
curl -sO https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
chmod +x wp-cli.phar
mv wp-cli.phar /usr/local/bin/wp

# rclone
command -v rclone >/dev/null || curl -s https://rclone.org/install.sh | bash || echo -e "${YELLOW}[WARN]${NC} rclone install failed"

# acme.sh (SSL)
if [[ ! -f /root/.acme.sh/acme.sh ]]; then
    curl -fsSL https://get.acme.sh | sh -s email="admin@$(hostname -f 2>/dev/null || hostname)" || echo -e "${YELLOW}[WARN]${NC} acme.sh install failed"
fi

# Node.js + DKVPS Agent (systemd service)
if ! command -v node >/dev/null || [[ "$(node -v | tr -d v | cut -d. -f1)" -lt 18 ]]; then
    if [[ "$PKG_MANAGER" == "apt-get" ]]; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
        apt_get install -y nodejs
    else
        curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
        dnf install -y nodejs
    fi
fi
mkdir -p /opt/dkvps
rm -rf /opt/dkvps/agent /opt/dkvps/dashboard
cp -r "$SCRIPT_DIR/agent" /opt/dkvps/agent
cp -r "$SCRIPT_DIR/dashboard" /opt/dkvps/dashboard
(cd /opt/dkvps/agent && npm install --omit=dev --no-audit --no-fund)
if [[ "$PROFILE" == "lite" ]]; then
# Lite: the agent is socket-activated by systemd and exits after 10 idle
# minutes, so it costs 0 MB until the dashboard or API actually connects.
cat > /etc/systemd/system/dkvps-agent.socket <<EOF
[Unit]
Description=DKVPS Agent API socket

[Socket]
ListenStream=$PORT_AGENT
NoDelay=true

[Install]
WantedBy=sockets.target
EOF
cat > /etc/systemd/system/dkvps-agent.service <<EOF
[Unit]
Description=DKVPS Agent API (socket activated)
Requires=dkvps-agent.socket
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/dkvps/agent
Environment=NODE_ENV=production
Environment=AGENT_PORT=$PORT_AGENT
Environment=AGENT_IDLE_EXIT=600
ExecStart=$(command -v node) --max-old-space-size=64 server.js
Restart=on-failure
RestartSec=3
MemoryMax=128M
OOMScoreAdjust=500
EOF
else
cat > /etc/systemd/system/dkvps-agent.service <<EOF
[Unit]
Description=DKVPS Agent API
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/dkvps/agent
Environment=NODE_ENV=production
Environment=AGENT_PORT=$PORT_AGENT
ExecStart=$(command -v node) server.js
Restart=always
RestartSec=3
MemoryMax=128M

[Install]
WantedBy=multi-user.target
EOF
fi

# ============================================================
# Save Configuration
# ============================================================

echo -e "${CYAN}[12/12]${NC} Saving configuration..."

AGENT_API_KEY=$(openssl rand -hex 32)
AGENT_SECRET=$(openssl rand -hex 32)
cat > "/etc/dkvps/.dkvps.conf" <<EOF
ip=$IP
version=$DKVPS_VERSION
port_ssh=$PORT_SSH
port_admin=$PORT_ADMIN
port_agent=$PORT_AGENT
db_admin_user=admin
db_admin_password=$DB_ROOT_PASSWORD
admin_password=$ADMIN_PASSWORD
agent_api_key=$AGENT_API_KEY
agent_secret=$AGENT_SECRET
timezone=Asia/Ho_Chi_Minh
php_default_version=$PHP_VER
profile=$PROFILE
EOF
chmod 600 /etc/dkvps/.dkvps.conf
systemctl daemon-reload
if [[ "$PROFILE" == "lite" ]]; then
    systemctl disable --now dkvps-agent.service 2>/dev/null || true
    systemctl enable --now dkvps-agent.socket
else
    systemctl disable --now dkvps-agent.socket 2>/dev/null || true
    systemctl enable --now dkvps-agent
    systemctl restart dkvps-agent
fi

# ============================================================
# Resource tuning (profile: lite | standard)
# ============================================================
if [[ "$PROFILE" == "lite" ]]; then
    INNODB_BUFFER="64M";  INNODB_LOG="32M"; DB_MAX_CONN=40;  DB_TABLE_CACHE=400
    PHP_MEMORY="128M";    OPCACHE_MEM=64;   OPCACHE_FILES=10000
    REDIS_MAXMEM="32mb";  WWW_MAX_CHILDREN=2
elif (( EFFECTIVE_RAM_MB <= 4096 )); then
    INNODB_BUFFER="384M"; INNODB_LOG="96M"; DB_MAX_CONN=100; DB_TABLE_CACHE=2000
    PHP_MEMORY="256M";    OPCACHE_MEM=128;  OPCACHE_FILES=20000
    REDIS_MAXMEM="128mb"; WWW_MAX_CHILDREN=4
else
    INNODB_BUFFER="1G";   INNODB_LOG="256M"; DB_MAX_CONN=200; DB_TABLE_CACHE=4000
    PHP_MEMORY="512M";    OPCACHE_MEM=256;  OPCACHE_FILES=40000
    REDIS_MAXMEM="256mb"; WWW_MAX_CHILDREN=8
fi

# MariaDB
if [[ -d /etc/mysql/mariadb.conf.d ]]; then DB_CNF=/etc/mysql/mariadb.conf.d/90-dkvps.cnf; else DB_CNF=/etc/my.cnf.d/90-dkvps.cnf; fi
mkdir -p "$(dirname "$DB_CNF")"
cat > "$DB_CNF" <<EOF
# DKVPS tuning (profile: $PROFILE)
[mysqld]
skip-name-resolve
performance_schema = OFF
max_connections = $DB_MAX_CONN
innodb_buffer_pool_size = $INNODB_BUFFER
innodb_log_file_size = $INNODB_LOG
innodb_log_buffer_size = 8M
innodb_flush_log_at_trx_commit = 2
innodb_flush_method = O_DIRECT
innodb_file_per_table = 1
table_open_cache = $DB_TABLE_CACHE
table_definition_cache = $DB_TABLE_CACHE
thread_cache_size = 8
tmp_table_size = 16M
max_heap_table_size = 16M
key_buffer_size = 8M
sort_buffer_size = 1M
join_buffer_size = 1M
read_rnd_buffer_size = 512K
EOF

# PHP: OPcache + per-user cache isolation
PHP_CONF_D_DIR="$(dirname "$PHP_INI")/conf.d"
mkdir -p "$PHP_CONF_D_DIR"
cat > "$PHP_CONF_D_DIR/90-dkvps.ini" <<EOF
; DKVPS tuning (profile: $PROFILE)
memory_limit = $PHP_MEMORY
expose_php = Off
opcache.enable = 1
opcache.memory_consumption = $OPCACHE_MEM
opcache.interned_strings_buffer = 8
opcache.max_accelerated_files = $OPCACHE_FILES
opcache.validate_timestamps = 1
opcache.revalidate_freq = 30
opcache.save_comments = 1
; pools run as different users: never serve one site's cached script to another
opcache.validate_permission = 1
opcache.validate_root = 1
realpath_cache_size = 1M
realpath_cache_ttl = 600
EOF
[[ "$PROFILE" == "lite" ]] && echo "opcache.jit = disable" >> "$PHP_CONF_D_DIR/90-dkvps.ini"

# Default "www" pool: only serves the admin panel, never keep idle workers
WWW_POOL="$(dirname "$PHP_INI")/pool.d/www.conf"
[[ "$PKG_MANAGER" == "dnf" ]] && WWW_POOL=/etc/php-fpm.d/www.conf
if [[ -f "$WWW_POOL" ]]; then
    sed -i -E "s/^pm = .*/pm = ondemand/; s/^pm.max_children = .*/pm.max_children = $WWW_MAX_CHILDREN/; s/^;?pm.process_idle_timeout = .*/pm.process_idle_timeout = 10s/" "$WWW_POOL"
fi

# Redis: capped LRU cache, no RDB snapshots on lite
REDIS_CONF=/etc/redis/redis.conf; [[ -f /etc/redis.conf ]] && REDIS_CONF=/etc/redis.conf
if [[ -f "$REDIS_CONF" ]]; then
    sed -i -E '/^# DKVPS/,$d' "$REDIS_CONF"
    {
        echo "# DKVPS tuning (profile: $PROFILE)"
        echo "maxmemory $REDIS_MAXMEM"
        echo "maxmemory-policy allkeys-lru"
        [[ "$PROFILE" == "lite" ]] && echo 'save ""'
    } >> "$REDIS_CONF"
    systemctl restart "$REDIS_SERVICE" 2>/dev/null || true
fi

# OOM priorities: under memory pressure the kernel kills a PHP worker,
# never the database, nginx or sshd.
for _svc in "$PHP_FPM_SERVICE:300" "mariadb:-600" "nginx:-500"; do
    _n="${_svc%%:*}"; _v="${_svc##*:}"
    mkdir -p "/etc/systemd/system/${_n}.service.d"
    printf '[Service]\nOOMScoreAdjust=%s\n' "$_v" > "/etc/systemd/system/${_n}.service.d/10-dkvps-oom.conf"
done
systemctl daemon-reload

# Swap (1GB) + VM tuning
if [[ ! -f /var/swap.1 ]] && [[ "$(awk '/SwapTotal/ {print $2}' /proc/meminfo)" -eq 0 ]]; then
    dd if=/dev/zero of=/var/swap.1 bs=1M count=1024 2>/dev/null
    chmod 600 /var/swap.1
    mkswap /var/swap.1
    swapon -p 10 /var/swap.1
    echo "/var/swap.1 none swap defaults,pri=10 0 0" >> /etc/fstab
fi
# Lite: compressed RAM swap (zram, 50% of RAM, zstd) in front of the swapfile.
# Skip with DKVPS_ZRAM=0 (e.g. inside containers that share the host kernel).
if [[ "$PROFILE" == "lite" && "${DKVPS_ZRAM:-1}" == "1" ]]; then
    /usr/bin/dkvps swap zram on 50 zstd >/dev/null 2>&1 || echo -e "${YELLOW}[WARN]${NC} zram not available, using swapfile only"
fi
# Lite: PackageKit (desktop software-center backend, D-Bus activated by apt
# hooks) only costs RAM on a server; apt keeps working without it.
if [[ "$PROFILE" == "lite" ]] && systemctl list-unit-files packagekit.service >/dev/null 2>&1; then
    systemctl stop packagekit >/dev/null 2>&1; systemctl mask packagekit >/dev/null 2>&1 || true
fi
cat > /etc/sysctl.d/90-dkvps.conf <<EOF
vm.swappiness = 10
vm.vfs_cache_pressure = 50
EOF
sysctl -p /etc/sysctl.d/90-dkvps.conf >/dev/null 2>&1 || true
[[ -f /etc/sysctl.d/91-dkvps-zram.conf ]] && { sysctl -p /etc/sysctl.d/91-dkvps-zram.conf >/dev/null 2>&1 || true; }

# Page cache dirs + purge worker (honours WordPress purge requests)
mkdir -p /var/cache/nginx/dkvps /etc/dkvps/nginx/sites
chown "$NGINX_USER": /var/cache/nginx/dkvps
cat > /etc/cron.d/dkvps-cache <<EOF
* * * * * root /usr/bin/dkvps domain purge-pending >/dev/null 2>&1
EOF
chmod 644 /etc/cron.d/dkvps-cache

# Setup cron
cat > /etc/dkvps/cron/backup/daily <<'EOF'
#!/bin/bash
# Daily backup - customize as needed
EOF
chmod +x /etc/dkvps/cron/backup/daily

(crontab -l 2>/dev/null; echo "0 2 * * * /etc/dkvps/cron/backup/daily >> /dev/null 2>&1") | sort -u | crontab -

# Shortcuts
grep -q "alias 0='dkvps'" /root/.bashrc 2>/dev/null || echo "alias 0='dkvps'" >> /root/.bashrc

# Restart services
bash -c 'source /etc/dkvps/menu/core/config.sh; source /etc/dkvps/menu/core/colors.sh; source /etc/dkvps/menu/core/functions.sh; source /etc/dkvps/menu/core/sitekit.sh; site_ensure_globals'
nginx -t
systemctl restart nginx "$PHP_FPM_SERVICE" mariadb

# ============================================================
# Watchdog: 1 s oneshot every minute, no daemon
/usr/bin/dkvps watch on >/dev/null 2>&1 || true
# Daily release check at SSH login (background, root only)
# no background update/license checks: `dkvps` checks when the user opens it
/usr/bin/dkvps guard on >/dev/null 2>&1 || true
[[ "${DKVPS_BROTLI:-1}" == 1 ]] && { /usr/bin/dkvps nginx brotli on >/dev/null 2>&1 || true; }

# Done!
# ============================================================

# login user for the summary: the sudo caller on cloud images (root login is usually off)
SSH_LOGIN_USER="${SUDO_USER:-root}"; [[ "$SSH_LOGIN_USER" == "root" ]] && [[ "$(sshd -T 2>/dev/null | awk '$1=="permitrootlogin"{print $2}')" == "no" ]] && SSH_LOGIN_USER=$(awk -F: '$3>=1000 && $3<60000 && $7 ~ /(ba|z)?sh$/ && system("test -s " $6 "/.ssh/authorized_keys")==0 {print $1; exit}' /etc/passwd 2>/dev/null)
SSH_LOGIN_USER="${SSH_LOGIN_USER:-root}"

[[ -t 1 ]] && clear
echo -e "${CYAN}=========================================================================${NC}"
echo -e "${GREEN}${BOLD}              DKVPS v${DKVPS_VERSION} - Installation Complete!${NC}"
echo -e "${CYAN}=========================================================================${NC}"
echo ""
echo -e "  1. SSH:              ${WHITE}ssh -p $PORT_SSH $SSH_LOGIN_USER@$IP${NC}"
echo -e "  2. IP:               ${WHITE}$IP${NC}"
echo -e "  3. Version:          ${WHITE}$DKVPS_VERSION${NC}"
echo -e "  4. SSH Port:         ${WHITE}$PORT_SSH${NC}"
echo -e "  5. phpMyAdmin:       ${WHITE}http://$IP:$PORT_ADMIN/phpmyadmin${NC}"
echo -e "  6. DB Admin User:    ${WHITE}admin${NC}"
echo -e "  7. DB Admin Pass:    ${WHITE}$DB_ROOT_PASSWORD${NC}"
echo -e "  8. Admin Login:      ${WHITE}admin${NC}"
echo -e "  9. Admin Password:   ${WHITE}$ADMIN_PASSWORD${NC}"
echo -e " 10. Agent URL:        ${WHITE}http://$IP:$PORT_AGENT${NC}"
echo -e " 11. Agent API Key:    ${WHITE}$AGENT_API_KEY${NC}"
echo ""
echo -e "${CYAN}------------------------------------------------------------------------${NC}"
echo -e "  Run ${WHITE}dkvps${NC} to open management menu."
echo -e "  Documentation: ${WHITE}https://github.com/huynhlongdai/dkvpsp${NC}"
echo -e "${CYAN}------------------------------------------------------------------------${NC}"
echo ""

# Save install info
cat > "/etc/dkvps/.info.conf" <<EOF
========================================================================
DKVPS v${DKVPS_VERSION} - Installation Info
========================================================================
SSH:              ssh -p $PORT_SSH $SSH_LOGIN_USER@$IP
IP:               $IP
SSH Port:         $PORT_SSH
phpMyAdmin:       http://$IP:$PORT_ADMIN/phpmyadmin
DB Admin User:    admin
DB Admin Pass:    $DB_ROOT_PASSWORD
Admin Login:      admin
Admin Password:   $ADMIN_PASSWORD
Agent URL:        http://$IP:$PORT_AGENT
Agent API Key:    $AGENT_API_KEY
------------------------------------------------------------------------
EOF
chmod 600 /etc/dkvps/.info.conf
