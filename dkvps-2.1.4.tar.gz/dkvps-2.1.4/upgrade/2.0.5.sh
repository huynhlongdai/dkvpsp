#!/bin/bash
# 2.0.5: Lite servers drop PackageKit (desktop backend, ~17 MB, re-spawned by apt)
set -u
p=$(grep -m1 '^profile=' /etc/dkvps/.dkvps.conf 2>/dev/null | cut -d= -f2)
if [[ "$p" == "lite" ]] && systemctl list-unit-files packagekit.service >/dev/null 2>&1; then
    systemctl stop packagekit >/dev/null 2>&1
    systemctl mask packagekit >/dev/null 2>&1 || true
fi
exit 0
