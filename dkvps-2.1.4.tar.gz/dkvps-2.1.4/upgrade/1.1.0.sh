#!/bin/bash
# 1.1.0: self-update support. Older installs get the daily login check and a release file.
set -e
[[ -f /etc/profile.d/dkvps-update.sh ]] || /usr/bin/dkvps update notify on >/dev/null
mkdir -p /var/lib/dkvps/update
exit 0
