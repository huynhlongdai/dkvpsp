#!/bin/bash
# 2.0.2: CLI php must match the sites' PHP-FPM (wp-cli, cron, composer)
set -u
v=$(grep -m1 '^php_default_version=' /etc/dkvps/.dkvps.conf 2>/dev/null | cut -d= -f2)
if [[ -n "$v" && -x "/usr/bin/php$v" ]] && command -v update-alternatives >/dev/null; then
    update-alternatives --set php "/usr/bin/php$v" >/dev/null 2>&1 || true
fi
exit 0
