#!/bin/bash
# 2.1.2: daily license + version check (feeds the menu banner)
/usr/bin/dkvps check cron >/dev/null 2>&1 || true
( /usr/bin/dkvps check -q >/dev/null 2>&1 & )
exit 0
