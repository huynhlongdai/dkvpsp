# Upgrade migrations

`dkvps update` runs `upgrade/X.Y.Z.sh` once for every release X.Y.Z newer than the
installed version and not newer than the target, in version order, as root, after the
new CLI/agent are in place. Env: `DKVPS_FROM`, `DKVPS_TO`. Exit non-zero = the update
is rolled back. Scripts must be idempotent (safe to run twice) and never touch user data.
