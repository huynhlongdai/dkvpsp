#!/bin/bash
# 2.1.0: swapfile priority -2 was silently clamped to auto (-1); use 10 (zram stays above at 100)
set -e
if grep -qE '^/var/swap.1 .*pri=-2' /etc/fstab 2>/dev/null; then
    sed -i -E '\#^/var/swap.1 # s/pri=-2/pri=10/' /etc/fstab
fi
exit 0
