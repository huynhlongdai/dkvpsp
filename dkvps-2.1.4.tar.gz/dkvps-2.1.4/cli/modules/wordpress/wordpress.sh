#!/bin/bash
#
# DKVPS - WordPress Management Module
# Uses WP-CLI for advanced management
#

wordpress_handler() {
    local action="$1"
    shift
    [[ "$action" != install && -n "${1:-}" && "$1" != -* ]] && export DKVPS_DOMAIN="$1"
    case "$action" in
        install)       wordpress_install "$@" ;;
        update)        wp_update_all "$@" ;;
        clear-cache)   wp_clear_cache "$@" ;;
        delete-spam)   wp_delete_spam "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown WordPress action: $action"
            fi
            wordpress_menu
            ;;
    esac
}

wordpress_menu() {
    echo ""
    print_subheader "WordPress Management"
    echo ""

    local options=(
        "Install WordPress"
        "Clear Cache (All Domains)"
        "Clear Cache (One Domain)"
        "Update All (Core + Theme + Plugin)"
        "Update WordPress Core"
        "Update Themes"
        "Update Plugins"
        "Delete Inactive Themes/Plugins"
        "Delete Draft/Trash/Revision Posts"
        "Delete Spam Comments"
        "Support WebP (Nginx)"
        "Move wp-config.php (Security)"
        "Disable File Edit in WP Dashboard"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}")  wordpress_install ;;
            "${options[1]}")  wp_clear_cache_all ;;
            "${options[2]}")  wp_clear_cache ;;
            "${options[3]}")  wp_update_all ;;
            "${options[4]}")  wp_update_core ;;
            "${options[5]}")  wp_update_themes ;;
            "${options[6]}")  wp_update_plugins ;;
            "${options[7]}")  wp_delete_inactive ;;
            "${options[8]}")  wp_delete_drafts ;;
            "${options[9]}")  wp_delete_spam ;;
            "${options[10]}") wp_webp_support ;;
            "${options[11]}") wp_move_config ;;
            "${options[12]}") wp_disable_file_edit ;;
            *) return ;;
        esac
    done
}

wordpress_install() {
    echo ""
    print_subheader "Install WordPress"
    echo ""

    local domain="${1:-}"
    if [[ -z "$domain" ]]; then choose_domain || return; domain="$SELECTED_DOMAIN"; fi
    local username=$(get_username "$domain")

    if ! domain_exists "$domain"; then
        print_error "Domain $domain not found."
        return 1
    fi
    local docroot="/home/$username/$domain/public_html"
    if [[ -f "$docroot/wp-config.php" || -f "$docroot/wp-settings.php" ]]; then
        print_error "WordPress is already installed on $domain."
        return 1
    fi
    if find "$docroot" -mindepth 1 -maxdepth 1 ! -name index.html ! -name '.well-known' | grep -q .; then
        print_warning "$docroot is not empty; its files will be deleted."
    fi
    confirm "Install WordPress (latest) for $domain?" || return

    load_config
    load_domain_config "$domain"
    local db_name="${username}_db" db_user="${username}_user" db_password; db_password=$(generate_password 32)
    if MYSQL_PWD="$db_admin_password" mysql -u "$db_admin_user" -e "USE \`$db_name\`" 2>/dev/null; then
        print_error "Database $db_name already exists; delete it first or use: dkvps domain add <new> --wp"; return 1
    fi
    MYSQL_PWD="$db_admin_password" mysql -u "$db_admin_user" -e "CREATE DATABASE \`$db_name\`; CREATE USER IF NOT EXISTS '$db_user'@'localhost' IDENTIFIED BY '$db_password'; ALTER USER '$db_user'@'localhost' IDENTIFIED BY '$db_password'; GRANT ALL PRIVILEGES ON \`$db_name\`.* TO '$db_user'@'localhost'; FLUSH PRIVILEGES;" \
        || { print_error "Could not create the database"; return 1; }

    find "$docroot" -mindepth 1 -maxdepth 1 ! -name '.well-known' -exec rm -rf {} +
    source "${CLI_DIR}/modules/domain/domain.sh"
    WP_ADMIN_USER=""; WP_ADMIN_PASS=""
    _install_wordpress "$domain" "$username" "$db_name" "$db_user" "$db_password" "$(openssl rand -hex 3)" || return 1

    local conf="$DKVPS_USER_DIR/.$domain.conf"
    set_config "db_name" "$db_name" "$conf"
    set_config "db_user" "$db_user" "$conf"
    set_config "db_password" "$db_password" "$conf"
    set_config "app" "wp" "$conf"
    set_config "fcgi_cache" "1" "$conf"
    if [[ -n "$WP_ADMIN_USER" ]]; then
        set_config "wp_admin_user" "$WP_ADMIN_USER" "$conf"
        set_config "wp_admin_password" "$WP_ADMIN_PASS" "$conf"
    fi
    site_apply "$domain" "$username" "wp"
    restart_php >/dev/null; reload_nginx >/dev/null

    print_line
    echo "  Domain:      http://$domain"
    echo "  DB Name:     $db_name"
    echo "  DB User:     $db_user"
    echo "  DB Password: $db_password"
    print_line
}

# WP-CLI helper
_wp_cli() {
    local domain="$1"
    shift
    local username=$(get_username "$domain")
    local path="/home/$username/$domain/public_html"

    if [[ ! -f /usr/local/bin/wp ]]; then
        print_error "WP-CLI not installed. Run: dkvps util install-wpcli"
        return 1
    fi

    # run as the site owner, so updates never leave root-owned files behind
    sudo -u "$username" HOME="/home/$username/$domain/tmp" wp --path="$path" "$@"
}

wp_clear_cache() {
    choose_domain || return
    _wp_cli "$SELECTED_DOMAIN" cache flush 2>/dev/null
    print_success "Cache cleared for $SELECTED_DOMAIN"
}

wp_clear_cache_all() {
    print_info "Clearing cache for all WordPress sites..."
    for entry in $(ls -A "$DKVPS_USER_DIR" 2>/dev/null); do
        local domain=$(echo "$entry" | sed 's/^\.//' | sed 's/\.conf$//')
        local username=$(get_username "$domain")
        if [[ -f "/home/$username/$domain/public_html/wp-config.php" ]]; then
            _wp_cli "$domain" cache flush 2>/dev/null
            print_success "Cache cleared: $domain"
        fi
    done
}

wp_update_all() {
    choose_domain || return
    local domain="$SELECTED_DOMAIN"
    _wp_cli "$domain" core update 2>/dev/null
    _wp_cli "$domain" theme update --all 2>/dev/null
    _wp_cli "$domain" plugin update --all 2>/dev/null
    print_success "WordPress updated for $domain"
}

wp_update_core() {
    choose_domain || return
    _wp_cli "$SELECTED_DOMAIN" core update 2>/dev/null
    print_success "WordPress core updated."
}

wp_update_themes() {
    choose_domain || return
    _wp_cli "$SELECTED_DOMAIN" theme update --all 2>/dev/null
    print_success "Themes updated."
}

wp_update_plugins() {
    choose_domain || return
    _wp_cli "$SELECTED_DOMAIN" plugin update --all 2>/dev/null
    print_success "Plugins updated."
}

wp_delete_inactive() {
    choose_domain || return
    local d="$SELECTED_DOMAIN" th pl
    th=$(_wp_cli "$d" theme list --status=inactive --field=name 2>/dev/null)
    pl=$(_wp_cli "$d" plugin list --status=inactive --field=name 2>/dev/null)
    [[ -n "$th" ]] && _wp_cli "$d" theme delete $th >/dev/null
    [[ -n "$pl" ]] && _wp_cli "$d" plugin delete $pl >/dev/null
    print_success "Deleted $(echo $th | wc -w) inactive themes, $(echo $pl | wc -w) inactive plugins."
}

wp_delete_drafts() {
    choose_domain || return
    local d="$SELECTED_DOMAIN" ids rev
    ids=$(_wp_cli "$d" post list --post_type=any --post_status=draft,trash,auto-draft --format=ids 2>/dev/null)
    [[ -n "$ids" ]] && _wp_cli "$d" post delete $ids --force >/dev/null
    rev=$(_wp_cli "$d" post list --post_type=revision --post_status=any --format=ids 2>/dev/null)
    [[ -n "$rev" ]] && _wp_cli "$d" post delete $rev --force >/dev/null
    print_success "Deleted $(echo $ids $rev | wc -w) draft/trash/revision posts."
}

wp_delete_spam() {
    choose_domain || return
    local d="$SELECTED_DOMAIN" ids
    ids=$(_wp_cli "$d" comment list --status=spam --format=ids 2>/dev/null)
    [[ -n "$ids" ]] && _wp_cli "$d" comment delete $ids --force >/dev/null
    print_success "Deleted $(echo $ids | wc -w) spam comments."
}

wp_webp_support() {
    print_info "WebP support: Add WebP mapping to Nginx global config."
    print_info "Already configured in /etc/dkvps/nginx/global.conf"
}

wp_move_config() {
    choose_domain || return
    local domain="$SELECTED_DOMAIN"
    local username=$(get_username "$domain")
    local src="/home/$username/$domain/public_html/wp-config.php"
    local dst="/home/$username/$domain/wp-config.php"

    if [[ -f "$src" ]]; then
        mv "$src" "$dst"
        chmod 0400 "$dst"
        print_success "wp-config.php moved outside public_html"
    else
        print_error "wp-config.php not found."
    fi
}

wp_disable_file_edit() {
    choose_domain || return
    local domain="$SELECTED_DOMAIN"
    local username=$(get_username "$domain")
    local config="/home/$username/$domain/public_html/wp-config.php"

    if [[ ! -f "$config" ]]; then
        config="/home/$username/$domain/wp-config.php"
    fi

    if [[ -f "$config" ]]; then
        if ! grep -q "DISALLOW_FILE_EDIT" "$config"; then
            sed -i "/<?php/a define('DISALLOW_FILE_EDIT', true);" "$config"
        fi
        if ! grep -q "DISALLOW_FILE_MODS" "$config"; then
            sed -i "/<?php/a define('DISALLOW_FILE_MODS', true);" "$config"
        fi
        print_success "File edit/mods disabled in WordPress."
    else
        print_error "wp-config.php not found."
    fi
}
