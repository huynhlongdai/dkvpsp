#!/bin/bash
#
# DKVPS - Laravel Management Module
#

laravel_handler() {
    local action="$1"
    shift
    case "$action" in
        install) laravel_install "$@" ;;
        clear)   laravel_clear_cache "$@" ;;
        public)  laravel_config_public "$@" ;;
        *) laravel_menu ;;
    esac
}

laravel_menu() {
    echo ""
    print_subheader "Laravel Management"
    echo ""

    local options=("Install Laravel" "Clear Cache" "Config Public Path" "Install Composer")
    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") laravel_install ;;
            "${options[1]}") laravel_clear_cache ;;
            "${options[2]}") laravel_config_public ;;
            "${options[3]}") laravel_install_composer ;;
            *) return ;;
        esac
    done
}

_laravel_pick() {   # [domain] -> SELECTED_DOMAIN
    if [[ -n "${1:-}" ]]; then domain_exists "$1" || { print_error "Domain $1 not found"; return 1; }; SELECTED_DOMAIN="$1"
    else choose_domain || return 1; fi
}

laravel_install() {
    # dkvps laravel install [domain] [--yes]
    local d="" a
    for a in "$@"; do case "$a" in -y|--yes) DKVPS_ASSUME_YES=1 ;; *) d="$a" ;; esac; done
    print_subheader "Install Laravel"
    _laravel_pick "$d" || return 1
    local domain="$SELECTED_DOMAIN" username; username=$(get_username "$domain")
    if [[ -f "/home/$username/$domain/public_html/artisan" ]]; then print_error "Laravel already installed on $domain"; return 1; fi
    confirm "Install Laravel (latest) for $domain? public_html must be empty" || return 0
    source "${CLI_DIR}/modules/domain/domain.sh"
    load_config
    local conf="$DKVPS_USER_DIR/.$domain.conf"
    local db_name db_user db_password
    db_name=$(site_get "$domain" db_name); db_user=$(site_get "$domain" db_user); db_password=$(site_get "$domain" db_password)
    if [[ -z "$db_name" ]]; then
        db_name="${username}_db"; db_user="${username}_user"; db_password=$(generate_password 32)
        MYSQL_PWD="$db_admin_password" mysql -u "$db_admin_user" -e "CREATE DATABASE IF NOT EXISTS \`$db_name\`; CREATE USER IF NOT EXISTS '$db_user'@'localhost' IDENTIFIED BY '$db_password'; GRANT ALL PRIVILEGES ON \`$db_name\`.* TO '$db_user'@'localhost'; FLUSH PRIVILEGES;" \
            || { print_error "Database could not be created"; return 1; }
        set_config db_name "$db_name" "$conf"; set_config db_user "$db_user" "$conf"; set_config db_password "$db_password" "$conf"
    fi
    _install_laravel "$domain" "$username" "$db_name" "$db_user" "$db_password" || return 1
    site_apply "$domain" "$username" laravel
    reload_nginx >/dev/null
    echo "  URL:      http://$domain"
    echo "  Database: $db_name (user $db_user, password in $conf)"
}

laravel_clear_cache() {
    _laravel_pick "${1:-}" || return 1
    local domain="$SELECTED_DOMAIN" username; username=$(get_username "$domain")
    local path="/home/$username/$domain/public_html"
    [[ -f "$path/artisan" ]] || { print_error "No Laravel app on $domain"; return 1; }
    local php="php${DKVPS_PHP_VERSION}"; command -v "$php" >/dev/null || php=php
    ( cd "$path" && sudo -u "$username" HOME="/home/$username/$domain/tmp" "$php" artisan optimize:clear ) || { print_error "artisan optimize:clear failed"; return 1; }
    print_success "Laravel cache cleared for $domain"
}

laravel_config_public() {
    _laravel_pick "${1:-}" || return 1
    local domain="$SELECTED_DOMAIN" username; username=$(get_username "$domain")
    set_config app laravel "$DKVPS_USER_DIR/.$domain.conf"
    site_apply "$domain" "$username" laravel && reload_nginx >/dev/null
    print_success "Nginx root set to public_html/public for $domain"
}

laravel_install_composer() {
    source "${CLI_DIR}/modules/domain/domain.sh"
    _laravel_composer
}
