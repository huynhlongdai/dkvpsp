#!/bin/bash
#
# DKVPS - check license + version (online)
#
#   dkvps check            refresh the license with the hub and look for a new DKVPS release
#   dkvps check -q         quiet (cron): only refreshes the cached state
#   dkvps --json check     {"version":{...},"license":{...}} for the Web UI / DKVPS Hub
#   dkvps check banner     one-line summary from the cached state (no network), used by the menu
#
# Exit: 0 all good, 10 update available, 20 license not valid, 30 both
# Cron /etc/cron.d/dkvps-check runs `dkvps check -q` once a day.
#

CHECK_CRON="${DKVPS_CHECK_CRON:-/etc/cron.d/dkvps-check}"

check_handler() {
    case "${1:-}" in
        banner) check_banner ;;
        cron)   check_cron_install; print_success "Daily check installed: $CHECK_CRON" ;;
        -q|--quiet|"") check_run "${1:-}" ;;
        *) sed -n '3,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; return 2 ;;
    esac
}

_chk_src() {
    source "${CLI_DIR}/modules/update/update.sh"
    source "${CLI_DIR}/modules/license/license.sh"
}

check_cron_install() {
    [[ -d "$(dirname "$CHECK_CRON")" ]] || return 0
    local bin; bin=$(command -v dkvps 2>/dev/null || echo /usr/bin/dkvps)
    local min=$(( $(cksum < /etc/machine-id 2>/dev/null | cut -d' ' -f1 || echo 7) % 60 ))
    printf '# DKVPS: daily license + new version check (cached for the menu banner)\n%d 5 * * * root %s check -q >/dev/null 2>&1\n' "$min" "$bin" > "$CHECK_CRON"
    chmod 644 "$CHECK_CRON"
}

check_run() {
    _chk_src
    local quiet=0; [[ "$1" == -q || "$1" == --quiet ]] && quiet=1
    local rc=0 cur latest="" upd="unknown" lic_state="none" lic_plan="" lic_until="" lic_msg=""

    # version
    cur=$(_upd_current)
    local out ur
    out=$(update_check -q 2>/dev/null); ur=$?
    case $ur in
        0)  upd="latest"; latest="$cur" ;;
        10) upd="available"; latest=$(cat "$DKVPS_UPD_STATE/available" 2>/dev/null); rc=$((rc + 10)) ;;
        *)  upd="unknown" ;;
    esac

    # license: ask the hub (refresh), fall back to the offline token
    local key; key=$(get_config key "$LICENSE_CONF" 2>/dev/null)
    if [[ -n "$key" ]]; then
        lic_msg=$(LICENSE_QUIET=1 license_refresh --quiet 2>&1 | sed 's/\x1b\[[0-9;]*m//g' | tail -1)
    fi
    local js; js=$(JSON_MODE=true license_status 2>/dev/null)
    lic_state=$(jq -r '.state // "none"' <<<"$js" 2>/dev/null); lic_state=${lic_state:-none}
    lic_plan=$(jq -r '.plan // empty' <<<"$js" 2>/dev/null)
    lic_until=$(jq -r '.valid_until // empty' <<<"$js" 2>/dev/null)
    [[ "$lic_state" == valid ]] || rc=$((rc + 20))
    mkdir -p "$DKVPS_UPD_STATE"; date +%s > "$DKVPS_UPD_STATE/checked"

    if [[ "${JSON_MODE:-false}" == true ]]; then
        jq -cn --arg cur "$cur" --arg latest "$latest" --arg upd "$upd" --argjson lic "${js:-null}" --arg msg "$lic_msg" \
            '{version:{current:$cur, latest:(if $latest=="" then null else $latest end), status:$upd, update_available:($upd=="available")},
              license:($lic + {message:(if $msg=="" then null else $msg end)})}'
        return $rc
    fi
    (( quiet )) && return $rc

    echo ""
    print_subheader "DKVPS check"
    echo ""
    case "$upd" in
        latest)    print_status_line "Version" "$cur (latest)" "$GREEN" ;;
        available) print_status_line "Version" "$cur -> $latest available" "$YELLOW" ;;
        *)         print_status_line "Version" "$cur (could not reach the release mirror)" "$YELLOW" ;;
    esac
    if [[ "$lic_state" == valid ]]; then
        print_status_line "License" "$lic_plan, valid until $(date -d "@$lic_until" '+%Y-%m-%d %H:%M')" "$GREEN"
    elif [[ -z "$key" ]]; then
        print_status_line "License" "not activated" "$YELLOW"
    else
        print_status_line "License" "$lic_state" "$RED"
    fi
    [[ -n "$lic_msg" && "$lic_state" != valid ]] && echo "  $lic_msg"
    echo ""
    [[ "$upd" == available ]] && print_info "Update: dkvps update  (menu: Update DKVPS)"
    [[ "$lic_state" != valid ]] && print_info "License: dkvps -> License  (or: dkvps license activate <KEY>)"
    return $rc
}

# one line from cached state only: never touches the network (menu draws it on every screen)
check_banner() {
    _chk_src
    local cur avail lic plan line
    cur=$(_upd_current); avail=$(cat "$DKVPS_UPD_STATE/available" 2>/dev/null)
    if [[ -n "$avail" ]] && _upd_newer "$avail" "$cur"; then
        line="Version: ${cur} ${YELLOW}(update ${avail} available)${NC}"
    else
        line="Version: ${cur}"
    fi
    if plan=$(license_plan 2>/dev/null); then
        line+=" | License: ${GREEN}${plan}${NC}"
    elif [[ -n "$(get_config key "$LICENSE_CONF" 2>/dev/null)" ]]; then
        line+=" | License: ${RED}invalid/expired${NC}"
    else
        line+=" | License: ${YELLOW}not activated${NC}"
    fi
    echo -e "  $line"
    # stale cache (>1 day): refresh in the background for next time
    local last; last=$(cat "$DKVPS_UPD_STATE/checked" 2>/dev/null || echo 0)
    if (( $(date +%s) - last > 86400 )); then
        ( "${CLI_DIR}/dkvps" check -q >/dev/null 2>&1 & ) 2>/dev/null
    fi
}
