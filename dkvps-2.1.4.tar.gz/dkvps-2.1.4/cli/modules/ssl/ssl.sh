#!/bin/bash
#
# DKVPS - SSL Management Module
#
#   dkvps ssl install <domain> [--provider letsencrypt|zerossl] [--dns cloudflare]
#                               [--wildcard] [--www|--no-www] [--redirect] [--staging] [--force]
#   dkvps ssl custom <domain> --cert <file> --key <file> [--chain <file>]
#   dkvps ssl list | check | renew <domain|--all> | delete <domain>
#   dkvps ssl redirect <domain> [on|off]      http -> https, only once the cert is valid
#   dkvps ssl hsts <domain> [on|off]          only for a trusted, non-expiring cert
#   dkvps ssl cloudflare <api_token|->        token for DNS-01 (wildcard, port 80 closed)
#   dkvps ssl provider [letsencrypt|zerossl]
#
# Certificates are ECDSA P-256 (cheaper TLS handshakes on 1 vCPU), kept in
# /home/<user>/<domain>/ssl owned by root (a compromised site cannot read its
# own private key), renewed by acme.sh's cron and audited daily by
# `dkvps ssl check`, which also re-adopts renewals of migrated sites and alerts.
#

ACME_HOME="/root/.acme.sh"
ACME="$ACME_HOME/acme.sh"
DKVPS_SSL_CONF_DIR=/etc/dkvps/ssl
DKVPS_CF_ENV="$DKVPS_SSL_CONF_DIR/cloudflare.env"
DKVPS_SSL_WARN_DAYS=14

ssl_handler() {
    local action="${1:-}"; shift 2>/dev/null
    case "$action" in
        install|create)  ssl_install "$@" ;;
        install-zerossl) ssl_install "$@" --provider zerossl ;;
        custom)          ssl_custom "$@" ;;
        delete|rm)       ssl_delete "$@" ;;
        renew)           ssl_renew "$@" ;;
        list|ls)         ssl_list "$@" ;;
        check)           ssl_check "$@" ;;
        redirect)        ssl_redirect "$@" ;;
        hsts)            ssl_hsts "$@" ;;
        cloudflare|cf)   ssl_cloudflare "$@" ;;
        provider)        ssl_provider "$@" ;;
        test)            ssl_install "$@" --staging ;;
        setup-acme)      ssl_setup_acme ;;
        "")              ssl_menu ;;
        *)               print_error "Unknown SSL action: $action"; ssl_usage; return 1 ;;
    esac
}

ssl_usage() {
    cat <<'EOF'
dkvps ssl install <domain> [--provider letsencrypt|zerossl] [--dns cloudflare] [--wildcard]
                           [--www|--no-www] [--redirect] [--staging] [--force]
dkvps ssl custom <domain> --cert <file> --key <file> [--chain <file>]
dkvps ssl list | check | renew <domain|--all> | delete <domain>
dkvps ssl redirect <domain> [on|off]   dkvps ssl hsts <domain> [on|off]
dkvps ssl cloudflare <api_token|->     dkvps ssl provider [letsencrypt|zerossl]
EOF
}

ssl_menu() {
    echo ""; print_subheader "SSL Management"; echo ""
    local options=("Install SSL (auto checks DNS)" "Install wildcard SSL (Cloudflare DNS)" "Install custom/paid SSL"
                   "List certificates" "Enable HTTPS redirect" "Enable HSTS" "Renew" "Delete SSL" "Cloudflare API token" "Default provider")
    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $REPLY in
            1) choose_domain && ssl_install "$SELECTED_DOMAIN" --redirect ;;
            2) choose_domain && ssl_install "$SELECTED_DOMAIN" --wildcard --redirect ;;
            3) choose_domain && { read -rp "Certificate (.crt): " c; read -rp "Private key (.key): " k; read -rp "CA bundle (optional): " b
                                  ssl_custom "$SELECTED_DOMAIN" --cert "$c" --key "$k" ${b:+--chain "$b"}; } ;;
            4) ssl_list ;;
            5) choose_domain && ssl_redirect "$SELECTED_DOMAIN" on ;;
            6) choose_domain && ssl_hsts "$SELECTED_DOMAIN" on ;;
            7) ssl_renew --all ;;
            8) choose_domain && ssl_delete "$SELECTED_DOMAIN" ;;
            9) read -rsp "Cloudflare API token (Zone:DNS:Edit): " t; echo; ssl_cloudflare "$t" ;;
            10) read -rp "letsencrypt or zerossl: " p; ssl_provider "$p" ;;
            *) return ;;
        esac
    done
}

# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------
_ssl_conf() { echo "$DKVPS_USER_DIR/.$1.conf"; }
_ssl_set()  { set_config "$2" "$3" "$(_ssl_conf "$1")"; }
_ssl_dir()  { echo "/home/$(get_username "$1")/$1/ssl"; }
_ssl_crt()  { echo "$(_ssl_dir "$1")/$1.fullchain.crt"; }
_ssl_key()  { echo "$(_ssl_dir "$1")/$1.key"; }

_ssl_adopt_pending() {   # acme state of migrated sites waiting for acme.sh
    [[ -d /root/.acme.sh.pending && -x "$ACME" ]] || return 0
    cp -a /root/.acme.sh.pending/. "$ACME_HOME"/ && rm -rf /root/.acme.sh.pending
}

ssl_setup_acme() {
    if [[ -x "$ACME" ]]; then _ssl_adopt_pending; return 0; fi
    print_info "Installing acme.sh..."
    local email="${ACME_EMAIL:-$(get_config admin_email)}"
    [[ "$email" == *@*.* ]] || email="admin@$(hostname -f 2>/dev/null | grep '\.' || echo dkvps.local)"
    local tmp; tmp=$(mktemp -d)
    if ! curl -fsSL --max-time 60 https://github.com/acmesh-official/acme.sh/archive/master.tar.gz | tar -xz -C "$tmp"; then
        rm -rf "$tmp"; print_error "Could not download acme.sh"; return 1
    fi
    (cd "$tmp"/acme.sh-master && HOME=/root ./acme.sh --install --home "$ACME_HOME" --accountemail "$email" >/dev/null 2>&1)
    rm -rf "$tmp"
    [[ -x "$ACME" ]] || { print_error "acme.sh install failed"; return 1; }
    "$ACME" --set-default-ca --server "$(get_config ssl_provider || true)" >/dev/null 2>&1 || "$ACME" --set-default-ca --server letsencrypt >/dev/null 2>&1
    "$ACME" --upgrade --auto-upgrade >/dev/null 2>&1 || true
    _ssl_adopt_pending
    print_success "acme.sh installed (renewals run from its own cron)"
}

_ssl_public_ip() {
    [[ -n "${_DKVPS_PUBIP:-}" ]] && { echo "$_DKVPS_PUBIP"; return; }
    local ip
    ip=$(curl -s4 --max-time 5 https://api.ipify.org 2>/dev/null || curl -s4 --max-time 5 https://ifconfig.me 2>/dev/null)
    [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || ip=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')
    _DKVPS_PUBIP="$ip"; echo "$ip"
}

# public A records (bypasses /etc/hosts): dig @1.1.1.1, then DNS-over-HTTPS
_ssl_resolve() {
    local n="$1" out=""
    if command -v dig >/dev/null 2>&1; then
        out=$(dig +short +time=3 +tries=1 A "$n" @1.1.1.1 2>/dev/null | grep -E '^[0-9.]+$')
    fi
    if [[ -z "$out" ]]; then
        out=$(curl -s --max-time 5 -H 'accept: application/dns-json' "https://cloudflare-dns.com/dns-query?name=$n&type=A" 2>/dev/null \
              | grep -oE '"data":"[0-9.]+"' | grep -oE '[0-9.]+')
    fi
    echo "$out"
}

_ip2int() { local IFS=.; read -r a b c d <<<"$1"; echo $(( (a<<24) + (b<<16) + (c<<8) + d )); }
_ssl_is_cloudflare_ip() {
    local ip; ip=$(_ip2int "$1") || return 1
    local r net bits
    for r in 173.245.48.0/20 103.21.244.0/22 103.22.200.0/22 103.31.4.0/22 141.101.64.0/18 108.162.192.0/18 \
             190.93.240.0/20 188.114.96.0/20 197.234.240.0/22 198.41.128.0/17 162.158.0.0/15 104.16.0.0/13 \
             104.24.0.0/14 172.64.0.0/13 131.0.72.0/22; do
        net=$(_ip2int "${r%/*}"); bits=${r#*/}
        (( (ip >> (32 - bits)) == (net >> (32 - bits)) )) && return 0
    done
    return 1
}

# where does <name> point? prints direct|cloudflare|elsewhere:<ip>|none
_ssl_dns_state() {
    local n="$1" me ips ip
    me=$(_ssl_public_ip); ips=$(_ssl_resolve "$n")
    [[ -z "$ips" ]] && { echo none; return; }
    for ip in $ips; do [[ "$ip" == "$me" ]] && { echo direct; return; }; done
    for ip in $ips; do _ssl_is_cloudflare_ip "$ip" && { echo cloudflare; return; }; done
    echo "elsewhere:$(echo $ips | tr ' ' ',')"
}

# can nginx serve an ACME token from this site's webroot?
_ssl_webroot_selftest() {
    local domain="$1" webroot="$2"
    local d="$webroot/.well-known/acme-challenge" t="dkvps-$RANDOM$RANDOM"
    mkdir -p "$d"; echo "$t" > "$d/$t"; chmod 0644 "$d/$t"
    local got; got=$(curl -s --max-time 5 --resolve "$domain:80:127.0.0.1" "http://$domain/.well-known/acme-challenge/$t" 2>/dev/null)
    rm -f "$d/$t"
    [[ "$got" == "$t" ]]
}

_ssl_cert_days() {   # days left, negative when expired, empty when no cert
    local f="$1" end
    [[ -f "$f" ]] || return 1
    end=$(openssl x509 -enddate -noout -in "$f" 2>/dev/null | cut -d= -f2) || return 1
    echo $(( ($(date -d "$end" +%s) - $(date +%s)) / 86400 ))
}

_ssl_cert_trusted() {  # signed by a CA in the system store (not staging, not self-signed)
    local f="$1"
    openssl verify -CAfile /etc/ssl/certs/ca-certificates.crt -untrusted "$f" "$f" >/dev/null 2>&1
}

_ssl_cert_covers() { openssl x509 -noout -checkhost "$2" -in "$1" 2>/dev/null | grep -q 'does match'; }

_ssl_acme_has() {     # acme.sh on THIS server knows how to renew <domain>
    [[ -f "$ACME_HOME/${1}_ecc/${1}.conf" || -f "$ACME_HOME/${1}/${1}.conf" ]]
}

# the cert nginx actually serves for <domain> on 127.0.0.1:443
_ssl_served_matches() {
    local domain="$1" want got
    want=$(openssl x509 -noout -fingerprint -sha256 -in "$(_ssl_crt "$domain")" 2>/dev/null)
    got=$(echo | timeout 8 openssl s_client -connect 127.0.0.1:443 -servername "$domain" 2>/dev/null | openssl x509 -noout -fingerprint -sha256 2>/dev/null)
    [[ -n "$want" && "$want" == "$got" ]]
}

_ssl_apply() {
    local domain="$1" username; username=$(get_username "$domain")
    local d; d=$(_ssl_dir "$domain")
    chown -R root:root "$d"; chmod 0700 "$d"; chmod 0600 "$d"/*.key 2>/dev/null
    load_domain_config "$domain"
    site_ensure_globals
    site_write_vhost "$domain" "$username" "${app:-}" || return 1
    reload_nginx >/dev/null 2>&1 || restart_nginx >/dev/null 2>&1
}

# ------------------------------------------------------------------
# install (ACME)
# ------------------------------------------------------------------
ssl_install() {
    local domain="" provider="" dns="" wildcard=0 www=auto redirect=0 staging=0 force=0 quiet=0
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --provider) provider="$2"; shift ;;
            --zerossl) provider=zerossl ;;
            --dns) dns="$2"; shift ;;
            --wildcard) wildcard=1 ;;
            --www) www=1 ;;
            --no-www) www=0 ;;
            --redirect) redirect=1 ;;
            --staging|--test) staging=1 ;;
            --force|-f) force=1 ;;
            --quiet) quiet=1 ;;
            -*) print_error "Unknown option $1"; return 1 ;;
            *) domain="$1" ;;
        esac
        shift
    done
    [[ -z "$domain" ]] && { choose_domain || return 1; domain="$SELECTED_DOMAIN"; }
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    provider="${provider:-$(get_config ssl_provider)}"; provider="${provider:-letsencrypt}"
    [[ "$provider" =~ ^(letsencrypt|zerossl)$ ]] || { print_error "Provider: letsencrypt or zerossl"; return 1; }
    [[ "$wildcard" == "1" && -z "$dns" ]] && dns=cloudflare
    [[ -z "$dns" || "$dns" == "cloudflare" ]] || { print_error "DNS provider supported: cloudflare"; return 1; }

    local username; username=$(get_username "$domain")
    local root="/home/$username/$domain" webroot="/home/$username/$domain/public_html"
    ssl_setup_acme || return 1

    # names: apex (+ www when it really points here) or apex + *.apex
    local names=("$domain") st
    if [[ "$wildcard" == "1" ]]; then
        names+=("*.$domain")
    else
        if [[ "$www" == "auto" ]]; then
            www=0
            if [[ "$(is_subdomain "$domain")" == "no" ]]; then
                st=$(_ssl_dns_state "www.$domain")
                [[ "$st" == direct || "$st" == cloudflare || -n "$dns" ]] && www=1
                [[ "$www" == "0" && "$quiet" == "0" ]] && print_info "www.$domain does not point here ($st), issuing for $domain only"
            fi
        fi
        [[ "$www" == "1" ]] && names+=("www.$domain")
    fi

    # pre-flight: never burn CA rate limits on a request that cannot pass
    if [[ -z "$dns" ]]; then
        st=$(_ssl_dns_state "$domain")
        case "$st" in
            direct) ;;
            cloudflare) [[ "$quiet" == "0" ]] && print_info "$domain is behind Cloudflare proxy (HTTP challenge passes through it)" ;;
            *)  if [[ "$force" != "1" ]]; then
                    print_error "$domain points to ${st#elsewhere:} but this server is $(_ssl_public_ip). Fix DNS, use --dns cloudflare, or --force."
                    return 1
                fi ;;
        esac
        if ! _ssl_webroot_selftest "$domain" "$webroot"; then
            print_error "nginx does not serve /.well-known/acme-challenge/ for $domain (check custom rules)"
            return 1
        fi
    else
        [[ -f "$DKVPS_CF_ENV" ]] || { print_error "Set a Cloudflare token first: dkvps ssl cloudflare <token>"; return 1; }
    fi

    local args=() n
    for n in "${names[@]}"; do args+=(-d "$n"); done
    # DKVPS_ACME_SERVER: another ACME directory (private CA, or pebble for tests)
    args+=(--keylength ec-256 --server "${DKVPS_ACME_SERVER:-$provider}")
    [[ "${DKVPS_ACME_INSECURE:-0}" == "1" ]] && args+=(--insecure)
    [[ "$staging" == "1" ]] && args+=(--staging)
    if [[ -n "$dns" ]]; then args+=(--dns dns_cf); else args+=(-w "$webroot"); fi

    local label="$provider"; [[ "$staging" == "1" ]] && label="$provider staging"
    [[ "$quiet" == "0" ]] && print_info "Requesting ${names[*]} from $label via ${dns:-http} challenge..."
    local out rc
    out=$( set -a; [[ -n "$dns" ]] && source "$DKVPS_CF_ENV"; set +a; "$ACME" --issue "${args[@]}" 2>&1 ); rc=$?
    if [[ $rc -ne 0 && $rc -ne 2 ]]; then   # 2 = still valid, nothing to do
        print_error "Certificate request failed for $domain:"
        echo "$out" | grep -iE "error|invalid|timeout|refused|rate|unauthorized|dns" | grep -v '^\s*$' | tail -5
        return 1
    fi

    local d="$root/ssl"; mkdir -p "$d"
    "$ACME" --install-cert -d "$domain" --ecc \
        --key-file "$d/$domain.key" --fullchain-file "$d/$domain.fullchain.crt" --cert-file "$d/$domain.crt" \
        --reloadcmd "nginx -t >/dev/null 2>&1 && systemctl reload nginx" >/dev/null 2>&1 \
        || { print_error "Could not install the certificate files"; return 1; }

    _ssl_set "$domain" ssl_mode acme
    _ssl_set "$domain" ssl_provider "$provider"
    _ssl_set "$domain" ssl_challenge "${dns:-http}"
    _ssl_set "$domain" ssl_names "$(IFS=,; echo "${names[*]}")"
    _ssl_set "$domain" ssl_staging "$staging"
    _ssl_apply "$domain" || return 1

    if ! _ssl_served_matches "$domain"; then
        print_error "nginx is not serving the new certificate for $domain"; return 1
    fi
    print_success "SSL active for ${names[*]} ($(_ssl_cert_days "$d/$domain.fullchain.crt") days, auto-renew on)"
    if [[ "$redirect" == "1" ]]; then
        if [[ "$staging" == "1" ]]; then print_warning "Staging certificate: HTTPS redirect not enabled"
        else ssl_redirect "$domain" on; fi
    fi
    [[ "$quiet" == "0" && "$staging" == "0" ]] && print_info "When https works for you: dkvps ssl hsts $domain on"
    return 0
}

# ------------------------------------------------------------------
# custom / paid certificate
# ------------------------------------------------------------------
ssl_custom() {
    local domain="" cert="" key="" chain=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --cert) cert="$2"; shift ;; --key) key="$2"; shift ;; --chain|--ca) chain="$2"; shift ;;
            *) domain="$1" ;;
        esac; shift
    done
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    [[ -f "$cert" && -f "$key" ]] || { print_error "Usage: dkvps ssl custom <domain> --cert <file> --key <file> [--chain <file>]"; return 1; }
    local cpub kpub
    cpub=$(openssl x509 -noout -pubkey -in "$cert" 2>/dev/null | sha256sum)
    kpub=$(openssl pkey -pubout -in "$key" 2>/dev/null | sha256sum)
    [[ -n "$cpub" && "$cpub" == "$kpub" ]] || { print_error "Certificate and private key do not match"; return 1; }
    _ssl_cert_covers "$cert" "$domain" || { print_error "Certificate is not valid for $domain"; return 1; }
    local days; days=$(_ssl_cert_days "$cert"); (( days > 0 )) || { print_error "Certificate is expired"; return 1; }
    local d; d=$(_ssl_dir "$domain"); mkdir -p "$d"
    _ssl_acme_has "$domain" && "$ACME" --remove -d "$domain" --ecc >/dev/null 2>&1
    cp "$key" "$d/$domain.key"; cp "$cert" "$d/$domain.crt"
    if [[ -f "$chain" ]]; then cat "$cert" "$chain" > "$d/$domain.fullchain.crt"; else cp "$cert" "$d/$domain.fullchain.crt"; fi
    _ssl_set "$domain" ssl_mode custom
    _ssl_apply "$domain" || return 1
    print_success "Custom SSL installed for $domain ($days days left; renewal is up to you, ssl check will warn)"
}

# ------------------------------------------------------------------
# redirect / HSTS: only on a certificate that will not break the site
# ------------------------------------------------------------------
ssl_redirect() {
    local domain="$1" state="${2:-on}"
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    if [[ "$state" == "on" ]]; then
        local c; c=$(_ssl_crt "$domain"); local days; days=$(_ssl_cert_days "$c" 2>/dev/null)
        [[ -n "$days" ]] || { print_error "$domain has no certificate"; return 1; }
        (( days > 0 )) || { print_error "Certificate of $domain is expired"; return 1; }
        _ssl_cert_covers "$c" "$domain" || { print_error "Certificate does not cover $domain"; return 1; }
        _ssl_set "$domain" ssl_redirect 1
    else
        _ssl_set "$domain" ssl_redirect 0; _ssl_set "$domain" ssl_hsts 0; _ssl_hsts_map
    fi
    _ssl_apply "$domain" && print_success "HTTPS redirect $state for $domain"
}

_ssl_hsts_map() {   # http-level map: SNI name -> HSTS value (empty = no header)
    local f=/etc/dkvps/nginx/hsts.map d
    : > "$f.tmp"
    for d in $(list_domain_configs); do
        if site_flag "$d" ssl_hsts; then
            printf '%s "max-age=31536000";\nwww.%s "max-age=31536000";\n' "$d" "$d" >> "$f.tmp"
        fi
    done
    mv "$f.tmp" "$f"
}

ssl_hsts() {
    local domain="$1" state="${2:-on}"
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    if [[ "$state" == "on" ]]; then
        local c; c=$(_ssl_crt "$domain")
        _ssl_cert_trusted "$c" || { print_error "HSTS needs a publicly trusted certificate (this one is staging/self-signed/broken)"; return 1; }
        local days; days=$(_ssl_cert_days "$c"); (( days >= DKVPS_SSL_WARN_DAYS )) || { print_error "Certificate expires in $days days, renew first"; return 1; }
        [[ "$(site_get "$domain" ssl_mode)" != "acme" || "$(_ssl_acme_has "$domain" && echo y)" == "y" ]] \
            || { print_error "Auto-renew is not set up on this server (run: dkvps ssl check)"; return 1; }
        site_flag "$domain" ssl_redirect || ssl_redirect "$domain" on || return 1
        _ssl_set "$domain" ssl_hsts 1
    else
        _ssl_set "$domain" ssl_hsts 0
    fi
    _ssl_hsts_map
    reload_nginx >/dev/null 2>&1
    if [[ "$state" == "on" ]]; then print_success "HSTS on for $domain (browsers will refuse plain http for 1 year)"
    else print_success "HSTS off for $domain (browsers that saw it keep it until max-age ends)"; fi
}

# ------------------------------------------------------------------
# status, renew, delete, daily audit
# ------------------------------------------------------------------
ssl_list() {
    printf '%-28s %-7s %-14s %-11s %5s  %-10s %-8s %s\n' DOMAIN MODE ISSUER EXPIRES DAYS RENEW REDIRECT HSTS
    local d c days iss exp renew mode
    for d in $(list_domain_configs); do
        c=$(_ssl_crt "$d"); mode=$(site_get "$d" ssl_mode)
        if [[ ! -f "$c" ]]; then printf '%-28s %-7s\n' "$d" none; continue; fi
        days=$(_ssl_cert_days "$c")
        iss=$(openssl x509 -noout -issuer -in "$c" 2>/dev/null | sed -n 's/.*O *= *\([^,]*\).*/\1/p' | cut -c1-14)
        exp=$(date -d "$(openssl x509 -enddate -noout -in "$c" | cut -d= -f2)" +%F)
        renew="-"
        if [[ "$mode" == "acme" ]]; then _ssl_acme_has "$d" && renew=auto || renew="MISSING"; fi
        [[ "$mode" == "custom" ]] && renew=manual
        printf '%-28s %-7s %-14s %-11s %5s  %-10s %-8s %s\n' "$d" "${mode:-files}" "${iss:-?}" "$exp" "$days" "$renew" \
            "$(site_flag "$d" ssl_redirect && echo on || echo off)" "$(site_flag "$d" ssl_hsts && echo on || echo off)"
    done
}

ssl_renew() {
    local target="${1:---all}"
    ssl_setup_acme || return 1
    if [[ "$target" == "--all" ]]; then
        "$ACME" --cron --home "$ACME_HOME" 2>&1 | grep -iE "renew|error|skip" | tail -20
    else
        "$ACME" --renew -d "$target" --ecc --force 2>&1 | tail -3
    fi
}

ssl_delete() {
    local domain="$1"
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    confirm "Delete SSL for $domain?" || return 0
    [[ -x "$ACME" ]] && { "$ACME" --remove -d "$domain" --ecc >/dev/null 2>&1; "$ACME" --remove -d "$domain" >/dev/null 2>&1; }
    rm -rf "$ACME_HOME/${domain}_ecc" "$ACME_HOME/${domain}"
    local d; d=$(_ssl_dir "$domain"); rm -f "$d/$domain".{key,crt,fullchain.crt}
    _ssl_set "$domain" ssl_mode none; _ssl_set "$domain" ssl_redirect 0; _ssl_set "$domain" ssl_hsts 0
    _ssl_hsts_map; _ssl_apply "$domain"
    print_success "SSL removed for $domain"
}

# Daily (cron): re-adopt renewals after a migration, retry failing renewals, alert
ssl_check() {
    local d c days mode problems=0
    for d in $(list_domain_configs); do
        c=$(_ssl_crt "$d"); [[ -f "$c" ]] || continue
        mode=$(site_get "$d" ssl_mode); days=$(_ssl_cert_days "$c")
        if [[ "$mode" == "acme" ]] && ! _ssl_acme_has "$d"; then
            # site came from another server: take over its renewal here once DNS points to us
            local opts=(--quiet) names; names=$(site_get "$d" ssl_names)
            [[ "$(site_get "$d" ssl_challenge)" == "cloudflare" ]] && opts+=(--dns cloudflare)
            [[ "$names" == *"*.$d"* ]] && opts+=(--wildcard)
            [[ "$names" == *"www.$d"* ]] && opts+=(--www) || opts+=(--no-www)
            [[ -n "$(site_get "$d" ssl_provider)" ]] && opts+=(--provider "$(site_get "$d" ssl_provider)")
            [[ "$(site_get "$d" ssl_staging)" == "1" ]] && opts+=(--staging)
            if ssl_install "$d" "${opts[@]}" >/tmp/dkvps-ssl-adopt.log 2>&1; then
                notify_send ok "SSL renewal for $d is now handled by this server"
                days=$(_ssl_cert_days "$c")
            else
                notify_send warn "SSL for $d: auto-renew not set up on this server yet ($(grep -m1 -E 'ERROR|points to' /tmp/dkvps-ssl-adopt.log | sed 's/\x1b\[[0-9;]*m//g'))"
                problems=$((problems+1))
            fi
        fi
        if (( days <= DKVPS_SSL_WARN_DAYS )); then
            [[ "$mode" == "acme" ]] && "$ACME" --renew -d "$d" --ecc --force >/dev/null 2>&1 && days=$(_ssl_cert_days "$c")
            if (( days <= 0 )); then notify_send crit "SSL for $d EXPIRED ($days days)"; problems=$((problems+1))
            elif (( days <= DKVPS_SSL_WARN_DAYS )); then notify_send warn "SSL for $d expires in $days days and did not renew"; problems=$((problems+1)); fi
        fi
    done
    [[ "$problems" == "0" ]] && print_success "All certificates OK" || print_warning "$problems certificate problem(s), see $DKVPS_ALERT_LOG"
    [[ "$problems" == "0" ]]
}

ssl_cloudflare() {
    local token="${1:-}"
    [[ "$token" == "-" ]] && read -r token
    [[ "$token" =~ ^[A-Za-z0-9_-]{30,}$ ]] || { print_error "Usage: dkvps ssl cloudflare <api_token|->  (token with Zone:DNS:Edit)"; return 1; }
    local ok; ok=$(printf 'header = "Authorization: Bearer %s"\n' "$token" | curl -s --max-time 10 -K - "${DKVPS_CF_API:-https://api.cloudflare.com/client/v4}/user/tokens/verify" | jq -r '.result.status // empty' 2>/dev/null | grep -x active)
    [[ -n "$ok" ]] || { print_error "Cloudflare rejected the token"; return 1; }
    mkdir -p "$DKVPS_SSL_CONF_DIR"; chmod 0700 "$DKVPS_SSL_CONF_DIR"
    (umask 077; printf 'CF_Token=%s\n' "$token" > "$DKVPS_CF_ENV")
    print_success "Cloudflare token saved (DNS-01 and wildcard certificates available)"
}

ssl_provider() {
    local p="${1:-}"
    if [[ -z "$p" ]]; then echo "Default provider: $(get_config ssl_provider || true)"; return; fi
    [[ "$p" =~ ^(letsencrypt|zerossl)$ ]] || { print_error "letsencrypt or zerossl"; return 1; }
    ssl_setup_acme || return 1
    "$ACME" --set-default-ca --server "$p" >/dev/null 2>&1
    set_config ssl_provider "$p"
    print_success "Default SSL provider: $p"
}
