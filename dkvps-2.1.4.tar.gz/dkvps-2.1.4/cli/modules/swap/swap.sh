#!/bin/bash
#
# DKVPS - Swap Management Module
#

swap_handler() {
    local action="$1"
    shift
    case "$action" in
        create) swap_create "$@" ;;
        delete) swap_delete "$@" ;;
        list)   swap_list ;;
        zram)   swap_zram "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown swap action: $action"
            fi
            swap_menu
            ;;
    esac
}

swap_menu() {
    echo ""
    print_subheader "Swap Management"
    echo ""
    echo "  Swap Total:     $(human_readable $(get_swap_total))"
    echo "  Swap Free:      $(human_readable $(get_swap_free))"
    echo "  Swappiness:     $(cat /proc/sys/vm/swappiness)"
    echo ""

    local options=("Create Swap" "Delete Swap" "Swap Info")
    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") swap_create ;;
            "${options[1]}") swap_delete ;;
            "${options[2]}") swap_list ;;
            *) return ;;
        esac
    done
}

swap_create() {
    local size_mb="${1:-}"
    if [[ -z "$size_mb" ]]; then
        read -p "Enter swap size in MB (e.g., 1024, 2048): " size_mb
    fi
    if ! [[ "$size_mb" =~ ^[0-9]+$ ]] || (( size_mb < 256 )); then
        print_error "Invalid swap size. Minimum 256 MB."; return 1
    fi
    local free_mb; free_mb=$(df -Pm /var | awk 'NR==2{print $4}')
    if (( size_mb + 1024 > free_mb )); then
        print_error "Not enough disk: ${free_mb} MB free on /var, need ${size_mb} MB + 1 GB headroom"; return 1
    fi
    if systemd-detect-virt -q --container 2>/dev/null && [[ "${DKVPS_SWAP_IN_CONTAINER:-0}" != "1" ]]; then
        # /proc/swaps and swapon act on the HOST kernel from a container (LXC/OpenVZ/docker)
        print_error "This server is a container ($(systemd-detect-virt --container)): swap belongs to the host, not changed here"; return 1
    fi

    # replacing a swapfile that is in use: its pages must fit in free RAM first
    if grep -q '^/var/swap.1 ' /proc/swaps; then
        local used_kb avail_kb
        used_kb=$(awk '$1=="/var/swap.1"{print $4}' /proc/swaps)
        avail_kb=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
        if (( used_kb > avail_kb - 102400 )); then
            print_error "Current swap holds $((used_kb/1024)) MB and only $((avail_kb/1024)) MB RAM is free: cannot swap off safely"; return 1
        fi
        swapoff /var/swap.1 || { print_error "swapoff failed"; return 1; }
    fi
    rm -f /var/swap.1

    print_info "Creating ${size_mb} MB swap..."
    if ! fallocate -l "${size_mb}M" /var/swap.1 2>/dev/null || ! mkswap /var/swap.1 >/dev/null 2>&1; then
        rm -f /var/swap.1   # btrfs/xfs-on-some-kernels: fallocated files are refused, write it out
        dd if=/dev/zero of=/var/swap.1 bs=1M count="$size_mb" status=none || { rm -f /var/swap.1; print_error "Could not write /var/swap.1"; return 1; }
        mkswap /var/swap.1 >/dev/null || { rm -f /var/swap.1; print_error "mkswap failed"; return 1; }
    fi
    chmod 600 /var/swap.1
    if ! swapon -p 10 /var/swap.1; then
        rm -f /var/swap.1; print_error "swapon refused (container or filesystem without swap support)"; return 1
    fi
    sed -i '\#^/var/swap.1 #d' /etc/fstab
    echo "/var/swap.1 none swap defaults,pri=10 0 0" >> /etc/fstab
    print_success "Swap created: ${size_mb} MB ($(awk '$1=="/var/swap.1"{print $3/1024}' /proc/swaps) MB active)"
}

swap_delete() {
    [[ "${1:-}" == "--yes" || "${1:-}" == "-y" ]] && DKVPS_ASSUME_YES=1
    [[ -f /var/swap.1 ]] || { print_info "No swap file /var/swap.1"; return 0; }
    if systemd-detect-virt -q --container 2>/dev/null && [[ "${DKVPS_SWAP_IN_CONTAINER:-0}" != "1" ]]; then
        print_error "This server is a container: swap belongs to the host, not changed here"; return 1
    fi
    confirm "Delete swap file?" || return 0
    if grep -q '^/var/swap.1 ' /proc/swaps; then
        local used_kb avail_kb
        used_kb=$(awk '$1=="/var/swap.1"{print $4}' /proc/swaps); avail_kb=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
        (( used_kb > avail_kb - 102400 )) && { print_error "Swap holds $((used_kb/1024)) MB, not enough free RAM to take it back"; return 1; }
        swapoff /var/swap.1 || { print_error "swapoff failed"; return 1; }
    fi
    rm -f /var/swap.1
    sed -i '\#^/var/swap.1 #d' /etc/fstab
    print_success "Swap deleted."
}

swap_list() {
    echo ""
    print_subheader "Swap Info"
    echo ""
    swapon --show 2>/dev/null || cat /proc/swaps
    echo ""
    free -h | head -1
    free -h | grep -i swap
}

# ------------------------------------------------------------------
# zram: compressed swap in RAM. On a 1 GB VPS, cold PHP/MariaDB pages are
# compressed ~3:1 instead of hitting the disk, so it behaves like ~1.5-2 GB
# without the latency of a swapfile. The swapfile stays as a lower-priority
# safety net (pri 10 vs zram pri 100).
#   dkvps swap zram on [percent=50] [algo=zstd] | off | status
# ------------------------------------------------------------------
swap_zram() {
    local op="${1:-status}" pct="${2:-50}" algo="${3:-zstd}"
    case "$op" in
        on|enable)
            [[ "$pct" =~ ^[0-9]+$ ]] && (( pct >= 10 && pct <= 150 )) || { print_error "percent must be 10-150"; return 1; }
            if ! modprobe zram 2>/dev/null; then
                # no zram module: fall back to zswap (built into most kernels),
                # which compresses pages in RAM in front of the swapfile
                if [[ -w /sys/module/zswap/parameters/enabled ]]; then
                    echo zstd > /sys/module/zswap/parameters/compressor 2>/dev/null || true
                    echo 25 > /sys/module/zswap/parameters/max_pool_percent
                    echo Y > /sys/module/zswap/parameters/enabled
                    grep -q "zswap.enabled" /etc/default/grub 2>/dev/null || \
                        sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT="/&zswap.enabled=1 zswap.compressor=zstd zswap.max_pool_percent=25 /' /etc/default/grub 2>/dev/null
                    command -v update-grub >/dev/null && update-grub >/dev/null 2>&1
                    print_success "zram unavailable; enabled zswap (zstd, 25% pool) in front of the swapfile"
                    return 0
                fi
                print_error "Kernel has neither zram nor zswap (OpenVZ/LXC?). Keep the swapfile."; return 1
            fi
            mkdir -p /etc/dkvps/tools
            cat > /etc/dkvps/tools/zram.sh <<'EOF'
#!/bin/bash
# DKVPS zram swap helper: zram.sh start <percent> <algo> | stop
set -u
dev_file=/run/dkvps-zram.dev
case "${1:-}" in
  start)
    pct="${2:-50}"; algo="${3:-zstd}"
    modprobe zram || exit 1
    mem_kb=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    size=$(( mem_kb * pct / 100 ))K
    grep -qw "$algo" /sys/block/zram0/comp_algorithm 2>/dev/null || algo=lz4
    dev=$(zramctl --find --size "$size" --algorithm "$algo") || exit 1
    echo "$dev" > "$dev_file"
    mkswap "$dev" >/dev/null && swapon -p 100 "$dev"
    ;;
  stop)
    [[ -f "$dev_file" ]] || exit 0
    dev=$(cat "$dev_file")
    swapoff "$dev" 2>/dev/null; zramctl --reset "$dev" 2>/dev/null; rm -f "$dev_file"
    ;;
esac
EOF
            chmod 755 /etc/dkvps/tools/zram.sh
            cat > /etc/systemd/system/dkvps-zram.service <<EOF
[Unit]
Description=DKVPS compressed RAM swap (zram)
After=local-fs.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/etc/dkvps/tools/zram.sh start $pct $algo
ExecStop=/etc/dkvps/tools/zram.sh stop

[Install]
WantedBy=multi-user.target
EOF
            # with fast in-RAM swap the kernel should prefer swapping cold anon
            # pages over dropping file cache; page-cluster 0 = no readahead
            cat > /etc/sysctl.d/91-dkvps-zram.conf <<EOF
vm.swappiness = 100
vm.page-cluster = 0
EOF
            sysctl -p /etc/sysctl.d/91-dkvps-zram.conf >/dev/null 2>&1
            systemctl daemon-reload
            systemctl stop dkvps-zram 2>/dev/null
            systemctl enable --now dkvps-zram >/dev/null 2>&1 || { print_error "zram start failed: journalctl -u dkvps-zram"; return 1; }
            print_success "zram swap on: ${pct}% of RAM, $algo, priority 100"
            swapon --show ;;
        off|disable)
            systemctl disable --now dkvps-zram >/dev/null 2>&1
            rm -f /etc/systemd/system/dkvps-zram.service /etc/sysctl.d/91-dkvps-zram.conf
            sysctl -w vm.swappiness=10 vm.page-cluster=3 >/dev/null 2>&1
            systemctl daemon-reload
            print_success "zram swap off" ;;
        status)
            zramctl 2>/dev/null || echo "zram: not available"
            swapon --show
            echo "swappiness=$(cat /proc/sys/vm/swappiness) page-cluster=$(cat /proc/sys/vm/page-cluster)" ;;
        *) print_error "Usage: dkvps swap zram on [percent] [algo]|off|status"; return 1 ;;
    esac
}
