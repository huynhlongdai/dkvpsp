#!/bin/bash
#
# DKVPS - SSH/SFTP Management Module
#

ssh_handler() {
    local action="$1"
    shift
    case "$action" in
        port)     ssh_change_port "$@" ;;
        password) ssh_change_password "$@" ;;
        sftp)     ssh_change_sftp_password "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown SSH action: $action"
            fi
            ssh_menu
            ;;
    esac
}

ssh_menu() {
    load_config
    echo ""
    print_subheader "SSH/SFTP Management"
    echo ""
    echo "  SSH Port: ${port_ssh:-22}"
    echo "  SSHD:     $(service_status sshd)"
    echo ""

    local options=(
        "Change SSH/SFTP Port"
        "Change Root Password"
        "Change SFTP User Password"
        "View Failed Login Attempts"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") ssh_change_port ;;
            "${options[1]}") ssh_change_password ;;
            "${options[2]}") ssh_change_sftp_password ;;
            "${options[3]}") ssh_login_failed ;;
            *) return ;;
        esac
    done
}

ssh_change_port() {
    local new_port="${1:-}"
    load_config
    command -v sshd >/dev/null 2>&1 && [[ -f /etc/ssh/sshd_config ]] || { print_error "OpenSSH server is not installed on this machine"; return 1; }
    local old_port; old_port=$(sshd -T 2>/dev/null | awk '$1=="port"{print $2; exit}'); old_port="${old_port:-${port_ssh:-22}}"

    echo ""
    echo "Current SSH port: $old_port"
    if [[ -z "$new_port" ]]; then
        read -p "Enter new SSH port: " new_port
    fi

    if ! [[ "$new_port" =~ ^[0-9]+$ ]] || (( new_port < 1 || new_port > 65535 )); then
        print_error "Invalid port number."; return 1
    fi
    [[ "$new_port" == "$old_port" ]] && { print_info "SSH already on port $new_port"; return 0; }
    if ss -ltnH 2>/dev/null | awk '{print $4}' | grep -qE "[:.]$new_port\$"; then
        print_error "Port $new_port is already used by another service"; return 1
    fi

    # back up every file that may set Port (Debian/Ubuntu cloud images put it in sshd_config.d)
    local bak; bak=$(mktemp -d)
    cp -a /etc/ssh/sshd_config "$bak/"
    [[ -d /etc/ssh/sshd_config.d ]] && cp -a /etc/ssh/sshd_config.d "$bak/"
    _ssh_restore() { cp -a "$bak/sshd_config" /etc/ssh/sshd_config; [[ -d "$bak/sshd_config.d" ]] && { rm -rf /etc/ssh/sshd_config.d; cp -a "$bak/sshd_config.d" /etc/ssh/; }; }

    # drop-ins are read first and the first Port wins, so set it there and nowhere else
    local f
    for f in /etc/ssh/sshd_config.d/*.conf; do [[ -f "$f" ]] && sed -i -E '/^[[:space:]]*Port[[:space:]]/d' "$f"; done
    sed -i -E 's/^[[:space:]]*Port[[:space:]].*/#&/' /etc/ssh/sshd_config
    if grep -qE '^[[:space:]]*Include[[:space:]]+/etc/ssh/sshd_config.d' /etc/ssh/sshd_config; then
        echo "Port $new_port" > /etc/ssh/sshd_config.d/00-dkvps-port.conf
    else
        sed -i "1i Port $new_port" /etc/ssh/sshd_config
    fi

    if ! sshd -t 2>/tmp/sshd-t.err || [[ "$(sshd -T 2>/dev/null | awk '$1=="port"{print $2; exit}')" != "$new_port" ]]; then
        print_error "sshd config test failed, nothing changed: $(head -1 /tmp/sshd-t.err)"
        _ssh_restore; rm -rf "$bak"; return 1
    fi

    command -v semanage &>/dev/null && semanage port -a -t ssh_port_t -p tcp "$new_port" 2>/dev/null
    firewall_open_port "$new_port"

    if systemctl is-active --quiet ssh.socket 2>/dev/null; then
        systemctl daemon-reload; systemctl restart ssh.socket
    else
        systemctl reload "$SSH_SERVICE" 2>/dev/null || systemctl restart "$SSH_SERVICE"
    fi
    local i; for i in 1 2 3 4 5; do ss -ltnH | awk '{print $4}' | grep -qE "[:.]$new_port\$" && break; sleep 1; done
    if ! ss -ltnH | awk '{print $4}' | grep -qE "[:.]$new_port\$"; then
        print_error "sshd did not start listening on $new_port, rolled back to $old_port"
        _ssh_restore
        if systemctl is-active --quiet ssh.socket 2>/dev/null; then systemctl daemon-reload; systemctl restart ssh.socket
        else systemctl reload "$SSH_SERVICE" 2>/dev/null || systemctl restart "$SSH_SERVICE"; fi
        rm -rf "$bak"; return 1
    fi
    rm -rf "$bak"; unset -f _ssh_restore

    # fail2ban must watch the new port
    if [[ -f /etc/fail2ban/jail.d/sshd.local ]]; then
        sed -i -E "s/^port *=.*/port = $new_port/" /etc/fail2ban/jail.d/sshd.local
        systemctl reload fail2ban 2>/dev/null || systemctl restart fail2ban 2>/dev/null
    fi

    set_config "port_ssh" "$new_port"
    print_success "SSH port changed $old_port -> $new_port (old port still open in the firewall)"
    print_warning "Test now in a NEW terminal: ssh -p $new_port user@${ip:-$(get_public_ip)}"
    print_warning "When it works, close the old port: dkvps firewall close $old_port"
}

ssh_change_password() {
    echo ""
    print_info "Changing root password..."
    passwd root
}

ssh_change_sftp_password() {
    choose_domain || return
    local domain="$SELECTED_DOMAIN"
    local username=$(get_username "$domain")

    echo ""
    print_info "Changing SFTP password for user: $username"
    local new_password=$(generate_password 32)
    echo "$username:$new_password" | chpasswd

    set_config "password_sftp" "$new_password" "$DKVPS_USER_DIR/.$domain.conf"

    print_success "SFTP password changed for $username"
    echo "  New Password: $new_password"
}

ssh_login_failed() {
    echo ""
    print_subheader "Failed Login Attempts"
    echo ""

    local src
    if [[ -f /var/log/secure ]]; then src="cat /var/log/secure"
    elif [[ -f /var/log/auth.log ]]; then src="cat /var/log/auth.log"
    else src="journalctl -q --no-pager -t sshd -t sshd-session --since -7days"; fi
    echo "Failed attempts by IP (last 7 days):"
    $src 2>/dev/null | grep -E "Failed password|Invalid user|authentication failure" \
        | grep -oE "from [0-9a-fA-F:.]+" | awk '{print $2}' | sort | uniq -c | sort -rn | head -20
    echo ""
    echo "Last successful logins:"
    if command -v last >/dev/null 2>&1; then last -n 10 2>/dev/null | grep -v "^$"
    elif command -v wtmpdb >/dev/null 2>&1; then wtmpdb last -n 10 2>/dev/null
    else $src 2>/dev/null | grep "Accepted" | tail -10; fi
}
