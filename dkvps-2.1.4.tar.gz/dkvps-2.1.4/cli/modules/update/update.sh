#!/bin/bash
#
# DKVPS self-update
#
#   dkvps update              download latest release, verify sha256, apply, auto-rollback on failure
#   dkvps update check        is a newer release on the mirror? (exit 10 = yes)
#   dkvps update to X.Y.Z     install a specific release (up or down)
#   dkvps update rollback     restore the version that was running before the last update
#   dkvps update notify on|off  daily check at SSH login (default on, costs nothing between checks)
#   dkvps update system       apt/dnf upgrade of the OS packages
#
# Mirror layout (built by scripts/release.sh):
#   <mirror>/get.sh  <mirror>/latest ("X.Y.Z <sha256>")  <mirror>/dkvps-X.Y.Z.tar.gz(.sha256)
#
# What gets replaced: /etc/dkvps/menu (CLI), /opt/dkvps/agent, /opt/dkvps/dashboard.
# What never gets touched: /etc/dkvps/*.conf, domains, sites, DBs, certs, secrets.
# Version-specific migrations live in <release>/upgrade/X.Y.Z.sh and run once, in order.

DKVPS_UPD_STATE=/var/lib/dkvps/update
DKVPS_RELEASE_CONF=/etc/dkvps/release

_upd_conf() { sed -n "s/^$1=//p" "$DKVPS_RELEASE_CONF" 2>/dev/null | head -1; }
_upd_mirror() { local m="${DKVPS_MIRROR:-$(_upd_conf mirror)}"; echo "${m%/}"; }
_upd_current() {
    local v; v=$(cat /etc/dkvps/menu/VERSION 2>/dev/null)
    [[ -n "$v" ]] || v=$(sed -n 's/^version=//p' /etc/dkvps/.dkvps.conf 2>/dev/null | head -1)
    echo "${v:-0.0.0}"
}
_upd_fetch() { curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 15 ${DKVPS_TOKEN:+-H "Authorization: Bearer $DKVPS_TOKEN"} "$1" -o "$2"; }
_upd_newer() { [[ "$1" != "$2" && "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -1)" == "$1" ]]; }

# latest -> "X.Y.Z sha"
# (messages go to stderr: callers capture stdout)
_upd_latest() {
    local m; m=$(_upd_mirror)
    [[ -n "$m" ]] || { print_error >&2 "No mirror configured (/etc/dkvps/release or DKVPS_MIRROR)"; return 1; }
    local f; f=$(mktemp)
    if ! _upd_fetch "$m/latest" "$f"; then rm -f "$f"; print_error >&2 "Cannot reach $m/latest"; return 1; fi
    local v s; read -r v s < "$f"; rm -f "$f"
    [[ "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ && "$s" =~ ^[0-9a-f]{64}$ ]] || { print_error >&2 "Malformed release index on mirror"; return 1; }
    echo "$v $s"
}

# download + verify + unpack into /opt/dkvps/releases/<v>; prints the dir
_upd_download() {
    local v="$1" sum="$2" m tmp dest
    m=$(_upd_mirror); tmp=$(mktemp -d)
    if [[ -z "$sum" ]]; then
        _upd_fetch "$m/dkvps-$v.tar.gz.sha256" "$tmp/sum" || { rm -rf "$tmp"; print_error >&2 "Release $v not on mirror"; return 1; }
        read -r sum _ < "$tmp/sum"
    fi
    _upd_fetch "$m/dkvps-$v.tar.gz" "$tmp/a.tgz" || { rm -rf "$tmp"; print_error >&2 "Download failed"; return 1; }
    echo "$sum  $tmp/a.tgz" | sha256sum -c --quiet - >/dev/null 2>&1 || { rm -rf "$tmp"; print_error >&2 "Checksum mismatch: refusing"; return 1; }
    dest=/opt/dkvps/releases/$v
    rm -rf "$dest.new"; mkdir -p "$dest.new"
    tar -xzf "$tmp/a.tgz" -C "$dest.new" --strip-components=1 --no-same-owner
    rm -rf "$tmp"
    [[ -f "$dest.new/cli/dkvps" ]] || { rm -rf "$dest.new"; print_error >&2 "Archive incomplete"; return 1; }
    rm -rf "$dest"; mv "$dest.new" "$dest"
    echo "$dest"
}

_upd_restart_services() {
    systemctl daemon-reload
    if systemctl is-enabled -q dkvps-agent.socket 2>/dev/null; then
        systemctl stop dkvps-agent.service 2>/dev/null || true   # next connection starts the new code
    elif systemctl is-enabled -q dkvps-agent.service 2>/dev/null; then
        systemctl restart dkvps-agent.service
    fi
    systemctl is-active -q dkvps-bot 2>/dev/null && systemctl restart dkvps-bot
    return 0
}

# snapshot of the running version; promoted to prev.* only when the update succeeds,
# so a failed update never overwrites what `dkvps update rollback` restores
_upd_snapshot() {
    mkdir -p "$DKVPS_UPD_STATE"
    tar -czf "$DKVPS_UPD_STATE/pending.tar.gz" -C / etc/dkvps/menu opt/dkvps/agent opt/dkvps/dashboard 2>/dev/null
    _upd_current > "$DKVPS_UPD_STATE/pending.version"
}
_upd_promote_snapshot() {
    mv -f "$DKVPS_UPD_STATE/pending.tar.gz" "$DKVPS_UPD_STATE/prev.tar.gz"
    mv -f "$DKVPS_UPD_STATE/pending.version" "$DKVPS_UPD_STATE/prev.version"
}

_upd_restore_snapshot() {
    local which="${1:-prev}"
    [[ -f "$DKVPS_UPD_STATE/$which.tar.gz" ]] || { print_error "No previous version saved"; return 1; }
    local t; t=$(mktemp -d)
    tar -xzf "$DKVPS_UPD_STATE/$which.tar.gz" -C "$t"
    _upd_swap_dir "$t/etc/dkvps/menu" /etc/dkvps/menu
    _upd_swap_dir "$t/opt/dkvps/agent" /opt/dkvps/agent
    _upd_swap_dir "$t/opt/dkvps/dashboard" /opt/dkvps/dashboard
    rm -rf "$t"
    local pv; pv=$(cat "$DKVPS_UPD_STATE/$which.version" 2>/dev/null)
    [[ -n "$pv" ]] && sed -i "s/^version=.*/version=$pv/" /etc/dkvps/.dkvps.conf
    _upd_restart_services
}

# atomic-ish directory swap: running bash/node keep their open inodes
_upd_swap_dir() {
    local src="$1" dst="$2"
    [[ -d "$src" ]] || return 0
    rm -rf "$dst.new" "$dst.old"
    cp -a "$src" "$dst.new"
    [[ -d "$dst" ]] && mv "$dst" "$dst.old"
    mv "$dst.new" "$dst"
    rm -rf "$dst.old"
}

# Apply an unpacked release dir. Runs from the NEW code (get.sh / update re-exec here).
_upd_apply() {
    local src="$1" from to staged rc=0
    from=$(_upd_current); to=$(cat "$src/cli/VERSION")
    print_info "Applying DKVPS $from -> $to"

    # 1) syntax-check every shell file before touching anything
    local bad=0 f
    while IFS= read -r -d '' f; do
        bash -n "$f" 2>/dev/null || { print_error "Syntax error in ${f#$src/}"; bad=1; }
    done < <(find "$src/cli" -type f \( -name '*.sh' -o -name dkvps \) -print0)
    (( bad )) && { print_error "Release rejected, nothing changed"; return 1; }

    _upd_snapshot

    # 2) stage agent (npm only when dependencies changed)
    staged=$(mktemp -d /opt/dkvps/.stage.XXXX)
    cp -a "$src/agent" "$staged/agent"
    rm -rf "$staged/agent/node_modules"
    if [[ -d /opt/dkvps/agent/node_modules ]] && cmp -s "$src/agent/package.json" /opt/dkvps/agent/package.json \
        && { [[ ! -f "$src/agent/package-lock.json" ]] || cmp -s "$src/agent/package-lock.json" /opt/dkvps/agent/package-lock.json; }; then
        cp -a /opt/dkvps/agent/node_modules "$staged/agent/"
    else
        print_info "Agent dependencies changed: npm install"
        (cd "$staged/agent" && npm install --omit=dev --no-audit --no-fund --loglevel=error) || rc=1
    fi
    if (( rc )); then rm -rf "$staged"; print_error "npm install failed, nothing changed"; return 1; fi

    # 3) swap
    mkdir -p "$staged/menu" && cp -a "$src/cli/." "$staged/menu/"
    find "$staged/menu" -type f -exec chmod 755 {} \;
    _upd_swap_dir "$staged/menu" /etc/dkvps/menu
    _upd_swap_dir "$staged/agent" /opt/dkvps/agent
    _upd_swap_dir "$src/dashboard" /opt/dkvps/dashboard
    rm -rf "$staged"
    ln -sf /etc/dkvps/menu/dkvps /usr/bin/dkvps; ln -sf /etc/dkvps/menu/dkvps /usr/bin/myvps

    # 4) migrations: upgrade/X.Y.Z.sh for from < X.Y.Z <= to
    if [[ -d "$src/upgrade" ]]; then
        local h hv
        for h in $(ls "$src/upgrade"/*.sh 2>/dev/null | sort -V); do
            hv=$(basename "$h" .sh)
            _upd_newer "$hv" "$from" || continue
            _upd_newer "$hv" "$to" && continue
            print_info "Migration $hv"
            if ! DKVPS_FROM="$from" DKVPS_TO="$to" bash "$h"; then rc=1; print_error "Migration $hv failed"; break; fi
        done
    fi

    # 5) post-checks, else roll back
    if (( rc == 0 )); then
        /usr/bin/dkvps version >/dev/null 2>&1 || { rc=1; print_error "New CLI does not start"; }
        if command -v nginx >/dev/null && ! nginx -t >/dev/null 2>&1; then rc=1; print_error "nginx -t fails after update"; fi
    fi
    if (( rc )); then
        print_warning "Rolling back to $from"
        _upd_restore_snapshot pending
        rm -f "$DKVPS_UPD_STATE"/pending.*
        nginx -t >/dev/null 2>&1 && systemctl reload nginx 2>/dev/null
        return 1
    fi

    _upd_promote_snapshot
    sed -i "s/^version=.*/version=$to/" /etc/dkvps/.dkvps.conf
    printf 'mirror=%s\nrelease=%s\n' "$(_upd_mirror)" "$to" > "$DKVPS_RELEASE_CONF"
    rm -f "$DKVPS_UPD_STATE/available"
    _upd_restart_services
    systemctl reload nginx 2>/dev/null || true
    ls -1d /opt/dkvps/releases/*/ 2>/dev/null | sort -V | head -n -3 | xargs -r rm -rf
    print_success "DKVPS updated: $from -> $to"
}

# changelog sections for versions in (from, to]
_upd_changelog() {
    local from="$1" to="$2" f line v show=0
    f=$(mktemp)
    if ! _upd_fetch "$(_upd_mirror)/CHANGELOG.md" "$f" 2>/dev/null; then rm -f "$f"; echo "    (no changelog on the mirror)"; return 0; fi
    while IFS= read -r line; do
        if [[ "$line" =~ ^##[[:space:]]+([0-9]+\.[0-9]+\.[0-9]+) ]]; then
            v=${BASH_REMATCH[1]}; show=0
            if _upd_newer "$to" "$from"; then _upd_newer "$v" "$from" && ! _upd_newer "$v" "$to" && show=1
            else [[ "$v" == "$to" ]] && show=1; fi
        fi
        (( show )) && echo "    $line"
    done < "$f"
    rm -f "$f"
}

# what an update would do; never changes anything
update_preview() {
    local cur="$1" want="$2"
    echo ""
    if _upd_newer "$cur" "$want"; then
        print_warning "Update preview: DKVPS $cur -> $want (DOWNGRADE)"
    else
        print_info "Update preview: DKVPS $cur -> $want"
    fi
    _upd_changelog "$cur" "$want"
    echo "    Sites, databases and settings are kept; a snapshot is taken and restored automatically if checks fail."
    echo ""
}

# ask before updating. Yes without asking only with -y / DKVPS_YES=1.
_upd_confirm() {
    local cur="$1" want="$2" ans
    [[ "${DKVPS_YES:-0}" == 1 ]] && return 0
    if [[ ! -t 0 ]]; then
        print_error "Not confirmed: run in a terminal or add -y (dkvps update -y)"; return 1
    fi
    read -r -p "Update DKVPS $cur -> $want now? [y/N] " ans
    [[ "$ans" =~ ^[Yy] ]] && return 0
    print_info "Update cancelled. Nothing was changed."; return 1
}

# OS packages: list what would be upgraded, then ask (never automatic)
update_system() {
    local list n
    print_info "Checking OS packages..."
    if command -v apt-get >/dev/null; then
        DEBIAN_FRONTEND=noninteractive apt-get update -qq >/dev/null 2>&1 || true
        list=$(apt list --upgradable 2>/dev/null | sed -n 's|^\([^/]*\)/[^ ]* \([^ ]*\) [^ ]* \[upgradable from: \([^]]*\)\]|\1 \3 -> \2|p')
    else
        list=$(dnf -q check-update 2>/dev/null | awk 'NF==3 && $1 !~ /^(Obsoleting|Security)/ {print $1" -> "$2}')
    fi
    n=$(grep -c . <<<"$list")
    if (( n == 0 )); then print_success "All OS packages are up to date"; return 0; fi
    echo ""
    echo "  $n package(s) would be upgraded:"
    head -n 60 <<<"$list" | sed 's/^/    /'
    (( n > 60 )) && echo "    ... and $((n - 60)) more"
    echo ""
    [[ "${DKVPS_PREVIEW_ONLY:-0}" == 1 ]] && { echo "Preview only: nothing was changed."; return 0; }
    if [[ "${DKVPS_YES:-0}" != 1 ]]; then
        [[ -t 0 ]] || { print_error "Not confirmed: run in a terminal or add -y"; return 1; }
        local ans; read -r -p "Upgrade these $n package(s) now? [y/N] " ans
        [[ "$ans" =~ ^[Yy] ]] || { print_info "Cancelled. Nothing was changed."; return 1; }
    fi
    if command -v apt-get >/dev/null; then DEBIAN_FRONTEND=noninteractive apt-get upgrade -y; else dnf update -y; fi
}

update_check() {
    local quiet="${1:-}" cur lv
    cur=$(_upd_current)
    lv=$(_upd_latest) || return 1
    lv=${lv%% *}
    mkdir -p "$DKVPS_UPD_STATE"; date +%s > "$DKVPS_UPD_STATE/checked"
    if _upd_newer "$lv" "$cur"; then
        echo "$lv" > "$DKVPS_UPD_STATE/available"
        if [[ "$quiet" != -q ]]; then
            echo "Update available: $cur -> $lv"
            _upd_changelog "$cur" "$lv"
            echo "Nothing was changed. To update: dkvps update"
        fi
        return 10
    fi
    rm -f "$DKVPS_UPD_STATE/available"
    [[ "$quiet" == -q ]] || echo "DKVPS $cur is up to date"
    return 0
}

update_to() {
    local want="$1" sum="" dir cur lv
    cur=$(_upd_current)
    if [[ -z "$want" ]]; then
        lv=$(_upd_latest) || return 1
        want=${lv%% *}; sum=${lv##* }
        if ! _upd_newer "$want" "$cur" && [[ "${DKVPS_FORCE:-0}" != 1 ]]; then
            print_success "DKVPS $cur is already the latest"; return 0
        fi
    fi
    [[ "$want" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { print_error "Bad version: $want"; return 1; }
    if [[ "$want" == "$cur" && "${DKVPS_FORCE:-0}" != 1 ]]; then print_success "DKVPS $cur is already installed"; return 0; fi
    update_preview "$cur" "$want"
    [[ "${DKVPS_PREVIEW_ONLY:-0}" == 1 ]] && { echo "Preview only: nothing was changed."; return 0; }
    _upd_confirm "$cur" "$want" || return 1
    exec 9>/run/dkvps-get.lock; flock -n 9 || { print_error "Another install/update is running"; return 1; }
    print_info "Downloading DKVPS $want"
    dir=$(_upd_download "$want" "$sum") || return 1
    # let the new release apply itself (new migrations / new apply logic)
    exec bash "$dir/cli/dkvps" update --from "$dir"
}

update_notify() {
    case "$1" in
        on)
            cat > /etc/profile.d/dkvps-update.sh <<'EOF'
# DKVPS: once a day, check for a new release in the background at login (root only)
if [ "$(id -u)" = 0 ] && [ -t 1 ] && command -v dkvps >/dev/null 2>&1; then
    _m=/var/lib/dkvps/update
    if [ -s "$_m/available" ]; then
        printf '\033[1;33mDKVPS %s is available.\033[0m Run: dkvps update\n' "$(cat "$_m/available")"
    fi
    if [ ! -f "$_m/checked" ] || [ $(( $(date +%s) - $(cat "$_m/checked" 2>/dev/null || echo 0) )) -gt 86400 ]; then
        (dkvps update check -q >/dev/null 2>&1 &)
    fi
    unset _m
fi
EOF
            chmod 644 /etc/profile.d/dkvps-update.sh
            print_success "Daily update check at login: on" ;;
        off) rm -f /etc/profile.d/dkvps-update.sh; print_success "Daily update check at login: off" ;;
        *) echo "Usage: dkvps update notify on|off"; return 2 ;;
    esac
}

update_handler() {
    # -y / --yes anywhere: confirm the update without asking
    local a args=()
    for a in "$@"; do case "$a" in -y|--yes) export DKVPS_YES=1 ;; *) args+=("$a") ;; esac; done
    set -- "${args[@]}"
    local action="${1:-}"; shift 2>/dev/null || true
    case "$action" in
        "")         require_root; update_to "" ;;
        --from)     require_root; _upd_apply "${1:?release dir}" ;;
        check)      update_check "${1:-}" ;;
        preview)    DKVPS_PREVIEW_ONLY=1 update_to "${1:-}" ;;
        to)         require_root; update_to "${1:?Usage: dkvps update to X.Y.Z}" ;;
        rollback)   require_root
                    local pv; pv=$(cat "$DKVPS_UPD_STATE/prev.version" 2>/dev/null)
                    _upd_restore_snapshot && print_success "Rolled back to ${pv:-previous version}" ;;
        notify)     require_root; update_notify "$1" ;;
        system)     require_root; update_system ;;
        phpmyadmin|pma) require_root; source "${CLI_DIR}/modules/monitor/monitor.sh"; pma_update ;;
        menu)       source "${CLI_DIR}/modules/monitor/monitor.sh"; update_dkvps ;;
        *)          echo "Usage: dkvps update [-y] [check [-q] | preview [X.Y.Z] | to X.Y.Z | rollback | notify on|off | system | phpmyadmin]"; return 2 ;;
    esac
}
