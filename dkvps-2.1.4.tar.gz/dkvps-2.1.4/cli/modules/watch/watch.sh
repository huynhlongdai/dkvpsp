#!/bin/bash
#
# DKVPS - watchdog: health checks + auto-heal, no daemon
#
#   dkvps watch on|off|status     systemd timer, every minute (a ~1 s oneshot)
#   dkvps watch run               one pass (what the timer runs)
#
# Each pass: restarts dead services (nginx only after nginx -t), probes every
# site locally and restarts its PHP pool / app after 2 failed probes in a row,
# watches disk, RAM and load. Alerts (log + Telegram) only when a state changes,
# so a site that stays down sends one message, then one when it is back.
#

WATCH_STATE=/var/lib/dkvps/watch

watch_handler() {
    case "${1:-status}" in
        on)  watch_on ;;
        off) systemctl disable --now dkvps-watch.timer >/dev/null 2>&1; print_success "Watchdog off" ;;
        run) watch_run ;;
        status|*)
            echo "timer: $(systemctl is-active dkvps-watch.timer 2>/dev/null)"
            ls "$WATCH_STATE" 2>/dev/null | while read -r k; do printf '  %-40s %s\n' "$k" "$(cat "$WATCH_STATE/$k")"; done
            echo "recent:"; grep -h "watch" "$DKVPS_ALERT_LOG" 2>/dev/null | tail -5 ;;
    esac
}

watch_on() {
    cat > /etc/systemd/system/dkvps-watch.service <<'EOF'
[Unit]
Description=DKVPS watchdog pass

[Service]
Type=oneshot
ExecStart=/usr/bin/dkvps watch run
Nice=10
IOSchedulingClass=idle
MemoryMax=64M
TimeoutStartSec=50
EOF
    cat > /etc/systemd/system/dkvps-watch.timer <<'EOF'
[Unit]
Description=DKVPS watchdog every minute

[Timer]
OnBootSec=2min
OnUnitActiveSec=60s
AccuracySec=5s

[Install]
WantedBy=timers.target
EOF
    systemctl daemon-reload
    systemctl enable --now dkvps-watch.timer >/dev/null 2>&1
    print_success "Watchdog on (every minute: services, sites, disk, RAM)"
}

# _wstate <key> <ok|bad...> <alert level> <message when bad> <message when ok>
_wstate() {
    local key="$1" st="$2" lvl="$3" bad="$4" good="$5" f="$WATCH_STATE/$1" old
    old=$(cat "$f" 2>/dev/null || echo ok)
    echo "$st" > "$f"
    if [[ "$st" != ok && "$old" == ok ]]; then notify_send "$lvl" "watch: $bad"
    elif [[ "$st" == ok && "$old" != ok ]]; then notify_send ok "watch: $good"; fi
}

_watch_service() {   # unit [pretest cmd]
    local u="$1"
    systemctl is-enabled --quiet "$u" 2>/dev/null || return 0
    if systemctl is-active --quiet "$u"; then _wstate "svc-$u" ok info "" "$u running again"; return 0; fi
    if [[ "$u" == nginx* ]] && ! nginx -t >/dev/null 2>&1; then
        _wstate "svc-$u" badconf crit "$u is down and its config is invalid: $(nginx -t 2>&1 | grep -m1 emerg)" "$u running again"
        return 1
    fi
    systemctl restart "$u" 2>/dev/null; sleep 2
    if systemctl is-active --quiet "$u"; then
        notify_send warn "watch: $u was down, restarted it"
        _wstate "svc-$u" ok info "" ""
    else
        _wstate "svc-$u" down crit "$u is down and would not restart" "$u running again"
    fi
}

_watch_site() {
    local d="$1" app code f="$WATCH_STATE/fail-$d" n
    [[ -f "/etc/nginx/conf.d/$d.conf" ]] || return 0          # suspended
    app=$(site_get "$d" app)
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -H "Host: $d" -H "User-Agent: dkvps-watch" http://127.0.0.1/ 2>/dev/null)
    if [[ "$code" =~ ^[1-4][0-9][0-9]$ ]]; then
        rm -f "$f"; _wstate "site-$d" ok info "" "$d is back (HTTP $code)"; return 0
    fi
    n=$(( $(cat "$f" 2>/dev/null || echo 0) + 1 )); echo "$n" > "$f"
    (( n < 2 )) && return 0
    if (( n == 2 )); then   # heal once, then just report
        if [[ "$app" =~ ^(node|bun|python)$ ]]; then systemctl restart "dkvps-app-$d" 2>/dev/null
        elif [[ "$code" =~ ^(502|503|504|000)$ ]]; then
            if systemctl is-enabled --quiet "dkvps-fpm@$d" 2>/dev/null; then systemctl restart "dkvps-fpm@$d"
            else systemctl reload "${PHP_FPM_SERVICE:-php-fpm}" 2>/dev/null; fi
        fi
        sleep 3
        code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 -H "Host: $d" http://127.0.0.1/ 2>/dev/null)
        if [[ "$code" =~ ^[1-4][0-9][0-9]$ ]]; then
            rm -f "$f"; notify_send warn "watch: $d returned errors, restarted its ${app:-php} process, now HTTP $code"; return 0
        fi
    fi
    _wstate "site-$d" "http-$code" crit "$d is down (HTTP $code), auto-restart did not help" "$d is back"
}

watch_run() {
    mkdir -p "$WATCH_STATE"
    exec 8>/run/dkvps-watch.lock; flock -n 8 || return 0
    local u
    _watch_service nginx
    _watch_service "${PHP_FPM_SERVICE:-php-fpm}"
    _watch_service mariadb
    _watch_service redis-server
    for u in $(systemctl list-unit-files --plain --no-legend 'dkvps-fpm@*' 'dkvps-redis@*' 'dkvps-app-*' 2>/dev/null | awk '$2=="enabled"{print $1}'); do
        _watch_service "$u"
    done
    # template instances are not listed as files: check the running set too
    for u in $(systemctl list-units --plain --no-legend --all 'dkvps-fpm@*' 'dkvps-redis@*' 2>/dev/null | awk '{print $1}'); do
        _watch_service "$u"
    done

    local d; for d in $(list_domain_configs); do _watch_site "$d"; done

    local pct; pct=$(df --output=pcent / | tail -1 | tr -dc 0-9)
    if (( pct >= 90 )); then _wstate disk "full-$pct" crit "disk / is ${pct}% full" "disk usage back to ${pct}%"
    else _wstate disk ok info "" "disk usage back to ${pct}%"; fi

    local avail total; avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo); total=$(awk '/MemTotal/{print $2}' /proc/meminfo)
    if (( avail * 100 / total < 5 )); then _wstate ram low warn "RAM almost exhausted ($((avail/1024)) MB available)" "RAM back to normal"
    else _wstate ram ok info "" "RAM back to normal ($((avail/1024)) MB available)"; fi

    local load5 cores old; load5=$(awk '{print int($2)}' /proc/loadavg); cores=$(nproc)
    old=$(cat "$WATCH_STATE/load" 2>/dev/null || echo ok)
    if (( load5 >= cores * 4 )); then _wstate load high warn "load $(cut -d' ' -f2 /proc/loadavg) on $cores CPU for 5 min" "load back to normal"
    elif (( load5 < cores * 2 )); then _wstate load ok info "" "load back to normal"; fi
    local now; now=$(cat "$WATCH_STATE/load")
    if [[ "$now" != "$old" ]] && grep -qs '^cf_shield_auto=1' "$DKVPS_USER_DIR"/.*.conf; then
        source "${CLI_DIR}/modules/cf/cf.sh"; cf_shield_watch "$now"
    fi
}
