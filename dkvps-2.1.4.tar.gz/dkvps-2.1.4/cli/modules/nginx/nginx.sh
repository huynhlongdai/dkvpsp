#!/bin/bash
#
# DKVPS - Nginx Management Module
#

nginx_handler() {
    local action="$1"
    shift
    case "$action" in
        config)     nginx_edit_config ;;
        domain)     nginx_domain_config "$@" ;;
        restart|-r) restart_nginx ;;
        reload)     reload_nginx ;;
        test|-t)    nginx -t ;;
        log-on)     nginx_access_log_on "$@" ;;
        log-off)    nginx_access_log_off "$@" ;;
        deny)       nginx_deny_ip "$@" ;;
        referer|referrer) nginx_referrer_spam "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown nginx action: $action"
            fi
            nginx_menu
            ;;
    esac
}

nginx_menu() {
    echo ""
    print_subheader "Nginx Management"
    echo ""
    echo "  Status: $(service_status nginx)"
    echo "  Version: $(nginx -v 2>&1 | cut -d'/' -f2)"
    echo ""

    local options=(
        "Edit nginx.conf"
        "Edit Domain Config"
        "Test Config"
        "Restart Nginx"
        "Reload Nginx"
        "Enable Access Log"
        "Disable Access Log"
        "Block IP Address"
        "Anti Referrer Spam"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") nginx_edit_config ;;
            "${options[1]}") nginx_domain_config ;;
            "${options[2]}") nginx -t ;;
            "${options[3]}") restart_nginx ;;
            "${options[4]}") reload_nginx ;;
            "${options[5]}") nginx_access_log_on ;;
            "${options[6]}") nginx_access_log_off ;;
            "${options[7]}") nginx_deny_ip ;;
            "${options[8]}") nginx_referrer_spam ;;
            *) return ;;
        esac
    done
}

nginx_edit_config() {
    ${EDITOR:-nano} /etc/nginx/nginx.conf
    nginx -t && print_success "Config valid" || print_error "Config has errors"
}

nginx_domain_config() {
    local domain="${1:-}"

    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    local conf="/etc/nginx/conf.d/$domain.conf"
    if [[ -f "$conf" ]]; then
        ${EDITOR:-nano} "$conf"
        nginx -t && reload_nginx
    else
        print_error "Nginx config not found: $conf"
    fi
}

# per-site rules live in the site's .custom include (server context), which
# survives vhost regeneration; every change is rolled back if nginx -t fails
_nginx_custom_edit() {   # <domain> <add|del> <line>
    local domain="$1" op="$2" line="$3"
    local f="$DKVPS_SITE_INC_DIR/$domain.custom"
    [[ -f "$f" ]] || echo "# custom nginx rules for $domain (server context)" > "$f"
    cp -a "$f" "$f.bak"
    if [[ "$op" == "add" ]]; then
        grep -qxF "$line" "$f" || echo "$line" >> "$f"
    else
        grep -vxF "$line" "$f.bak" > "$f"
    fi
    if nginx -t >/dev/null 2>&1; then
        rm -f "$f.bak"; reload_nginx >/dev/null; return 0
    fi
    mv "$f.bak" "$f"; print_error "nginx rejected the change, rolled back"; return 1
}

nginx_access_log_on() {
    local domain="${1:-}"
    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi
    domain_exists "$domain" || { print_error "Domain $domain not found."; return 1; }
    _nginx_custom_edit "$domain" del "access_log off; # dkvps" && print_success "Access log enabled for $domain"
}

nginx_access_log_off() {
    local domain="${1:-}"
    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi
    domain_exists "$domain" || { print_error "Domain $domain not found."; return 1; }
    _nginx_custom_edit "$domain" add "access_log off; # dkvps" && print_success "Access log disabled for $domain"
}

nginx_deny_ip() {
    local ip="${1:-}"
    if [[ -z "$ip" ]]; then
        read -p "Enter IP to block: " ip
    fi
    if ! [[ "$ip" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}(/[0-9]{1,2})?$ || "$ip" =~ ^[0-9a-fA-F:]+(/[0-9]{1,3})?$ ]]; then
        print_error "Invalid IP: $ip"; return 1
    fi

    local domain="${2:-}"
    if [[ -z "$domain" ]]; then choose_domain || return; domain="$SELECTED_DOMAIN"; fi
    domain_exists "$domain" || { print_error "Domain $domain not found."; return 1; }
    _nginx_custom_edit "$domain" add "deny $ip;" && print_success "IP $ip blocked for $domain"
}

nginx_referrer_spam() {
    # dkvps nginx referer on|off|add <host>|del <host>|list   (all sites)
    local op="${1:-}" host="${2:-}"
    local list=/etc/dkvps/nginx/referer-spam.list block=/etc/dkvps/nginx/referer-block.conf g="$DKVPS_NGINX_DIR/global.conf"
    if [[ -z "$op" ]]; then
        echo ""; print_subheader "Anti Referrer Spam"; echo ""
        echo "  Status: $([[ -f $block ]] && echo ON || echo OFF)   Hosts: $(grep -c . "$list" 2>/dev/null || echo 0)"
        local o=("Turn on" "Turn off" "Add host" "Remove host" "List hosts")
        local PS3=$'\n'"Select (1-${#o[@]}) [0=Back]: "
        select x in "${o[@]}"; do case $x in
            "${o[0]}") op=on ;; "${o[1]}") op=off ;; "${o[2]}") op=add; read -p "Host (e.g. semalt.com): " host ;;
            "${o[3]}") op=del; read -p "Host: " host ;; "${o[4]}") op=list ;; *) return ;; esac; break; done
    fi
    [[ -s "$list" ]] || printf '%s\n' semalt.com buttons-for-website.com darodar.com best-seo-offer.com ilovevitaly.com priceg.com \
        hulfingtonpost.com makemoneyonline blackhatworth.com trafficbot.life free-traffic.xyz > "$list"
    case "$op" in
        list) cat "$list"; return 0 ;;
        add|del)
            host="${host,,}"; host="${host#http*://}"; host="${host%%/*}"
            [[ "$host" =~ ^[a-z0-9.-]{3,100}$ ]] || { print_error "Invalid host"; return 1; }
            if [[ "$op" == add ]]; then grep -qx "$host" "$list" || echo "$host" >> "$list"
            else sed -i "\\#^${host//./\\.}\$#d" "$list"; fi ;;
        on|off) ;;
        *) print_error "Usage: dkvps nginx referer on|off|add <host>|del <host>|list"; return 1 ;;
    esac
    # map in http context (regenerated from the list), rule in every server via protect.conf
    {
        echo '# generated from referer-spam.list by dkvps nginx referer'
        echo 'map $http_referer $dkvps_bad_referer {'
        echo '    default 0;'
        local h; while IFS= read -r h; do [[ -n "$h" ]] && echo "    \"~*(^|[/.])${h//./\\.}\" 1;"; done < "$list"
        echo '}'
    } > /etc/dkvps/nginx/referer-spam.map
    sed -i '/# Anti referrer spam/,/^}/d' "$g"   # drop the old inline map (pre-2.0.4)
    grep -q 'referer-spam.map' "$g" || echo 'include /etc/dkvps/nginx/referer-spam.map;' >> "$g"
    grep -q 'referer-block' /etc/dkvps/nginx/protect.conf || echo 'include /etc/dkvps/nginx/referer-block*.conf;' >> /etc/dkvps/nginx/protect.conf
    if [[ "$op" == off ]]; then rm -f "$block"
    elif [[ "$op" == on || -f "$block" ]]; then echo 'if ($dkvps_bad_referer) { return 403; }' > "$block"; fi
    if nginx -t >/dev/null 2>&1; then reload_nginx >/dev/null
        print_success "Referrer spam blocking $([[ -f $block ]] && echo ON || echo OFF) ($(grep -c . "$list") hosts)"
    else
        rm -f "$block"; nginx -t >/dev/null 2>&1 && reload_nginx >/dev/null
        print_error "nginx rejected the rules, blocking turned off"; return 1
    fi
}
