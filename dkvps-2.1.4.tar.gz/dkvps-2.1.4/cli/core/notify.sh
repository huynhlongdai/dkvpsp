#!/bin/bash
#
# DKVPS - alerts: always logged to /var/log/dkvps-alerts.log, and sent to
# Telegram when `dkvps notify telegram <bot_token> <chat_id>` was set up.
# No daemon: callers (cron jobs, ssl check, backups) invoke it when needed.
#

DKVPS_NOTIFY_CONF=/etc/dkvps/notify.conf
DKVPS_ALERT_LOG=/var/log/dkvps-alerts.log

notify_send() {
    local level="${1:-info}"; shift
    local msg="$*" host; host=$(hostname -f 2>/dev/null || hostname)
    printf '%s [%s] %s\n' "$(date '+%F %T')" "$level" "$msg" >> "$DKVPS_ALERT_LOG" 2>/dev/null
    [[ -f "$DKVPS_NOTIFY_CONF" ]] || return 0
    local token chat
    token=$(grep -E '^tg_token=' "$DKVPS_NOTIFY_CONF" | cut -d= -f2-)
    chat=$(grep -E '^tg_chat=' "$DKVPS_NOTIFY_CONF" | cut -d= -f2-)
    [[ -n "$token" && -n "$chat" ]] || return 0
    local icon="ℹ️"; [[ "$level" == "warn" ]] && icon="⚠️"; [[ "$level" == "crit" ]] && icon="🚨"; [[ "$level" == "ok" ]] && icon="✅"
    # token goes in a curl config on stdin, never on the command line
    printf 'url = "%s/bot%s/sendMessage"\n' "${DKVPS_TG_API:-https://api.telegram.org}" "$token" | \
        curl -s --max-time 10 -o /dev/null -K - \
            --data-urlencode "chat_id=$chat" \
            --data-urlencode "text=$icon [$host] $msg" 2>/dev/null
    return 0
}

notify_handler() {
    local action="${1:-status}"; shift 2>/dev/null
    case "$action" in
        telegram)
            local token="${1:-}" chat="${2:-}"
            [[ "$token" == "-" ]] && read -r token
            [[ "$token" =~ ^[0-9]+:[A-Za-z0-9_-]+$ ]] || { print_error "Usage: dkvps notify telegram <bot_token|-> <chat_id>"; return 1; }
            [[ "$chat" =~ ^-?[0-9]+$|^@[A-Za-z0-9_]+$ ]] || { print_error "chat_id must be a number (or @channel)"; return 1; }
            mkdir -p /etc/dkvps
            (umask 077; printf 'tg_token=%s\ntg_chat=%s\n' "$token" "$chat" > "$DKVPS_NOTIFY_CONF")
            notify_send ok "DKVPS alerts connected"
            print_success "Telegram alerts on (a test message was sent)" ;;
        test) notify_send info "Test alert from DKVPS"; print_success "Sent (also logged to $DKVPS_ALERT_LOG)" ;;
        send) local lvl="${1:-warn}"; shift; notify_send "$lvl" "$*" ;;
        off)  rm -f "$DKVPS_NOTIFY_CONF"; print_success "Telegram alerts off (still logged to $DKVPS_ALERT_LOG)" ;;
        status|*)
            if [[ -f "$DKVPS_NOTIFY_CONF" ]]; then echo "Telegram: on (chat $(grep -E '^tg_chat=' "$DKVPS_NOTIFY_CONF" | cut -d= -f2-))"; else echo "Telegram: off"; fi
            echo "Log: $DKVPS_ALERT_LOG"; tail -5 "$DKVPS_ALERT_LOG" 2>/dev/null ;;
    esac
}
