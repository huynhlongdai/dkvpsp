#!/bin/bash
#
# DKVPS - Platform abstraction (RHEL family vs Debian/Ubuntu)
# Every module should use these variables/functions instead of hard-coded
# CentOS paths (/etc/php-fpm.d, php-fpm.service, firewall-cmd, ...).
#

detect_os_family() {
    local id="" like=""
    if [[ -f /etc/os-release ]]; then
        id=$(. /etc/os-release; echo "$ID")
        like=$(. /etc/os-release; echo "$ID_LIKE")
    fi
    case "$id $like" in
        *debian*|*ubuntu*) echo "debian" ;;
        *) echo "rhel" ;;
    esac
}

DKVPS_OS_FAMILY="${DKVPS_OS_FAMILY:-$(detect_os_family)}"
DKVPS_PHP_VERSION="${php_default_version:-8.1}"

platform_init() {
    DKVPS_PHP_VERSION="${php_default_version:-${DKVPS_PHP_VERSION:-8.1}}"
    if [[ "$DKVPS_OS_FAMILY" == "debian" ]]; then
        PHP_FPM_SERVICE="php${DKVPS_PHP_VERSION}-fpm"
        PHP_POOL_DIR="/etc/php/${DKVPS_PHP_VERSION}/fpm/pool.d"
        PHP_INI="/etc/php/${DKVPS_PHP_VERSION}/fpm/php.ini"
        PHP_CONF_D="/etc/php/${DKVPS_PHP_VERSION}/fpm/conf.d"
        PHP_FPM_LOG="/var/log/php${DKVPS_PHP_VERSION}-fpm.log"
        PHP_FPM_SOCK="/run/php/php${DKVPS_PHP_VERSION}-fpm.sock"
        NGINX_USER="www-data"
        REDIS_SERVICE="redis-server"
        CRON_SERVICE="cron"
        SSH_SERVICE="ssh"
        FIREWALL_TOOL="ufw"
    else
        PHP_FPM_SERVICE="php-fpm"
        PHP_POOL_DIR="/etc/php-fpm.d"
        PHP_INI="/etc/php.ini"
        PHP_CONF_D="/etc/php.d"
        PHP_FPM_LOG="/var/log/php-fpm/error.log"
        PHP_FPM_SOCK="/run/php-fpm/www.sock"
        NGINX_USER="nginx"
        REDIS_SERVICE="redis"
        CRON_SERVICE="crond"
        SSH_SERVICE="sshd"
        FIREWALL_TOOL="firewalld"
    fi
}
platform_init

# Map a logical service name to the real systemd unit on this OS
svc_name() {
    case "$1" in
        php-fpm)  echo "$PHP_FPM_SERVICE" ;;
        redis)    echo "$REDIS_SERVICE" ;;
        crond)    echo "$CRON_SERVICE" ;;
        sshd)     echo "$SSH_SERVICE" ;;
        *)        echo "$1" ;;
    esac
}

# ---------------- Firewall (firewalld or ufw) ----------------
fw_state() {
    if [[ "$FIREWALL_TOOL" == "ufw" ]] && command -v ufw &>/dev/null; then
        ufw status 2>/dev/null | head -1 | awk '{print $2}'
    elif command -v firewall-cmd &>/dev/null; then
        firewall-cmd --state 2>/dev/null
    else
        echo "N/A"
    fi
}

fw_list_ports() {
    if [[ "$FIREWALL_TOOL" == "ufw" ]] && command -v ufw &>/dev/null; then
        ufw status 2>/dev/null | awk 'NR>4 && $2 ~ /ALLOW/ && $1 !~ /\(v6\)/ {print $1}' | sort -u | tr '\n' ' '
    elif command -v firewall-cmd &>/dev/null; then
        firewall-cmd --list-ports 2>/dev/null
    else
        echo "N/A"
    fi
}

fw_open() {
    local port="$1" protocol="${2:-tcp}"
    if [[ "$FIREWALL_TOOL" == "ufw" ]]; then
        ufw allow "${port}/${protocol}" >/dev/null
    else
        firewall-cmd --permanent --zone=public --add-port="${port}/${protocol}" >/dev/null && firewall-cmd --reload >/dev/null
    fi
}

fw_close() {
    local port="$1" protocol="${2:-tcp}"
    if [[ "$FIREWALL_TOOL" == "ufw" ]]; then
        ufw delete allow "${port}/${protocol}" >/dev/null
    else
        firewall-cmd --permanent --zone=public --remove-port="${port}/${protocol}" >/dev/null && firewall-cmd --reload >/dev/null
    fi
}

fw_list_all() {
    if [[ "$FIREWALL_TOOL" == "ufw" ]]; then ufw status verbose 2>/dev/null; else firewall-cmd --list-all 2>/dev/null; fi
}
