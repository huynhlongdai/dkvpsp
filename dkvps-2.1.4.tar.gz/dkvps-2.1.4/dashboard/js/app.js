/**
 * DKVPS Dashboard - Pure vanilla JS, zero dependencies
 * ~8KB total JS
 */

// ============ State ============
const state = {
    servers: JSON.parse(localStorage.getItem('dkvps_servers') || '[]'),
    activeId: localStorage.getItem('dkvps_active') || null,
    ws: null,
    stats: null,
    page: location.hash.slice(1) || 'dashboard'
};

function activeServer() {
    return state.servers.find(s => s.id === state.activeId) || state.servers[0] || null;
}

function saveServers() {
    localStorage.setItem('dkvps_servers', JSON.stringify(state.servers));
    localStorage.setItem('dkvps_active', state.activeId);
}

// ============ Escaping (everything from the server is untrusted) ============
function esc(v) {
    return String(v ?? '').replace(/[&<>"'`]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' }[c]));
}
// for values placed inside onclick="fn('...')"
function jsArg(v) { return esc(JSON.stringify(String(v ?? ''))); }

// ============ API ============
async function login(srv) {
    const res = await fetch(`${srv.url}/api/auth/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_key: srv.apiKey })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Invalid API key');
    return data.token;
}

async function api(path, opts = {}, retried = false) {
    const srv = activeServer();
    if (!srv) throw new Error('No server connected');
    const res = await fetch(`${srv.url}/api${path}`, {
        ...opts,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${srv.token}`,
            ...(opts.headers || {})
        },
        body: opts.body ? JSON.stringify(opts.body) : undefined
    });
    // token expired / agent secret rotated -> re-login once with the stored API key
    if (res.status === 401 && !retried && srv.apiKey) {
        srv.token = await login(srv);
        saveServers();
        connectWS();
        return api(path, opts, true);
    }
    const data = await res.json().catch(() => ({ error: `HTTP ${res.status} (non-JSON response)` }));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
}

async function apiGet(path) { return api(path); }
async function apiPost(path, body) { return api(path, { method: 'POST', body }); }
async function apiDelete(path) { return api(path, { method: 'DELETE' }); }

// ============ WebSocket ============
function connectWS() {
    if (state.ws) { state.ws.close(); state.ws = null; }
    const srv = activeServer();
    if (!srv) return;
    const proto = srv.url.startsWith('https') ? 'wss' : 'ws';
    const host = srv.url.replace(/^https?:\/\//, '');
    state.ws = new WebSocket(`${proto}://${host}/ws?token=${encodeURIComponent(srv.token)}`);
    state.ws.onmessage = e => {
        try {
            const msg = JSON.parse(e.data);
            if (msg.type === 'stats') {
                state.stats = msg.data;
                if (state.page === 'dashboard') renderDashboardStats();
                if (state.page === 'monitor') renderMonitorStats();
                updateWsIndicator(true);
            }
        } catch {}
    };
    const ws = state.ws;
    ws.onclose = (ev) => {
        updateWsIndicator(false);
        if (state.ws !== ws) return; // replaced by a newer connection
        if (ev.code === 4001 && srv.apiKey) {
            login(srv).then(t => { srv.token = t; saveServers(); }).catch(() => {}).finally(() => setTimeout(connectWS, 1000));
        } else setTimeout(connectWS, 5000);
    };
    ws.onerror = () => ws.close();
}

function updateWsIndicator(on) {
    const el = document.getElementById('ws-status');
    if (el) {
        el.textContent = on ? '● Live' : '○ Offline';
        el.style.color = on ? 'var(--green)' : 'var(--fg3)';
    }
}

// ============ Server Management ============
async function addServer(name, url, apiKey) {
    url = url.replace(/\/$/, '');
    if (!/^https?:\/\//.test(url)) url = 'https://' + url;
    if (location.protocol === 'https:' && url.startsWith('http:')) throw new Error('Dashboard is on HTTPS: the agent URL must be https:// too (browser blocks mixed content)');
    let token;
    try { token = await login({ url, apiKey }); }
    catch (e) { throw new Error(e instanceof TypeError ? `Cannot reach ${url} (firewall, wrong port or https/http mismatch)` : e.message); }
    const id = Date.now().toString();
    const server = { id, name: name || 'VPS', url, token, apiKey };
    state.servers.push(server);
    state.activeId = id;
    saveServers();
    return server;
}

function removeServer(id) {
    state.servers = state.servers.filter(s => s.id !== id);
    if (state.activeId === id) state.activeId = state.servers[0]?.id || null;
    saveServers();
}

function switchServer(id) {
    state.activeId = id;
    saveServers();
    connectWS();
    navigate(state.page);
}

// ============ Router ============
function navigate(page) {
    state.page = page;
    location.hash = page;
    document.querySelectorAll('.sidebar-nav a').forEach(a => {
        a.classList.toggle('active', a.dataset.page === page);
    });
    renderPage();
}

function renderPage() {
    const content = document.getElementById('page-content');
    if (!content) return;
    const fn = pages[state.page];
    if (fn) fn(content);
    else content.innerHTML = '<p>Page not found</p>';
}

// ============ Helpers ============
function h(tag, attrs, ...children) {
    const el = document.createElement(tag);
    if (attrs) Object.entries(attrs).forEach(([k, v]) => {
        if (k === 'className') el.className = v;
        else if (k.startsWith('on')) el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'html') el.innerHTML = v;
        else el.setAttribute(k, v);
    });
    children.flat().forEach(c => {
        if (c == null) return;
        el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return el;
}

function formatBytes(b) {
    if (!b) return '0 B';
    const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(b) / Math.log(k));
    return (b / Math.pow(k, i)).toFixed(1) + ' ' + s[i];
}

function progressBar(pct, color) {
    const c = pct > 90 ? 'red' : pct > 70 ? 'yellow' : color;
    const cl = c === 'red' ? 'progress-red' : c === 'green' ? 'progress-green' : 'progress-blue';
    return `<div class="progress ${cl}"><div class="progress-bar" style="width:${Math.min(pct, 100)}%"></div></div>`;
}

function badge(status) {
    const s = esc((status || '').trim());
    if (s === 'active' || s === 'running') return `<span class="badge badge-green">${s}</span>`;
    if (s === 'suspended') return `<span class="badge badge-yellow">${s}</span>`;
    return `<span class="badge badge-red">${s}</span>`;
}

// ============ SVG Icons (inline, ~20 icons) ============
const icons = {
    server: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r="1"/><circle cx="6" cy="18" r="1"/></svg>',
    grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20"/></svg>',
    database: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
    cpu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    code: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    hdd: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12H2"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" y1="16" x2="6.01" y2="16"/><line x1="10" y1="16" x2="10.01" y2="16"/></svg>',
    archive: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>',
    activity: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
    monitor: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
    stop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
};

function icon(name, size = 18) {
    return `<span style="display:inline-flex;width:${size}px;height:${size}px">${icons[name] || ''}</span>`;
}

// ============ Init ============
window.addEventListener('hashchange', () => { state.page = location.hash.slice(1) || 'dashboard'; renderPage(); });
document.addEventListener('DOMContentLoaded', init);

function init() {
    if (!activeServer()) {
        renderLogin();
    } else {
        renderApp();
        connectWS();
    }
}
