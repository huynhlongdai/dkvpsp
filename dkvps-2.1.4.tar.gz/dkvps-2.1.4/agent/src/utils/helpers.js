const { cmd, cmdOk } = require('./exec');
const { loadConfig } = require('./config');

const DKVPS_BIN = process.env.DKVPS_BIN || '/usr/bin/dkvps';

/** Wrap an async route so thrown errors become proper JSON responses */
const h = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(e => {
    res.status(e.status || 500).json({ error: e.message || 'Internal error' });
});

/** Run the dkvps CLI non-interactively */
function dkvps(args, timeout = 60000) {
    return cmdOk(DKVPS_BIN, ['--yes', ...args], { timeout, env: { DKVPS_ASSUME_YES: '1', TERM: 'dumb' } });
}

/** Run SQL as the DKVPS DB admin; password passed via env, never on the command line */
function mysql(sql, { raw = false } = {}) {
    const c = loadConfig();
    const args = ['-u', c.db_admin_user || 'admin', '-N', '-B', '-e', sql];
    return cmdOk('mysql', args, { env: { MYSQL_PWD: c.db_admin_password || '' } }).then(r => raw ? r : r.stdout);
}

module.exports = { h, dkvps, mysql, DKVPS_BIN, cmd, cmdOk };
