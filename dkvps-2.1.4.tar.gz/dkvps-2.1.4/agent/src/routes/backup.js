const express = require('express');
const fs = require('fs');
const path = require('path');
const { v } = require('../utils/validate');
const { h, dkvps } = require('../utils/helpers');

const router = express.Router();
const BACKUP_DIR = '/etc/dkvps/backup';

router.get('/', (req, res) => {
    const backups = [];
    for (const type of ['source', 'db']) {
        const dir = path.join(BACKUP_DIR, type);
        try {
            fs.readdirSync(dir).forEach(f => {
                const stat = fs.statSync(path.join(dir, f));
                if (stat.isFile()) backups.push({ name: f, type, size: stat.size, created: stat.mtime });
            });
        } catch (e) { /* dir may not exist */ }
    }
    backups.sort((a, b) => b.created - a.created);
    res.json({ backups });
});

router.post('/create', h(async (req, res) => {
    const domain = v.domain(req.body.domain);
    const action = req.body.type === 'database' ? 'db-only' : 'create';
    const r = await dkvps(['backup', action, domain], 900000);
    res.json({ message: `Backup created for ${domain}`, output: r.stdout });
}));

router.delete('/:filename', (req, res) => {
    let name;
    try { name = v.filename(req.params.filename); } catch (e) { return res.status(400).json({ error: e.message }); }
    for (const type of ['source', 'db']) {
        const fp = path.join(BACKUP_DIR, type, name);
        if (fs.existsSync(fp)) { fs.unlinkSync(fp); return res.json({ message: 'Deleted' }); }
    }
    res.status(404).json({ error: 'Backup not found' });
});

module.exports = router;
