const express = require('express');
const { listDomainConfigs, loadDomainConfig } = require('../utils/config');
const { v } = require('../utils/validate');
const { h, dkvps } = require('../utils/helpers');

const router = express.Router();
const SECRET_KEYS = ['password', 'password_sftp', 'db_password'];
const strip = cfg => Object.fromEntries(Object.entries(cfg).filter(([k]) => !SECRET_KEYS.includes(k)));

router.get('/', (req, res) => {
    res.json({ domains: listDomainConfigs().map(strip) });
});

router.get('/:domain', (req, res) => {
    const domain = v.domain(req.params.domain);
    const cfg = loadDomainConfig(domain);
    if (!cfg) return res.status(404).json({ error: 'Domain not found' });
    res.json({ domain, ...strip(cfg) });
});

router.post('/', h(async (req, res) => {
    const domain = v.domain(req.body.domain);
    const app = v.oneOf(req.body.app || 'none', ['none', 'db', 'wordpress', 'laravel'], 'app');
    const flag = { none: '--no-app', db: '--db', wordpress: '--wp', laravel: '--laravel' }[app];
    const r = await dkvps(['domain', 'add', domain, flag], app === 'none' || app === 'db' ? 120000 : 600000);
    if (!loadDomainConfig(domain)) throw new Error(r.stdout.split('\n').slice(-5).join('\n') || 'Domain was not created');
    res.json({ message: `Domain ${domain} created`, output: r.stdout });
}));

router.delete('/:domain', h(async (req, res) => {
    const domain = v.domain(req.params.domain);
    if (!loadDomainConfig(domain)) return res.status(404).json({ error: 'Domain not found' });
    await dkvps(['domain', 'delete', domain]);
    res.json({ message: `Domain ${domain} deleted` });
}));

for (const [path, action, msg] of [['suspend', 'suspend', 'Suspended'], ['unsuspend', 'unsuspend', 'Unsuspended'], ['fix-permissions', 'permission', 'Permissions fixed']]) {
    router.post(`/:domain/${path}`, h(async (req, res) => {
        const domain = v.domain(req.params.domain);
        if (!loadDomainConfig(domain)) return res.status(404).json({ error: 'Domain not found' });
        await dkvps(['domain', action, domain]);
        res.json({ message: msg });
    }));
}

module.exports = router;
