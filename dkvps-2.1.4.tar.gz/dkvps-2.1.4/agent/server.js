/**
 * DKVPS Agent - Lightweight API running on VPS
 *
 * This agent runs directly on the VPS with minimal resource usage.
 * The Web Dashboard (running separately) connects to this agent
 * to monitor and control the VPS.
 *
 * Dependencies: express, helmet, jsonwebtoken, ws (4 packages only)
 * Memory: ~15-20MB
 */

const express = require('express');
const helmet = require('helmet');
const http = require('http');
const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const auth = require('./src/routes/auth');
const system = require('./src/routes/system');
const domains = require('./src/routes/domains');
const databases = require('./src/routes/databases');
const services = require('./src/routes/services');
const ssl = require('./src/routes/ssl');
const php = require('./src/routes/php');
const firewall = require('./src/routes/firewall');
const cache = require('./src/routes/cache');
const backup = require('./src/routes/backup');
const { setupWS } = require('./src/utils/ws');
const { loadConfig, setConfigValue } = require('./src/utils/config');

const config = loadConfig();
const PORT = process.env.AGENT_PORT || config.port_agent || 9090;
const HOST = process.env.AGENT_HOST || config.agent_host || '0.0.0.0';

// Persist the JWT secret so tokens survive agent restarts
let JWT_SECRET = process.env.AGENT_SECRET || config.agent_secret;
if (!JWT_SECRET) {
    JWT_SECRET = require('crypto').randomBytes(32).toString('hex');
    try { setConfigValue('agent_secret', JWT_SECRET); } catch { console.warn('[DKVPS Agent] Could not persist agent_secret; tokens reset on restart'); }
}
if (!config.agent_api_key) {
    const key = require('crypto').randomBytes(32).toString('hex');
    try { setConfigValue('agent_api_key', key); config.agent_api_key = key; console.log('[DKVPS Agent] Generated API key - see agent_api_key in /etc/dkvps/.dkvps.conf'); } catch { /* ignore */ }
}

const app = express();
const server = http.createServer(app);

// Minimal middleware
app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: false }));
app.use(express.json({ limit: '1mb' }));

// CORS - allow dashboard from any origin (auth via token)
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type,Authorization');
    res.header('Access-Control-Allow-Credentials', 'true');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});

// Auth middleware
function authMiddleware(req, res, next) {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Token required' });
    try {
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch {
        res.status(401).json({ error: 'Invalid token' });
    }
}

// Public routes
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', version: config.version || '1.0.0' });
});
app.use('/api/auth', auth(JWT_SECRET, config));

// Protected routes
app.use('/api/system', authMiddleware, system);
app.use('/api/domains', authMiddleware, domains);
app.use('/api/databases', authMiddleware, databases);
app.use('/api/services', authMiddleware, services);
app.use('/api/ssl', authMiddleware, ssl);
app.use('/api/php', authMiddleware, php);
app.use('/api/firewall', authMiddleware, firewall);
app.use('/api/cache', authMiddleware, cache);
app.use('/api/backup', authMiddleware, backup);

// Serve static dashboard (optional - dashboard can also run standalone)
const dashboardPath = path.join(__dirname, '..', 'dashboard');
if (fs.existsSync(dashboardPath)) {
    app.use(express.static(dashboardPath));
    app.get('/', (req, res) => res.sendFile(path.join(dashboardPath, 'index.html')));
}

// WebSocket for real-time monitoring
const wss = new WebSocket.Server({ server, path: '/ws' });
setupWS(wss, JWT_SECRET);

// Error handler
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
    console.error(`[${new Date().toISOString()}] Error:`, err.message);
    res.status(err.status || 500).json({ error: err.status === 400 ? err.message : 'Internal server error' });
});

// Lite profile: systemd socket activation (LISTEN_FDS) + exit when idle, so the
// agent costs no RAM until the dashboard/API connects. systemd keeps the port
// open and starts us again on the next connection.
const IDLE_EXIT = parseInt(process.env.AGENT_IDLE_EXIT || '0', 10);
let lastActivity = Date.now();
server.on('request', () => { lastActivity = Date.now(); });
server.on('upgrade', () => { lastActivity = Date.now(); });
if (IDLE_EXIT > 0) {
    setInterval(() => {
        if (wss.clients.size > 0) { lastActivity = Date.now(); return; }
        if (Date.now() - lastActivity > IDLE_EXIT * 1000) {
            console.log(`[DKVPS Agent] Idle for ${IDLE_EXIT}s, exiting (socket activation will restart on demand)`);
            server.close(() => process.exit(0));
            setTimeout(() => process.exit(0), 3000).unref();
        }
    }, 15000).unref();
}

const onListen = (where) => () => {
    console.log(`[DKVPS Agent] Running on ${where}`);
    console.log(`[DKVPS Agent] Memory: ${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB`);
};
if (process.env.LISTEN_FDS && parseInt(process.env.LISTEN_FDS, 10) >= 1 &&
    (!process.env.LISTEN_PID || parseInt(process.env.LISTEN_PID, 10) === process.pid)) {
    server.listen({ fd: 3 }, onListen('systemd socket (fd 3)'));
} else {
    server.listen(PORT, HOST, onListen(`${HOST}:${PORT}`));
}
