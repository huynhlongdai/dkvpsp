#!/bin/bash
# 1.1.0: self-update support (release state dir). No login/cron checks since 2.1.5.
mkdir -p /var/lib/dkvps/update
exit 0
