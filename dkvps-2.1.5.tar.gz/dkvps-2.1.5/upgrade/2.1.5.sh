#!/bin/bash
# 2.1.5: no background checks. Version/license are checked only when the user runs `dkvps`.
rm -f /etc/cron.d/dkvps-check /etc/profile.d/dkvps-update.sh
exit 0
