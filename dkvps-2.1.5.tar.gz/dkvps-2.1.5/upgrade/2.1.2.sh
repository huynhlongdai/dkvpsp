#!/bin/bash
# 2.1.2 added a daily check cron; removed again in 2.1.5 (checks run only when `dkvps` is opened)
exit 0
