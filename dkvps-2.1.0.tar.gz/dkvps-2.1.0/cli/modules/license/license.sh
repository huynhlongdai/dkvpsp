#!/bin/bash
#
# DKVPS - License (DKVPS Hub)
#
#   dkvps license activate <KEY> [--hub URL] [--repin]   bind this server to a key, save the signed token
#   dkvps license status                                 plan, features, validity (--json supported)
#   dkvps license refresh [--quiet]                      re-issue the token (daily cron does this)
#   dkvps license deactivate                             free this server's activation slot
#
# Token  /etc/dkvps/license.token (0600): base64url(JSON).base64url(Ed25519 sig), valid 7 days offline
# Pubkey /etc/dkvps/license.pub: fetched at first activation, then pinned
# Hub    --hub > hub_url in /etc/dkvps/license.conf > $DKVPS_HUB_URL > HUB_URL_DEFAULT
#
# For other modules:  license_plan  (prints plan, exit 1 if no valid license)
#                     license_has_feature <name>  (exit 0/1)
#

HUB_URL_DEFAULT="https://hub.finc.web.id"   # DKVPS Hub (license + fleet); override with --hub URL, DKVPS_HUB_URL or hub_url in /etc/dkvps/license.conf

LICENSE_DIR="${DKVPS_LICENSE_DIR:-/etc/dkvps}"
LICENSE_CONF="$LICENSE_DIR/license.conf"
LICENSE_TOKEN="$LICENSE_DIR/license.token"
LICENSE_PUB="$LICENSE_DIR/license.pub"
LICENSE_CRON="${DKVPS_LICENSE_CRON:-/etc/cron.d/dkvps-license}"
LICENSE_MACHINE_ID_FILE="${DKVPS_MACHINE_ID_FILE:-/etc/machine-id}"

license_handler() {
    local action="${1:-status}"; shift 2>/dev/null
    case "$action" in
        activate)   license_activate "$@" ;;
        status)     license_status "$@" ;;
        refresh)    license_refresh "$@" ;;
        deactivate) license_deactivate "$@" ;;
        *) sed -n '3,17p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; return 1 ;;
    esac
}

# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------
_lic_say() { [[ "${LICENSE_QUIET:-0}" == 1 ]] || "$@"; }

_lic_need() {
    local b; for b in curl jq openssl sha256sum; do
        command -v "$b" >/dev/null 2>&1 || { print_error "license: '$b' is required"; return 1; }
    done
}

license_machine_id() {
    local f="$LICENSE_MACHINE_ID_FILE"
    [[ -s "$f" ]] || f=/var/lib/dbus/machine-id
    [[ -s "$f" ]] || { print_error "license: no /etc/machine-id"; return 1; }
    tr -d ' \n' < "$f" | sha256sum | awk '{print $1}'
}

_lic_hub() {   # [override]
    local h="${1:-}"
    [[ -z "$h" ]] && h=$(get_config hub_url "$LICENSE_CONF" 2>/dev/null)
    [[ -z "$h" ]] && h="${DKVPS_HUB_URL:-}"
    [[ -z "$h" ]] && h="$HUB_URL_DEFAULT"
    echo "${h%/}"
}

_lic_key_norm() {   # user input -> DKVPS-XXXXX-XXXXX-XXXXX-XXXXX (checksum is checked by the hub)
    local k="${1^^}"; k="${k//[[:space:]-]/}"; k="${k#DKVPS}"
    k="${k//O/0}"; k="${k//I/1}"; k="${k//L/1}"
    [[ "$k" =~ ^[0-9A-HJKMNP-TV-Z]{20}$ ]] || return 1
    echo "DKVPS-${k:0:5}-${k:5:5}-${k:10:5}-${k:15:5}"
}

_lic_mask() { local k="$1"; [[ ${#k} -eq 29 ]] && echo "${k:0:11}-*****-*****-${k:24:5}" || echo "$k"; }

_lic_b64u_decode() {   # stdin base64url -> stdout bytes
    local s; s=$(tr -d '\n' | tr '_-' '/+')
    case $(( ${#s} % 4 )) in 2) s="$s==" ;; 3) s="$s=" ;; esac
    printf '%s' "$s" | openssl base64 -d -A
}

# POST json to the hub: sets LIC_HTTP (status code, 000 = unreachable) and LIC_BODY
_lic_post() {   # url json
    local out
    out=$(printf '%s' "$2" | curl -sS -m 25 --connect-timeout 10 -X POST -H 'Content-Type: application/json' \
          --data-binary @- -w '\n%{http_code}' "$1" 2>/dev/null) || true
    LIC_HTTP="${out##*$'\n'}"; LIC_BODY="${out%$'\n'*}"
    [[ "$LIC_HTTP" =~ ^[0-9]{3}$ ]] || LIC_HTTP=000
    [[ "$LIC_BODY" == "$LIC_HTTP" ]] && LIC_BODY=""
}

_lic_err() { jq -r '.message // .error // empty' <<<"$LIC_BODY" 2>/dev/null; }

# Verify a token's Ed25519 signature; prints the payload JSON on success.
license_verify_token() {   # [token_file] [pubkey_pem]
    local tf="${1:-$LICENSE_TOKEN}" pub="${2:-$LICENSE_PUB}" tok body sig tmp rc
    [[ -s "$tf" && -s "$pub" ]] || return 1
    tok=$(tr -d ' \n' < "$tf")
    body="${tok%%.*}"; sig="${tok#*.}"
    [[ -n "$body" && -n "$sig" && "$body" != "$tok" && "$body$sig" =~ ^[A-Za-z0-9_-]+$ ]] || return 1
    tmp=$(mktemp -d) || return 1
    printf '%s' "$body" > "$tmp/body"
    printf '%s' "$sig" | _lic_b64u_decode > "$tmp/sig" 2>/dev/null
    openssl pkeyutl -verify -pubin -inkey "$pub" -rawin -in "$tmp/body" -sigfile "$tmp/sig" >/dev/null 2>&1
    rc=$?
    if (( rc == 0 )); then printf '%s' "$body" | _lic_b64u_decode 2>/dev/null; echo; fi
    rm -rf "$tmp"
    return $rc
}

# payload of the installed token when it is valid right now (signature, machine, dates)
_lic_payload() {
    local p mid now
    p=$(license_verify_token) || return 1
    mid=$(license_machine_id 2>/dev/null) || return 1
    now=$(date +%s)
    jq -e --arg m "$mid" --argjson now "$now" \
        '.machine_id == $m and .valid_until > $now and (.expires_at == null or .expires_at > $now)' <<<"$p" >/dev/null 2>&1 || return 1
    echo "$p"
}

license_plan() {
    local p; p=$(_lic_payload) || { echo none; return 1; }
    jq -r '.plan' <<<"$p"
}

license_has_feature() {   # name
    local p; p=$(_lic_payload) || return 1
    jq -e --arg f "$1" '.features | index($f) != null' <<<"$p" >/dev/null 2>&1
}

# save a token returned by the hub after checking it with the pinned key
_lic_save_token() {   # token
    local tmp; tmp=$(mktemp "$LICENSE_DIR/.license.token.XXXXXX") || return 1
    printf '%s\n' "$1" > "$tmp"; chmod 600 "$tmp"
    local p; p=$(license_verify_token "$tmp") || { rm -f "$tmp"; print_error "license: token signature does not match the pinned hub key ($LICENSE_PUB)"; return 1; }
    if ! jq -e --arg m "$(license_machine_id)" '.machine_id == $m' <<<"$p" >/dev/null; then
        rm -f "$tmp"; print_error "license: token was issued for another machine"; return 1
    fi
    mv -f "$tmp" "$LICENSE_TOKEN"
}

_lic_cron_install() {
    [[ -d "$(dirname "$LICENSE_CRON")" ]] || return 0
    local bin; bin=$(command -v dkvps 2>/dev/null || echo /usr/bin/dkvps)
    local h; h=$(license_machine_id | cut -c1-4)
    local min=$(( 16#${h:-0} % 60 ))   # spread refreshes over the hour
    printf '# DKVPS license token refresh (offline grace: 7 days)\n%d 4 * * * root %s license refresh --quiet >/dev/null 2>&1\n' "$min" "$bin" > "$LICENSE_CRON"
    chmod 644 "$LICENSE_CRON"
}

_lic_request_json() {   # key
    jq -cn --arg k "$1" --arg m "$(license_machine_id)" --arg h "$(hostname 2>/dev/null)" --arg v "${DKVPS_VERSION:-}" \
        '{key:$k, machine_id:$m, hostname:$h, version:$v}'
}

# ------------------------------------------------------------------
# commands
# ------------------------------------------------------------------
license_activate() {
    local key="" hub="" repin=0
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --hub) hub="${2:-}"; shift ;;
            --repin) repin=1 ;;
            --quiet|-q) LICENSE_QUIET=1 ;;
            -*) print_error "Unknown option $1"; return 1 ;;
            *) key="$1" ;;
        esac; shift
    done
    _lic_need || return 1
    [[ -n "$key" ]] || { print_error "Usage: dkvps license activate <KEY> [--hub URL]"; return 1; }
    key=$(_lic_key_norm "$key") || { print_error "Invalid license key format (DKVPS-XXXXX-XXXXX-XXXXX-XXXXX)"; return 1; }
    hub=$(_lic_hub "$hub")
    [[ "$hub" =~ ^https?://[A-Za-z0-9.:_-]+(/[A-Za-z0-9._/-]*)?$ ]] || { print_error "Invalid hub URL: $hub"; return 1; }
    [[ "$hub" == "$HUB_URL_DEFAULT" ]] && print_warning "Using placeholder hub $hub (set --hub or DKVPS_HUB_URL)"
    mkdir -p "$LICENSE_DIR"; touch "$LICENSE_CONF"; chmod 600 "$LICENSE_CONF"

    _lic_say print_info "Activating $(_lic_mask "$key") on $hub ..."
    _lic_post "$hub/api/v1/license/activate" "$(_lic_request_json "$key")"
    if [[ "$LIC_HTTP" != 200 ]]; then
        [[ "$LIC_HTTP" == 000 ]] && { print_error "Cannot reach the license hub ($hub)"; return 1; }
        print_error "Activation failed ($LIC_HTTP): $(_lic_err)"; return 1
    fi

    # pin the hub signing key on first activation; refuse a different one later
    local pem; pem=$(jq -r '.pubkey.pem // empty' <<<"$LIC_BODY")
    [[ "$pem" == *"BEGIN PUBLIC KEY"* ]] || { print_error "Hub returned no public key"; return 1; }
    if [[ -s "$LICENSE_PUB" && $repin -eq 0 ]]; then
        if [[ "$(tr -d '\n' < "$LICENSE_PUB")" != "$(printf '%s' "$pem" | tr -d '\n')" ]]; then
            print_error "Hub signing key differs from the pinned key ($LICENSE_PUB). If the hub really changed its key, re-run with --repin."
            return 1
        fi
    else
        printf '%s\n' "$pem" > "$LICENSE_PUB"; chmod 644 "$LICENSE_PUB"
    fi

    _lic_save_token "$(jq -r '.token' <<<"$LIC_BODY")" || return 1
    set_config key "$key" "$LICENSE_CONF"
    set_config hub_url "$hub" "$LICENSE_CONF"
    _lic_cron_install
    _lic_say print_success "License active: plan $(license_plan), valid offline until $(date -d "@$(jq -r '.license.valid_until' <<<"$LIC_BODY")" '+%Y-%m-%d %H:%M')"
}

license_refresh() {
    while [[ $# -gt 0 ]]; do case "$1" in --quiet|-q) LICENSE_QUIET=1 ;; esac; shift; done
    _lic_need || return 1
    local key hub; key=$(get_config key "$LICENSE_CONF"); hub=$(_lic_hub)
    [[ -n "$key" ]] || { _lic_say print_error "No license on this server (dkvps license activate <KEY>)"; return 1; }
    _lic_post "$hub/api/v1/license/refresh" "$(_lic_request_json "$key")"
    case "$LIC_HTTP" in
        200)
            _lic_save_token "$(jq -r '.token' <<<"$LIC_BODY")" || return 1
            _lic_say print_success "License refreshed: plan $(license_plan), valid until $(date -d "@$(jq -r '.license.valid_until' <<<"$LIC_BODY")" '+%Y-%m-%d %H:%M')" ;;
        403|404)
            # revoked / expired / unknown key / activation removed: drop the token now
            rm -f "$LICENSE_TOKEN"
            print_error "License refresh refused ($LIC_HTTP): $(_lic_err). Token removed."
            return 1 ;;
        000)
            _lic_say print_warning "Cannot reach the license hub ($hub): keeping the current token (offline grace)"
            return 1 ;;
        *)
            _lic_say print_warning "License hub error ($LIC_HTTP): $(_lic_err). Keeping the current token."
            return 1 ;;
    esac
}

license_deactivate() {
    _lic_need || return 1
    local key hub; key=$(get_config key "$LICENSE_CONF"); hub=$(_lic_hub)
    [[ -n "$key" ]] || { print_error "No license on this server"; return 1; }
    _lic_post "$hub/api/v1/license/deactivate" "$(_lic_request_json "$key")"
    if [[ "$LIC_HTTP" != 200 ]]; then
        print_warning "Hub did not confirm ($LIC_HTTP $(_lic_err)): removing the local license anyway"
    fi
    rm -f "$LICENSE_TOKEN" "$LICENSE_CRON"
    sed -i '/^key=/d' "$LICENSE_CONF"
    print_success "License deactivated on this server"
}

license_status() {
    local key hub p raw state="none"
    key=$(get_config key "$LICENSE_CONF" 2>/dev/null); hub=$(_lic_hub)
    if [[ -s "$LICENSE_TOKEN" ]]; then
        if raw=$(license_verify_token 2>/dev/null); then
            if p=$(_lic_payload); then state="valid"
            elif ! jq -e --arg m "$(license_machine_id)" '.machine_id == $m' <<<"$raw" >/dev/null 2>&1; then state="wrong_machine"
            else state="expired"; fi
        else state="invalid_signature"; fi
    fi
    local src="${p:-$raw}"
    if [[ "${JSON_MODE:-false}" == true ]]; then
        jq -cn --arg state "$state" --arg key "$(_lic_mask "$key")" --arg hub "$hub" --argjson p "${src:-null}" \
            '{state:$state, valid:($state=="valid"), key:$key, hub:$hub, plan:($p.plan // null), features:($p.features // []),
              expires_at:($p.expires_at // null), valid_until:($p.valid_until // null), issued_at:($p.issued_at // null)}'
        [[ "$state" == valid ]]; return
    fi
    echo ""
    print_subheader "DKVPS License"
    echo ""
    local color="$GREEN"; [[ "$state" == valid ]] || color="$YELLOW"
    print_status_line "State" "$state" "$color"
    print_status_line "Key" "$( [[ -n $key ]] && _lic_mask "$key" || echo '-')"
    print_status_line "Hub" "$hub"
    if [[ -n "$src" ]]; then
        local exp vu
        exp=$(jq -r '.expires_at // empty' <<<"$src"); vu=$(jq -r '.valid_until' <<<"$src")
        print_status_line "Plan" "$(jq -r '.plan' <<<"$src")"
        print_status_line "Features" "$(jq -r '.features | join(", ")' <<<"$src")"
        print_status_line "Expires" "$( [[ -n $exp ]] && date -d "@$exp" '+%Y-%m-%d' || echo never)"
        print_status_line "Valid offline until" "$(date -d "@$vu" '+%Y-%m-%d %H:%M')"
    fi
    echo ""
    case "$state" in
        none) print_info "No license. Activate: dkvps license activate <KEY>" ;;
        expired) print_warning "Token is out of date: dkvps license refresh" ;;
        wrong_machine|invalid_signature) print_error "Token is not valid here: dkvps license activate <KEY>" ;;
    esac
    [[ "$state" == valid ]]
}
