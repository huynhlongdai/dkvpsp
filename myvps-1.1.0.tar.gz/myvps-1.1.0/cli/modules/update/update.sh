#!/bin/bash
#
# MyVPS self-update
#
#   myvps update              download latest release, verify sha256, apply, auto-rollback on failure
#   myvps update check        is a newer release on the mirror? (exit 10 = yes)
#   myvps update to X.Y.Z     install a specific release (up or down)
#   myvps update rollback     restore the version that was running before the last update
#   myvps update notify on|off  daily check at SSH login (default on, costs nothing between checks)
#   myvps update system       apt/dnf upgrade of the OS packages
#
# Mirror layout (built by scripts/release.sh):
#   <mirror>/get.sh  <mirror>/latest ("X.Y.Z <sha256>")  <mirror>/myvps-X.Y.Z.tar.gz(.sha256)
#
# What gets replaced: /etc/myvps/menu (CLI), /opt/myvps/agent, /opt/myvps/dashboard.
# What never gets touched: /etc/myvps/*.conf, domains, sites, DBs, certs, secrets.
# Version-specific migrations live in <release>/upgrade/X.Y.Z.sh and run once, in order.

MYVPS_UPD_STATE=/var/lib/myvps/update
MYVPS_RELEASE_CONF=/etc/myvps/release

_upd_conf() { sed -n "s/^$1=//p" "$MYVPS_RELEASE_CONF" 2>/dev/null | head -1; }
_upd_mirror() { local m="${MYVPS_MIRROR:-$(_upd_conf mirror)}"; echo "${m%/}"; }
_upd_current() {
    local v; v=$(cat /etc/myvps/menu/VERSION 2>/dev/null)
    [[ -n "$v" ]] || v=$(sed -n 's/^version=//p' /etc/myvps/.myvps.conf 2>/dev/null | head -1)
    echo "${v:-0.0.0}"
}
_upd_fetch() { curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 15 ${MYVPS_TOKEN:+-H "Authorization: Bearer $MYVPS_TOKEN"} "$1" -o "$2"; }
_upd_newer() { [[ "$1" != "$2" && "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -1)" == "$1" ]]; }

# latest -> "X.Y.Z sha"
# (messages go to stderr: callers capture stdout)
_upd_latest() {
    local m; m=$(_upd_mirror)
    [[ -n "$m" ]] || { print_error >&2 "No mirror configured (/etc/myvps/release or MYVPS_MIRROR)"; return 1; }
    local f; f=$(mktemp)
    if ! _upd_fetch "$m/latest" "$f"; then rm -f "$f"; print_error >&2 "Cannot reach $m/latest"; return 1; fi
    local v s; read -r v s < "$f"; rm -f "$f"
    [[ "$v" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ && "$s" =~ ^[0-9a-f]{64}$ ]] || { print_error >&2 "Malformed release index on mirror"; return 1; }
    echo "$v $s"
}

# download + verify + unpack into /opt/myvps/releases/<v>; prints the dir
_upd_download() {
    local v="$1" sum="$2" m tmp dest
    m=$(_upd_mirror); tmp=$(mktemp -d)
    if [[ -z "$sum" ]]; then
        _upd_fetch "$m/myvps-$v.tar.gz.sha256" "$tmp/sum" || { rm -rf "$tmp"; print_error >&2 "Release $v not on mirror"; return 1; }
        read -r sum _ < "$tmp/sum"
    fi
    _upd_fetch "$m/myvps-$v.tar.gz" "$tmp/a.tgz" || { rm -rf "$tmp"; print_error >&2 "Download failed"; return 1; }
    echo "$sum  $tmp/a.tgz" | sha256sum -c --quiet - >/dev/null 2>&1 || { rm -rf "$tmp"; print_error >&2 "Checksum mismatch: refusing"; return 1; }
    dest=/opt/myvps/releases/$v
    rm -rf "$dest.new"; mkdir -p "$dest.new"
    tar -xzf "$tmp/a.tgz" -C "$dest.new" --strip-components=1 --no-same-owner
    rm -rf "$tmp"
    [[ -f "$dest.new/cli/myvps" ]] || { rm -rf "$dest.new"; print_error >&2 "Archive incomplete"; return 1; }
    rm -rf "$dest"; mv "$dest.new" "$dest"
    echo "$dest"
}

_upd_restart_services() {
    systemctl daemon-reload
    if systemctl is-enabled -q myvps-agent.socket 2>/dev/null; then
        systemctl stop myvps-agent.service 2>/dev/null || true   # next connection starts the new code
    elif systemctl is-enabled -q myvps-agent.service 2>/dev/null; then
        systemctl restart myvps-agent.service
    fi
    systemctl is-active -q myvps-bot 2>/dev/null && systemctl restart myvps-bot
    return 0
}

# snapshot of the running version; promoted to prev.* only when the update succeeds,
# so a failed update never overwrites what `myvps update rollback` restores
_upd_snapshot() {
    mkdir -p "$MYVPS_UPD_STATE"
    tar -czf "$MYVPS_UPD_STATE/pending.tar.gz" -C / etc/myvps/menu opt/myvps/agent opt/myvps/dashboard 2>/dev/null
    _upd_current > "$MYVPS_UPD_STATE/pending.version"
}
_upd_promote_snapshot() {
    mv -f "$MYVPS_UPD_STATE/pending.tar.gz" "$MYVPS_UPD_STATE/prev.tar.gz"
    mv -f "$MYVPS_UPD_STATE/pending.version" "$MYVPS_UPD_STATE/prev.version"
}

_upd_restore_snapshot() {
    local which="${1:-prev}"
    [[ -f "$MYVPS_UPD_STATE/$which.tar.gz" ]] || { print_error "No previous version saved"; return 1; }
    local t; t=$(mktemp -d)
    tar -xzf "$MYVPS_UPD_STATE/$which.tar.gz" -C "$t"
    _upd_swap_dir "$t/etc/myvps/menu" /etc/myvps/menu
    _upd_swap_dir "$t/opt/myvps/agent" /opt/myvps/agent
    _upd_swap_dir "$t/opt/myvps/dashboard" /opt/myvps/dashboard
    rm -rf "$t"
    local pv; pv=$(cat "$MYVPS_UPD_STATE/$which.version" 2>/dev/null)
    [[ -n "$pv" ]] && sed -i "s/^version=.*/version=$pv/" /etc/myvps/.myvps.conf
    _upd_restart_services
}

# atomic-ish directory swap: running bash/node keep their open inodes
_upd_swap_dir() {
    local src="$1" dst="$2"
    [[ -d "$src" ]] || return 0
    rm -rf "$dst.new" "$dst.old"
    cp -a "$src" "$dst.new"
    [[ -d "$dst" ]] && mv "$dst" "$dst.old"
    mv "$dst.new" "$dst"
    rm -rf "$dst.old"
}

# Apply an unpacked release dir. Runs from the NEW code (get.sh / update re-exec here).
_upd_apply() {
    local src="$1" from to staged rc=0
    from=$(_upd_current); to=$(cat "$src/cli/VERSION")
    print_info "Applying MyVPS $from -> $to"

    # 1) syntax-check every shell file before touching anything
    local bad=0 f
    while IFS= read -r -d '' f; do
        bash -n "$f" 2>/dev/null || { print_error "Syntax error in ${f#$src/}"; bad=1; }
    done < <(find "$src/cli" -type f \( -name '*.sh' -o -name myvps \) -print0)
    (( bad )) && { print_error "Release rejected, nothing changed"; return 1; }

    _upd_snapshot

    # 2) stage agent (npm only when dependencies changed)
    staged=$(mktemp -d /opt/myvps/.stage.XXXX)
    cp -a "$src/agent" "$staged/agent"
    rm -rf "$staged/agent/node_modules"
    if [[ -d /opt/myvps/agent/node_modules ]] && cmp -s "$src/agent/package.json" /opt/myvps/agent/package.json \
        && { [[ ! -f "$src/agent/package-lock.json" ]] || cmp -s "$src/agent/package-lock.json" /opt/myvps/agent/package-lock.json; }; then
        cp -a /opt/myvps/agent/node_modules "$staged/agent/"
    else
        print_info "Agent dependencies changed: npm install"
        (cd "$staged/agent" && npm install --omit=dev --no-audit --no-fund --loglevel=error) || rc=1
    fi
    if (( rc )); then rm -rf "$staged"; print_error "npm install failed, nothing changed"; return 1; fi

    # 3) swap
    mkdir -p "$staged/menu" && cp -a "$src/cli/." "$staged/menu/"
    find "$staged/menu" -type f -exec chmod 755 {} \;
    _upd_swap_dir "$staged/menu" /etc/myvps/menu
    _upd_swap_dir "$staged/agent" /opt/myvps/agent
    _upd_swap_dir "$src/dashboard" /opt/myvps/dashboard
    rm -rf "$staged"
    ln -sf /etc/myvps/menu/myvps /usr/bin/myvps

    # 4) migrations: upgrade/X.Y.Z.sh for from < X.Y.Z <= to
    if [[ -d "$src/upgrade" ]]; then
        local h hv
        for h in $(ls "$src/upgrade"/*.sh 2>/dev/null | sort -V); do
            hv=$(basename "$h" .sh)
            _upd_newer "$hv" "$from" || continue
            _upd_newer "$hv" "$to" && continue
            print_info "Migration $hv"
            if ! MYVPS_FROM="$from" MYVPS_TO="$to" bash "$h"; then rc=1; print_error "Migration $hv failed"; break; fi
        done
    fi

    # 5) post-checks, else roll back
    if (( rc == 0 )); then
        /usr/bin/myvps version >/dev/null 2>&1 || { rc=1; print_error "New CLI does not start"; }
        if command -v nginx >/dev/null && ! nginx -t >/dev/null 2>&1; then rc=1; print_error "nginx -t fails after update"; fi
    fi
    if (( rc )); then
        print_warning "Rolling back to $from"
        _upd_restore_snapshot pending
        rm -f "$MYVPS_UPD_STATE"/pending.*
        nginx -t >/dev/null 2>&1 && systemctl reload nginx 2>/dev/null
        return 1
    fi

    _upd_promote_snapshot
    sed -i "s/^version=.*/version=$to/" /etc/myvps/.myvps.conf
    printf 'mirror=%s\nrelease=%s\n' "$(_upd_mirror)" "$to" > "$MYVPS_RELEASE_CONF"
    rm -f "$MYVPS_UPD_STATE/available"
    _upd_restart_services
    systemctl reload nginx 2>/dev/null || true
    ls -1d /opt/myvps/releases/*/ 2>/dev/null | sort -V | head -n -3 | xargs -r rm -rf
    print_success "MyVPS updated: $from -> $to"
}

update_check() {
    local quiet="${1:-}" cur lv
    cur=$(_upd_current)
    lv=$(_upd_latest) || return 1
    lv=${lv%% *}
    mkdir -p "$MYVPS_UPD_STATE"; date +%s > "$MYVPS_UPD_STATE/checked"
    if _upd_newer "$lv" "$cur"; then
        echo "$lv" > "$MYVPS_UPD_STATE/available"
        [[ "$quiet" == -q ]] || echo "Update available: $cur -> $lv  (run: myvps update)"
        return 10
    fi
    rm -f "$MYVPS_UPD_STATE/available"
    [[ "$quiet" == -q ]] || echo "MyVPS $cur is up to date"
    return 0
}

update_to() {
    local want="$1" sum="" dir cur lv
    cur=$(_upd_current)
    if [[ -z "$want" ]]; then
        lv=$(_upd_latest) || return 1
        want=${lv%% *}; sum=${lv##* }
        if ! _upd_newer "$want" "$cur" && [[ "${MYVPS_FORCE:-0}" != 1 ]]; then
            print_success "MyVPS $cur is already the latest"; return 0
        fi
    fi
    [[ "$want" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { print_error "Bad version: $want"; return 1; }
    exec 9>/run/myvps-get.lock; flock -n 9 || { print_error "Another install/update is running"; return 1; }
    print_info "Downloading MyVPS $want"
    dir=$(_upd_download "$want" "$sum") || return 1
    # let the new release apply itself (new migrations / new apply logic)
    exec bash "$dir/cli/myvps" update --from "$dir"
}

update_notify() {
    case "$1" in
        on)
            cat > /etc/profile.d/myvps-update.sh <<'EOF'
# MyVPS: once a day, check for a new release in the background at login (root only)
if [ "$(id -u)" = 0 ] && [ -t 1 ] && command -v myvps >/dev/null 2>&1; then
    _m=/var/lib/myvps/update
    if [ -s "$_m/available" ]; then
        printf '\033[1;33mMyVPS %s is available.\033[0m Run: myvps update\n' "$(cat "$_m/available")"
    fi
    if [ ! -f "$_m/checked" ] || [ $(( $(date +%s) - $(cat "$_m/checked" 2>/dev/null || echo 0) )) -gt 86400 ]; then
        (myvps update check -q >/dev/null 2>&1 &)
    fi
    unset _m
fi
EOF
            chmod 644 /etc/profile.d/myvps-update.sh
            print_success "Daily update check at login: on" ;;
        off) rm -f /etc/profile.d/myvps-update.sh; print_success "Daily update check at login: off" ;;
        *) echo "Usage: myvps update notify on|off"; return 2 ;;
    esac
}

update_handler() {
    local action="${1:-}"; shift 2>/dev/null || true
    case "$action" in
        "")         require_root; update_to "" ;;
        --from)     require_root; _upd_apply "${1:?release dir}" ;;
        check)      update_check "${1:-}" ;;
        to)         require_root; update_to "${1:?Usage: myvps update to X.Y.Z}" ;;
        rollback)   require_root
                    local pv; pv=$(cat "$MYVPS_UPD_STATE/prev.version" 2>/dev/null)
                    _upd_restore_snapshot && print_success "Rolled back to ${pv:-previous version}" ;;
        notify)     require_root; update_notify "$1" ;;
        system)     require_root
                    if command -v apt-get >/dev/null; then apt-get update && apt-get upgrade -y; else dnf update -y; fi ;;
        menu)       source "${CLI_DIR}/modules/monitor/monitor.sh"; update_myvps ;;
        *)          echo "Usage: myvps update [check [-q] | to X.Y.Z | rollback | notify on|off | system]"; return 2 ;;
    esac
}
