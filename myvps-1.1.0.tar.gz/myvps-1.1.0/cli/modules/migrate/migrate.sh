#!/bin/bash
#
# MyVPS - move sites between servers running MyVPS
#
#   myvps migrate push <domain|--all> <user@host> [-p port] [-i key]
#       streams each site (files, DB, SSL, config flags) over SSH and imports
#       it on the target with `myvps migrate receive`; the source is untouched.
#   myvps migrate export <domain> > site.tar     (package to stdout)
#   myvps migrate import <domain> < site.tar     (package from stdin)
#
# Target needs MyVPS installed and SSH key login for a user that may run
# `sudo myvps` (or root). Switch DNS after verifying the site on the target.
#

migrate_handler() {
    local action="$1"; shift || true
    case "$action" in
        push)    migrate_push "$@" ;;
        export)  site_pack_export "$@" ;;
        import|receive) migrate_receive "$@" ;;
        *) echo "Usage: myvps migrate push <domain|--all> <user@host> [-p port] [-i key] | export <domain> | import <domain>"; return 1 ;;
    esac
}

migrate_receive() {
    local domain="${1:-}"
    validate_domain "$domain" || return 1
    local work=/var/lib/myvps/incoming/$domain.$$
    mkdir -p "$work"; chmod 700 /var/lib/myvps/incoming "$work"
    tar -C "$work" -xf - || { print_error "Bad package stream"; rm -rf "$work"; return 1; }
    site_import "$domain" "$work"; local rc=$?
    rm -rf "$work"
    return $rc
}

migrate_push() {
    local target="" dest="" port=22 key="" domains=() d
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -p) port="$2"; shift ;;
            -i) key="$2"; shift ;;
            *) if [[ -z "$target" ]]; then target="$1"; else dest="$1"; fi ;;
        esac
        shift
    done
    [[ -n "$target" && "$dest" =~ ^[A-Za-z0-9._-]+@[A-Za-z0-9.:-]+$ ]] || { print_error "Usage: myvps migrate push <domain|--all> <user@host> [-p port] [-i key]"; return 1; }
    [[ "$port" =~ ^[0-9]+$ ]] || { print_error "Bad port"; return 1; }
    local ssh=(ssh -p "$port" -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o Compression=yes)
    [[ -n "$key" ]] && ssh+=(-i "$key")
    local remote="myvps"; [[ "${dest%%@*}" != "root" ]] && remote="sudo -n myvps"
    "${ssh[@]}" "$dest" "$remote info >/dev/null 2>&1 || command -v myvps >/dev/null" || { print_error "Cannot run myvps on $dest (SSH key / sudo / MyVPS installed?)"; return 1; }
    if [[ "$target" == "--all" ]]; then mapfile -t domains < <(list_domain_names); else domains=("$target"); fi
    local ok=0 fail=0
    for d in "${domains[@]}"; do
        [[ -n "$d" ]] || continue
        local t0=$SECONDS
        print_info "Moving $d -> $dest"
        if site_pack_export "$d" | "${ssh[@]}" "$dest" "$remote migrate receive $d"; then
            print_success "$d moved ($((SECONDS - t0))s)"; ok=$((ok+1))
        else
            print_error "$d failed"; fail=$((fail+1))
        fi
    done
    echo "Done: $ok moved, $fail failed. Verify on the target, then point DNS to it."
    [[ $fail -eq 0 ]]
}

# ------------------------------------------------------------------
# Staging: myvps domain staging <domain> create|push|delete|info
#   create  staging.<domain> = copy of files + DB (URLs rewritten), password
#           protected and hidden from search engines; no SSL/cache/limits copied
#   push    live is exported to /var/backups/myvps first, then staging replaces
#           live files + DB; live keeps its DB logins, SSL, cache, redis, limits
# ------------------------------------------------------------------
staging_handler() {
    local domain="${1:-}" action="${2:-info}"
    validate_domain "$domain" >/dev/null 2>&1 || { echo "Usage: myvps domain staging <domain> create|push|delete|info"; return 1; }
    local st="staging.$domain"
    case "$action" in
        create)
            domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
            domain_exists "$st" && { print_error "$st already exists (push or delete it first)"; return 1; }
            print_info "Copying $domain -> $st ..."
            site_pack_prepare "$domain" || return 1
            ( cd "/home/$(get_username "$domain")/$domain" && tar "${MYVPS_PACK_EXCLUDES[@]}" --exclude=./ssl -cf - . ) | migrate_receive "$st" >/dev/null || { site_pack_cleanup "$domain"; print_error "Copy failed"; return 1; }
            site_pack_cleanup "$domain"
            set_config staging_of "$domain" "$MYVPS_USER_DIR/.$st.conf"
            _staging_protect "$st"
            print_success "Staging ready: http://$st  (user: staging  password: $(cat "/etc/myvps/nginx/staging-$st.pass"))"
            print_info "Point DNS of $st to this server, test, then: myvps domain staging $domain push" ;;
        push)
            domain_exists "$st" || { print_error "No staging site for $domain"; return 1; }
            confirm "Replace LIVE $domain with $st (live is backed up first)?" || return 0
            mkdir -p /var/backups/myvps; chmod 0700 /var/backups/myvps
            local bk="/var/backups/myvps/$domain-before-push-$(date +%Y%m%d-%H%M%S).tar"
            site_pack_export "$domain" > "$bk" || { print_error "Backup of live failed, nothing changed"; rm -f "$bk"; return 1; }
            print_info "Live backed up to $bk"
            site_pack_prepare "$st" || return 1
            ( cd "/home/$(get_username "$st")/$st" && tar "${MYVPS_PACK_EXCLUDES[@]}" --exclude=./ssl -cf - . ) | migrate_receive "$domain" || { site_pack_cleanup "$st"; print_error "Push failed. Restore: myvps migrate import $domain < $bk"; return 1; }
            site_pack_cleanup "$st"
            local u; u=$(get_username "$domain")
            sed -i "/^staging_protect=/d" "$MYVPS_USER_DIR/.$domain.conf"
            if [[ -f "/home/$u/$domain/public_html/wp-config.php" ]] && command -v wp >/dev/null; then
                sudo -u "$u" HOME="/home/$u/$domain/tmp" wp --path="/home/$u/$domain/public_html" --skip-plugins --skip-themes option update blog_public 1 >/dev/null 2>&1
            fi
            load_domain_config "$domain"; site_write_vhost "$domain" "$u" "${app:-}"; reload_nginx >/dev/null 2>&1
            site_cache_purge "$domain" >/dev/null 2>&1
            print_success "$st is now live on $domain (backup: $bk)" ;;
        delete)
            domain_exists "$st" || { print_error "No staging site for $domain"; return 1; }
            MYVPS_ASSUME_YES=1 domain_delete "$st" >/dev/null
            rm -f "/etc/myvps/nginx/staging-$st".{htpasswd,pass}
            print_success "Deleted $st" ;;
        info|*)
            if domain_exists "$st"; then echo "$st (copy of $domain), password: $(cat "/etc/myvps/nginx/staging-$st.pass" 2>/dev/null)"; else echo "no staging for $domain"; fi ;;
    esac
}

_staging_protect() {
    local st="$1" u; u=$(get_username "$st")
    local pass; pass=$(generate_password 16)
    printf 'staging:%s\n' "$(openssl passwd -apr1 "$pass")" > "/etc/myvps/nginx/staging-$st.htpasswd"
    echo "$pass" > "/etc/myvps/nginx/staging-$st.pass"; chmod 0600 "/etc/myvps/nginx/staging-$st.pass"
    chown root:"${NGINX_USER:-www-data}" "/etc/myvps/nginx/staging-$st.htpasswd"; chmod 0640 "/etc/myvps/nginx/staging-$st.htpasswd"
    cat > "$MYVPS_SITE_INC_DIR/$st.custom" <<EOF
# staging copy: password + no indexing (myvps domain staging)
auth_basic "Staging";
auth_basic_user_file /etc/myvps/nginx/staging-$st.htpasswd;
EOF
    if [[ -f "/home/$u/$st/public_html/wp-config.php" ]] && command -v wp >/dev/null; then
        sudo -u "$u" HOME="/home/$u/$st/tmp" wp --path="/home/$u/$st/public_html" --skip-plugins --skip-themes option update blog_public 0 >/dev/null 2>&1
    fi
    reload_nginx >/dev/null 2>&1
}
