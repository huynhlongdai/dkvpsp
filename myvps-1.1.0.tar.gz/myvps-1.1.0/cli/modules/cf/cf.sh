#!/bin/bash
#
# MyVPS - Cloudflare
#
#   myvps cf token <api_token|->          same token as SSL DNS-01 (Zone:DNS:Edit, + Zone Settings:Edit for attack)
#   myvps cf dns <domain> [--dns-only]    point domain (+ www) to this server, proxied by default
#   myvps cf attack <domain> on|off       "I'm Under Attack" mode
#   myvps cf auto <domain> on|off         watchdog turns attack mode on when load stays very high
#   myvps cf realip [on|off]              real visitor IPs in logs, fail2ban and rate limits
#

CF_API="${MYVPS_CF_API:-https://api.cloudflare.com/client/v4}"
CF_ENV=/etc/myvps/ssl/cloudflare.env
CF_REALIP=/etc/myvps/nginx/cloudflare-realip.conf

cf_handler() {
    local action="${1:-}"; shift 2>/dev/null
    case "$action" in
        token)  source "${CLI_DIR}/modules/ssl/ssl.sh"; ssl_cloudflare "$@" ;;
        dns)    cf_dns "$@" ;;
        attack) cf_attack "$@" ;;
        auto)   cf_auto "$@" ;;
        realip) cf_realip "${1:-on}" ;;
        *) sed -n '3,10p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; return 1 ;;
    esac
}

_cf() {   # METHOD path [json]
    local tok; tok=$(grep -E '^CF_Token=' "$CF_ENV" 2>/dev/null | cut -d= -f2-)
    [[ -n "$tok" ]] || { echo '{"success":false,"errors":[{"message":"no token: myvps cf token <token>"}]}'; return 1; }
    printf 'header = "Authorization: Bearer %s"\n' "$tok" | \
        curl -s --max-time 20 -K - -X "$1" -H 'Content-Type: application/json' ${3:+--data "$3"} "$CF_API$2"
}
_cf_err() { jq -r '[.errors[]?.message] | join("; ")' <<<"$1" 2>/dev/null; }

_cf_zone() {   # domain -> zone id (tries example.com for a.b.example.com)
    local n="$1" r id
    while [[ "$n" == *.* ]]; do
        r=$(_cf GET "/zones?name=$n&status=active")
        id=$(jq -r '.result[0].id // empty' <<<"$r" 2>/dev/null)
        [[ -n "$id" ]] && { echo "$id"; return 0; }
        n="${n#*.}"
    done
    return 1
}

_cf_upsert_a() {   # zone name ip proxied
    local z="$1" name="$2" ip="$3" px="$4" r id body
    body=$(jq -nc --arg n "$name" --arg ip "$ip" --argjson p "$px" '{type:"A",name:$n,content:$ip,ttl:1,proxied:$p}')
    r=$(_cf GET "/zones/$z/dns_records?type=A&name=$name")
    id=$(jq -r '.result[0].id // empty' <<<"$r")
    if [[ -n "$id" ]]; then r=$(_cf PUT "/zones/$z/dns_records/$id" "$body"); else r=$(_cf POST "/zones/$z/dns_records" "$body"); fi
    [[ "$(jq -r .success <<<"$r")" == "true" ]] || { print_error "$name: $(_cf_err "$r")"; return 1; }
    print_success "$name -> $ip ($( [[ $px == true ]] && echo proxied || echo DNS only ))"
}

cf_dns() {
    local domain="" px=true
    while [[ $# -gt 0 ]]; do case "$1" in --dns-only) px=false ;; --proxied) px=true ;; *) domain="$1" ;; esac; shift; done
    validate_domain "$domain" >/dev/null 2>&1 || { print_error "Usage: myvps cf dns <domain> [--dns-only]"; return 1; }
    local z; z=$(_cf_zone "$domain") || { print_error "No active Cloudflare zone for $domain on this token"; return 1; }
    source "${CLI_DIR}/modules/ssl/ssl.sh"
    local ip; ip=$(_ssl_public_ip)
    _cf_upsert_a "$z" "$domain" "$ip" "$px" || return 1
    [[ "$(is_subdomain "$domain")" == "no" ]] && _cf_upsert_a "$z" "www.$domain" "$ip" "$px"
    [[ "$px" == "true" && ! -f "$CF_REALIP" ]] && cf_realip on
    return 0
}

cf_attack() {
    local domain="$1" state="${2:-on}" level
    [[ "$state" == "on" ]] && level=under_attack || level=medium
    local z; z=$(_cf_zone "$domain") || { print_error "No active Cloudflare zone for $domain"; return 1; }
    local r; r=$(_cf PATCH "/zones/$z/settings/security_level" "{\"value\":\"$level\"}")
    [[ "$(jq -r .success <<<"$r")" == "true" ]] || { print_error "$(_cf_err "$r") (token needs Zone Settings:Edit)"; return 1; }
    print_success "Under Attack mode $state for $domain"
}

cf_auto() {
    local domain="$1" state="${2:-on}"
    domain_exists "$domain" || { print_error "Domain $domain not found"; return 1; }
    set_config cf_shield_auto "$([[ $state == on ]] && echo 1 || echo 0)" "$MYVPS_USER_DIR/.$domain.conf"
    print_success "Automatic Under Attack for $domain: $state (when load stays above 4x CPU for 5 min)"
}

cf_realip() {
    if [[ "$1" == "off" ]]; then rm -f "$CF_REALIP"; : > "$CF_REALIP.disabled"; reload_nginx >/dev/null; print_success "Cloudflare real IP off"; return; fi
    local v4 v6
    v4=$(curl -s --max-time 10 https://www.cloudflare.com/ips-v4 | grep -E '^[0-9./]+$')
    v6=$(curl -s --max-time 10 https://www.cloudflare.com/ips-v6 | grep -E '^[0-9a-f:./]+$')
    [[ -n "$v4" ]] || v4="173.245.48.0/20 103.21.244.0/22 103.22.200.0/22 103.31.4.0/22 141.101.64.0/18 108.162.192.0/18 190.93.240.0/20 188.114.96.0/20 197.234.240.0/22 198.41.128.0/17 162.158.0.0/15 104.16.0.0/13 104.24.0.0/14 172.64.0.0/13 131.0.72.0/22"
    { echo "# Cloudflare edge ranges (myvps cf realip, refreshed weekly)"
      for r in $v4 $v6; do echo "set_real_ip_from $r;"; done
      echo "real_ip_header CF-Connecting-IP;"; } > "$CF_REALIP.tmp"
    mv "$CF_REALIP.tmp" "$CF_REALIP"; rm -f "$CF_REALIP.disabled"
    local g=/etc/myvps/nginx/global.conf
    grep -q 'cloudflare-realip.conf' "$g" || echo "include $CF_REALIP;" >> "$g"
    printf 'SHELL=/bin/bash\n%s 5 * * 1 root [ -f %s ] && /usr/bin/myvps cf realip on >/dev/null 2>&1\n' "$((RANDOM % 60))" "$CF_REALIP" > /etc/cron.d/myvps-cf-realip
    if nginx -t >/dev/null 2>&1; then reload_nginx >/dev/null; print_success "Cloudflare real IP on ($(grep -c set_real_ip_from "$CF_REALIP") ranges)"
    else sed -i '\#cloudflare-realip.conf#d' "$g"; print_error "nginx rejected the real IP config, reverted"; return 1; fi
}

# called by the watchdog on load transitions
cf_shield_watch() {   # high|ok
    local d
    for d in $(list_domain_configs); do
        site_flag "$d" cf_shield_auto || continue
        if [[ "$1" == "high" ]]; then cf_attack "$d" on >/dev/null 2>&1 && notify_send warn "watch: load high, Cloudflare Under Attack ON for $d"
        else cf_attack "$d" off >/dev/null 2>&1 && notify_send ok "watch: load normal, Cloudflare Under Attack OFF for $d"; fi
    done
}
