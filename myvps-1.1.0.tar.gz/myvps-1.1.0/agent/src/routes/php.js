const express = require('express');
const fs = require('fs');
const { v } = require('../utils/validate');
const { h, myvps, cmd, cmdOk } = require('../utils/helpers');
const { platform } = require('../utils/platform');
const { loadConfig } = require('../utils/config');

const router = express.Router();

router.get('/info', h(async (req, res) => {
    const p = platform(loadConfig());
    const [ver, mods] = await Promise.all([cmd('php', ['-v']), cmd('php', ['-m'])]);
    let pools = [];
    try { pools = fs.readdirSync(p.phpPoolDir).filter(f => f.endsWith('.conf')).map(f => f.slice(0, -5)); } catch { /* none */ }
    res.json({
        version: ver.stdout.split('\n')[0] || '',
        modules: mods.stdout.split('\n').filter(m => m && !m.startsWith('[')),
        pools
    });
}));

router.post('/version', h(async (req, res) => {
    const version = v.phpVersion(req.body.version);
    const r = await myvps(['php', 'version', version], 600000);
    res.json({ message: `PHP switched to ${version}`, output: r.stdout });
}));

router.post('/restart', h(async (req, res) => {
    await cmdOk('systemctl', ['restart', platform(loadConfig()).services['php-fpm']]);
    res.json({ message: 'PHP-FPM restarted' });
}));

module.exports = router;
