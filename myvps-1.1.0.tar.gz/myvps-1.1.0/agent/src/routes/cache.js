const express = require('express');
const { h, cmd, cmdOk } = require('../utils/helpers');
const { platform } = require('../utils/platform');
const { loadConfig } = require('../utils/config');

const router = express.Router();

router.get('/status', h(async (req, res) => {
    const p = platform(loadConfig());
    const [redis, memcached] = await Promise.all([cmd('systemctl', ['is-active', p.services.redis]), cmd('systemctl', ['is-active', 'memcached'])]);
    res.json({ redis: redis.stdout || 'inactive', memcached: memcached.stdout || 'inactive' });
}));

router.post('/redis/flush', h(async (req, res) => {
    await cmdOk('redis-cli', ['FLUSHALL']);
    res.json({ message: 'Redis flushed' });
}));

// OPcache lives inside PHP-FPM; resetting it from php-cli does nothing, so reload FPM instead.
async function resetOpcache() {
    await cmdOk('systemctl', ['reload', platform(loadConfig()).services['php-fpm']]);
}

router.post('/opcache/reset', h(async (req, res) => {
    await resetOpcache();
    res.json({ message: 'OPcache reset (PHP-FPM reloaded)' });
}));

router.post('/clear-all', h(async (req, res) => {
    await Promise.all([cmdOk('redis-cli', ['FLUSHALL']), resetOpcache()]);
    res.json({ message: 'All caches cleared' });
}));

module.exports = router;
