const express = require('express');
const { cmd } = require('../utils/exec');
const { h, cmdOk } = require('../utils/helpers');
const { platform } = require('../utils/platform');
const { loadConfig } = require('../utils/config');
const { v } = require('../utils/validate');

const router = express.Router();
const ALLOWED = ['nginx', 'php-fpm', 'mariadb', 'redis', 'memcached', 'fail2ban'];

async function status(unit) {
    const r = await cmd('systemctl', ['is-active', unit]);
    return r.stdout || 'inactive';
}

router.get('/', h(async (req, res) => {
    const p = platform(loadConfig());
    const services = {};
    await Promise.all(ALLOWED.map(async s => { services[s] = await status(p.services[s]); }));
    res.json({ services });
}));

router.post('/:name/:action', h(async (req, res) => {
    const name = v.oneOf(req.params.name, ALLOWED, 'service');
    const action = v.oneOf(req.params.action, ['start', 'stop', 'restart', 'reload'], 'action');
    const unit = platform(loadConfig()).services[name];
    if (name === 'nginx' && action !== 'stop') {
        const t = await cmd('nginx', ['-t']);
        if (t.code !== 0) return res.status(400).json({ error: 'nginx -t failed: ' + t.stderr });
    }
    await cmdOk('systemctl', [action, unit]);
    res.json({ message: `${name} ${action === 'stop' ? 'stopped' : action + 'ed'}`, status: await status(unit) });
}));

module.exports = router;
