const express = require('express');
const fs = require('fs');
const os = require('os');
const { v } = require('../utils/validate');
const { h, myvps, cmd, cmdOk } = require('../utils/helpers');

const router = express.Router();
const ACME = [process.env.ACME_SH, '/root/.acme.sh/acme.sh', `${os.homedir()}/.acme.sh/acme.sh`].find(p => p && fs.existsSync(p)) || '/root/.acme.sh/acme.sh';

router.get('/', h(async (req, res) => {
    const r = await cmd(ACME, ['--list', '--listraw']);
    const lines = r.stdout.split('\n').filter(Boolean);
    const [head, ...rows] = lines;
    const cols = (head || '').split('|');
    const certificates = rows.map(l => Object.fromEntries(l.split('|').map((x, i) => [cols[i] || i, x])));
    res.json({ certificates });
}));

router.post('/install', h(async (req, res) => {
    const domain = v.domain(req.body.domain);
    const provider = v.oneOf(req.body.provider || 'letsencrypt', ['letsencrypt', 'zerossl'], 'provider');
    const r = await myvps(['ssl', provider === 'zerossl' ? 'install-zerossl' : 'install', domain], 180000);
    res.json({ message: `SSL installed for ${domain}`, output: r.stdout });
}));

router.post('/renew', h(async (req, res) => {
    const r = await cmdOk(ACME, ['--renew-all'], { timeout: 300000 });
    res.json({ message: 'Renewed', output: r.stdout });
}));

router.delete('/:domain', h(async (req, res) => {
    const domain = v.domain(req.params.domain);
    await cmdOk(ACME, ['--remove', '-d', domain]);
    res.json({ message: 'Removed' });
}));

module.exports = router;
