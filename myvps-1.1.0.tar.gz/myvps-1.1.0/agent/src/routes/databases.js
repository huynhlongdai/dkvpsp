const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const { v } = require('../utils/validate');
const { h, mysql, cmd } = require('../utils/helpers');
const { loadConfig } = require('../utils/config');

const router = express.Router();
const SYSTEM_DBS = ['information_schema', 'performance_schema', 'mysql', 'sys'];

router.get('/', h(async (req, res) => {
    const out = await mysql('SHOW DATABASES');
    res.json({ databases: out.split('\n').filter(d => d && !SYSTEM_DBS.includes(d)) });
}));

router.get('/:name/info', h(async (req, res) => {
    const name = v.dbName(req.params.name);
    const [tables, size] = await Promise.all([
        mysql(`SHOW TABLES FROM \`${name}\``),
        mysql(`SELECT ROUND(SUM(data_length+index_length)/1024/1024,2) FROM information_schema.tables WHERE table_schema='${name}'`)
    ]);
    res.json({ name, tables: tables.split('\n').filter(Boolean), size_mb: parseFloat(size) || 0 });
}));

router.post('/', h(async (req, res) => {
    const name = v.dbName(req.body.name);
    const user = req.body.user ? v.dbUser(req.body.user) : null;
    if (SYSTEM_DBS.includes(name.toLowerCase())) return res.status(400).json({ error: 'Reserved name' });
    const password = crypto.randomBytes(16).toString('hex');
    await mysql(`CREATE DATABASE IF NOT EXISTS \`${name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    if (user) {
        await mysql(`CREATE USER IF NOT EXISTS '${user}'@'localhost' IDENTIFIED BY '${password}'; ALTER USER '${user}'@'localhost' IDENTIFIED BY '${password}'; GRANT ALL ON \`${name}\`.* TO '${user}'@'localhost'; FLUSH PRIVILEGES`);
    }
    res.json({ message: 'Created', name, user, password: user ? password : undefined });
}));

router.delete('/:name', h(async (req, res) => {
    const name = v.dbName(req.params.name);
    if (SYSTEM_DBS.includes(name.toLowerCase())) return res.status(400).json({ error: 'Reserved name' });
    await mysql(`DROP DATABASE IF EXISTS \`${name}\``);
    res.json({ message: 'Deleted' });
}));

router.post('/:name/export', h(async (req, res) => {
    const name = v.dbName(req.params.name);
    const c = loadConfig();
    const dir = '/etc/myvps/backup/db';
    fs.mkdirSync(dir, { recursive: true });
    const d = new Date(), p = n => String(n).padStart(2, '0');
    const ts = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
    const file = `${dir}/${name}_${ts}.sql.gz`;
    const { spawn } = require('child_process');
    const { pipeline } = require('stream/promises');
    const zlib = require('zlib');
    const dump = spawn('mysqldump', ['-u', c.db_admin_user || 'admin', '--single-transaction', '--routines', name], { env: { ...process.env, MYSQL_PWD: c.db_admin_password || '' } });
    let err = '';
    dump.stderr.on('data', d => { err += d; });
    const exited = new Promise(r => dump.on('close', r));
    await pipeline(dump.stdout, zlib.createGzip(), fs.createWriteStream(file, { mode: 0o600 }));
    if (await exited !== 0) { fs.rmSync(file, { force: true }); throw new Error(err.trim() || 'mysqldump failed'); }
    res.json({ message: 'Exported', file });
}));

module.exports = router;
