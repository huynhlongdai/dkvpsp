/**
 * Auth route - API key / admin password -> JWT
 * Lightweight: no database, uses /etc/myvps/.myvps.conf for credentials
 */
const express = require('express');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { setConfigValue, CONF_PATH } = require('../utils/config');

// constant-time compare; false when expected is empty/undefined
function safeEqual(given, expected) {
    if (typeof given !== 'string' || typeof expected !== 'string' || !expected) return false;
    const a = crypto.createHash('sha256').update(given).digest();
    const b = crypto.createHash('sha256').update(expected).digest();
    return crypto.timingSafeEqual(a, b);
}

// very small in-memory brute-force limiter: 10 failures / 15 min per IP
const failures = new Map();
const WINDOW = 15 * 60 * 1000, MAX_FAIL = 10;
function limited(ip) {
    const f = failures.get(ip);
    if (!f) return false;
    if (Date.now() - f.first > WINDOW) { failures.delete(ip); return false; }
    return f.count >= MAX_FAIL;
}
function fail(ip) {
    const f = failures.get(ip);
    if (!f || Date.now() - f.first > WINDOW) failures.set(ip, { first: Date.now(), count: 1 });
    else f.count++;
}

module.exports = function (JWT_SECRET, config) {
    const router = express.Router();

    router.post('/login', (req, res) => {
        const ip = req.ip;
        if (limited(ip)) return res.status(429).json({ error: 'Too many failed attempts, try again later' });
        const { api_key, password } = req.body || {};

        if (safeEqual(api_key, config.agent_api_key)) {
            failures.delete(ip);
            const token = jwt.sign({ role: 'dashboard' }, JWT_SECRET, { expiresIn: '7d' });
            return res.json({ token, expires_in: '7d' });
        }
        if (safeEqual(password, config.admin_password)) {
            failures.delete(ip);
            const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '24h' });
            return res.json({ token, expires_in: '24h' });
        }
        fail(ip);
        res.status(401).json({ error: 'Invalid credentials' });
    });

    router.post('/generate-key', (req, res) => {
        const ip = req.ip;
        if (limited(ip)) return res.status(429).json({ error: 'Too many failed attempts, try again later' });
        if (!safeEqual((req.body || {}).password, config.admin_password)) {
            fail(ip);
            return res.status(401).json({ error: 'Admin password required' });
        }
        const newKey = crypto.randomBytes(32).toString('hex');
        try {
            setConfigValue('agent_api_key', newKey);
            config.agent_api_key = newKey;
            res.json({ api_key: newKey });
        } catch (e) {
            res.status(500).json({ error: `Failed to save API key to ${CONF_PATH}` });
        }
    });

    router.get('/verify', (req, res) => {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) return res.status(401).json({ valid: false });
        try {
            const decoded = jwt.verify(token, JWT_SECRET);
            res.json({ valid: true, role: decoded.role, exp: decoded.exp });
        } catch {
            res.status(401).json({ valid: false });
        }
    });

    return router;
};
