const express = require('express');
const { v } = require('../utils/validate');
const { h, cmd, cmdOk } = require('../utils/helpers');
const { platform } = require('../utils/platform');
const { loadConfig } = require('../utils/config');

const router = express.Router();
const PROTECTED = () => [Number(loadConfig().port_ssh || 22), Number(process.env.AGENT_PORT || loadConfig().port_agent || 9090)];

router.get('/status', h(async (req, res) => {
    if (platform().firewall === 'ufw') {
        const r = await cmd('ufw', ['status']);
        const state = (r.stdout.match(/Status:\s*(\w+)/) || [])[1] || 'N/A';
        const ports = [...new Set(r.stdout.split('\n').filter(l => /ALLOW/.test(l) && !/\(v6\)/.test(l)).map(l => l.trim().split(/\s+/)[0]))];
        return res.json({ tool: 'ufw', state, ports });
    }
    const [state, ports] = await Promise.all([cmd('firewall-cmd', ['--state']), cmd('firewall-cmd', ['--list-ports'])]);
    res.json({ tool: 'firewalld', state: state.stdout || 'N/A', ports: ports.stdout.split(/\s+/).filter(Boolean) });
}));

router.post('/open', h(async (req, res) => {
    const port = v.port(req.body.port), protocol = v.protocol(req.body.protocol);
    if (platform().firewall === 'ufw') await cmdOk('ufw', ['allow', `${port}/${protocol}`]);
    else { await cmdOk('firewall-cmd', ['--permanent', '--zone=public', `--add-port=${port}/${protocol}`]); await cmdOk('firewall-cmd', ['--reload']); }
    res.json({ message: `Port ${port}/${protocol} opened` });
}));

router.post('/close', h(async (req, res) => {
    const port = v.port(req.body.port), protocol = v.protocol(req.body.protocol);
    if (PROTECTED().includes(port)) return res.status(400).json({ error: `Refusing to close port ${port} (SSH/Agent) - you would lock yourself out` });
    if (platform().firewall === 'ufw') await cmdOk('ufw', ['delete', 'allow', `${port}/${protocol}`]);
    else { await cmdOk('firewall-cmd', ['--permanent', '--zone=public', `--remove-port=${port}/${protocol}`]); await cmdOk('firewall-cmd', ['--reload']); }
    res.json({ message: `Port ${port}/${protocol} closed` });
}));

module.exports = router;
