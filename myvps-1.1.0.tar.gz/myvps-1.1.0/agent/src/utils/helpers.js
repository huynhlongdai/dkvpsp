const { cmd, cmdOk } = require('./exec');
const { loadConfig } = require('./config');

const MYVPS_BIN = process.env.MYVPS_BIN || '/usr/bin/myvps';

/** Wrap an async route so thrown errors become proper JSON responses */
const h = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(e => {
    res.status(e.status || 500).json({ error: e.message || 'Internal error' });
});

/** Run the myvps CLI non-interactively */
function myvps(args, timeout = 60000) {
    return cmdOk(MYVPS_BIN, ['--yes', ...args], { timeout, env: { MYVPS_ASSUME_YES: '1', TERM: 'dumb' } });
}

/** Run SQL as the MyVPS DB admin; password passed via env, never on the command line */
function mysql(sql, { raw = false } = {}) {
    const c = loadConfig();
    const args = ['-u', c.db_admin_user || 'admin', '-N', '-B', '-e', sql];
    return cmdOk('mysql', args, { env: { MYSQL_PWD: c.db_admin_password || '' } }).then(r => raw ? r : r.stdout);
}

module.exports = { h, myvps, mysql, MYVPS_BIN, cmd, cmdOk };
