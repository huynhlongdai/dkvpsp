/**
 * OS differences (RHEL family vs Debian/Ubuntu) - mirrors cli/core/platform.sh
 */
const fs = require('fs');

function osFamily() {
    try {
        const t = fs.readFileSync('/etc/os-release', 'utf8');
        if (/^(ID|ID_LIKE)=.*(debian|ubuntu)/m.test(t)) return 'debian';
    } catch { /* ignore */ }
    return 'rhel';
}

const FAMILY = osFamily();

function platform(config = {}) {
    const php = config.php_default_version || '8.1';
    const deb = FAMILY === 'debian';
    return {
        family: FAMILY,
        services: {
            nginx: 'nginx',
            'php-fpm': deb ? `php${php}-fpm` : 'php-fpm',
            mariadb: 'mariadb',
            redis: deb ? 'redis-server' : 'redis',
            memcached: 'memcached',
            fail2ban: 'fail2ban',
            sshd: deb ? 'ssh' : 'sshd'
        },
        phpPoolDir: deb ? `/etc/php/${php}/fpm/pool.d` : '/etc/php-fpm.d',
        firewall: deb ? 'ufw' : 'firewalld'
    };
}

module.exports = { platform, FAMILY };
