/**
 * WebSocket handler - real-time system monitoring
 * Sends CPU/RAM/Disk/Services every 5 seconds to authenticated clients
 */
const jwt = require('jsonwebtoken');
const os = require('os');
const { runSafe, cmd } = require('./exec');
const { platform } = require('./platform');
const { loadConfig } = require('./config');

function setupWS(wss, secret) {
    const clients = new Set();

    wss.on('connection', (ws, req) => {
        // Auth: token in query string ?token=xxx
        const url = new URL(req.url, 'http://localhost');
        const token = url.searchParams.get('token');
        if (!token) { ws.close(4001, 'Token required'); return; }
        try {
            jwt.verify(token, secret);
        } catch {
            ws.close(4001, 'Invalid token');
            return;
        }

        clients.add(ws);
        ws.on('close', () => clients.delete(ws));
        ws.on('error', () => clients.delete(ws));

        // Send initial data
        gatherAndSend(ws);
    });

    // Broadcast every 5s
    setInterval(() => {
        if (clients.size === 0) return;
        gatherStats().then(data => {
            const msg = JSON.stringify({ type: 'stats', data, ts: Date.now() });
            clients.forEach(c => { if (c.readyState === 1) c.send(msg); });
        }).catch(() => {});
    }, 5000);
}

async function gatherAndSend(ws) {
    const data = await gatherStats();
    if (ws.readyState === 1) {
        ws.send(JSON.stringify({ type: 'stats', data, ts: Date.now() }));
    }
}

async function gatherStats() {
    const [cpuResult, memResult, diskResult, uptimeResult, servicesResult] = await Promise.all([
        cpuUsage(),
        runSafe("free -b | awk '/Mem:/{printf \"%d|%d|%d\",$2,$3,$7}'"),
        runSafe("df -B1 / | tail -1 | awk '{printf \"%d|%d|%d|%s\",$2,$3,$4,$5}'"),
        runSafe("uptime -p 2>/dev/null || uptime"),
        getServiceStatuses()
    ]);

    const mem = memResult.stdout.split('|').map(Number);
    const disk = diskResult.stdout.split('|');

    return {
        cpu: { usage: cpuResult, cores: os.cpus().length },
        memory: { total: mem[0] || 0, used: mem[1] || 0, available: mem[2] || 0 },
        disk: { total: parseInt(disk[0]) || 0, used: parseInt(disk[1]) || 0, available: parseInt(disk[2]) || 0, usage: disk[3] || '0%' },
        uptime: uptimeResult.stdout,
        hostname: os.hostname(),
        services: servicesResult
    };
}

// Real current CPU usage: delta of /proc/stat between two calls (first call: 300ms sample)
let lastCpu = null;
function readCpu() {
    const p = require('fs').readFileSync('/proc/stat', 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
    const idle = p[3] + (p[4] || 0);
    return { idle, total: p.reduce((a, b) => a + b, 0) };
}
async function cpuUsage() {
    try {
        if (!lastCpu) { lastCpu = readCpu(); await new Promise(r => setTimeout(r, 300)); }
        const now = readCpu();
        const dt = now.total - lastCpu.total, di = now.idle - lastCpu.idle;
        lastCpu = now;
        return dt > 0 ? Math.round((1 - di / dt) * 1000) / 10 : 0;
    } catch { return 0; }
}

async function getServiceStatuses() {
    const units = platform(loadConfig()).services;
    const results = {};
    await Promise.all(Object.keys(units).map(async s => {
        const r = await cmd('systemctl', ['is-active', units[s]]);
        results[s] = r.stdout || 'inactive';
    }));
    return results;
}

module.exports = { setupWS, cpuUsage };
