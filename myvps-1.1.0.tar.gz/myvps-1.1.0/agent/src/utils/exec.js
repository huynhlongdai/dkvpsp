/**
 * Command execution utility
 *
 * SECURITY: never interpolate user input into a shell string.
 *  - cmd(file, args)  -> execFile, no shell, args passed verbatim (use for anything with user input)
 *  - run(shellString) -> only for constant, developer-written pipelines
 */
const { exec, execFile } = require('child_process');

const ANSI = /\x1b\[[0-9;]*[A-Za-z]/g;
const clean = x => String(x).replace(ANSI, '').trim();

function done(resolve, reject) {
    return (error, stdout, stderr) => {
        if (error && error.killed) return reject(new Error('Command timed out'));
        resolve({ stdout: clean(stdout), stderr: clean(stderr), code: error ? (typeof error.code === 'number' ? error.code : 1) : 0 });
    };
}

function run(command, timeout = 30000) {
    return new Promise((resolve, reject) => {
        exec(command, { timeout, maxBuffer: 4 * 1024 * 1024, shell: '/bin/bash' }, done(resolve, reject));
    });
}

function cmd(file, args = [], { timeout = 30000, input, env } = {}) {
    return new Promise((resolve, reject) => {
        const child = execFile(file, args, { timeout, maxBuffer: 4 * 1024 * 1024, env: { ...process.env, ...(env || {}) } }, done(resolve, reject));
        if (input !== undefined) { child.stdin.write(input); }
        child.stdin.end();
    });
}

/** Like cmd() but throws when the exit code is non-zero, with the command's own error text. */
async function cmdOk(file, args = [], opts = {}) {
    const r = await cmd(file, args, opts);
    if (r.code !== 0) {
        const err = new Error((r.stderr || r.stdout || `exit code ${r.code}`).split('\n').slice(-5).join('\n'));
        err.result = r;
        throw err;
    }
    return r;
}

function runSafe(command, timeout = 30000) {
    return run(command, timeout).catch(e => ({ stdout: '', stderr: e.message, code: 1 }));
}

module.exports = { run, runSafe, cmd, cmdOk };
