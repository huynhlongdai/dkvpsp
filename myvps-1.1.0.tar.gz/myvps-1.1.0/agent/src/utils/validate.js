/**
 * Input validators - every value from req.params / req.body that reaches
 * a command, a path or SQL must pass one of these first.
 */
const DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;
const DB_IDENT_RE = /^[A-Za-z0-9_]{1,64}$/;
const DB_USER_RE = /^[A-Za-z0-9_]{1,32}$/;
const PHP_VER_RE = /^[5-8]\.[0-9]$/;
const FILE_RE = /^[A-Za-z0-9._-]{1,200}$/;

class ValidationError extends Error { constructor(m) { super(m); this.status = 400; } }

const v = {
    domain(x) { if (typeof x !== 'string' || !DOMAIN_RE.test(x)) throw new ValidationError('Invalid domain'); return x.toLowerCase(); },
    dbName(x) { if (typeof x !== 'string' || !DB_IDENT_RE.test(x)) throw new ValidationError('Invalid database name (A-Z, 0-9, _ only)'); return x; },
    dbUser(x) { if (typeof x !== 'string' || !DB_USER_RE.test(x)) throw new ValidationError('Invalid database user (A-Z, 0-9, _ only, max 32)'); return x; },
    port(x) { const n = Number(x); if (!Number.isInteger(n) || n < 1 || n > 65535) throw new ValidationError('Invalid port'); return n; },
    protocol(x) { x = x || 'tcp'; if (!['tcp', 'udp'].includes(x)) throw new ValidationError('Invalid protocol'); return x; },
    phpVersion(x) { if (typeof x !== 'string' || !PHP_VER_RE.test(x)) throw new ValidationError('Invalid PHP version'); return x; },
    filename(x) { if (typeof x !== 'string' || !FILE_RE.test(x) || x.startsWith('.')) throw new ValidationError('Invalid filename'); return x; },
    oneOf(x, list, name = 'value') { if (!list.includes(x)) throw new ValidationError(`Invalid ${name}`); return x; }
};

module.exports = { v, ValidationError };
