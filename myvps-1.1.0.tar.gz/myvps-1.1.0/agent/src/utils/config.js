/**
 * Config reader - reads /etc/myvps/.myvps.conf
 */
const fs = require('fs');
const path = require('path');

const CONF_PATH = process.env.MYVPS_CONF || '/etc/myvps/.myvps.conf';
const USER_DIR = '/etc/myvps/user';

function loadConfig() {
    const config = {};
    try {
        fs.readFileSync(CONF_PATH, 'utf8').split('\n').forEach(line => {
            line = line.trim();
            if (line && !line.startsWith('#')) {
                const idx = line.indexOf('=');
                if (idx > 0) config[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
            }
        });
    } catch (e) { /* config may not exist */ }
    return config;
}

function loadDomainConfig(domain) {
    const config = {};
    if (typeof domain !== 'string' || domain.includes('/') || domain.startsWith('.')) return null;
    try {
        fs.readFileSync(path.join(USER_DIR, `.${domain}.conf`), 'utf8').split('\n').forEach(line => {
            line = line.trim();
            if (line && !line.startsWith('#') && !line.startsWith('[')) {
                const idx = line.indexOf('=');
                if (idx > 0) config[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
            }
        });
    } catch (e) { return null; }
    return config;
}

function listDomainConfigs() {
    const domains = [];
    try {
        fs.readdirSync(USER_DIR).forEach(file => {
            if (file.startsWith('.') && file.endsWith('.conf') && !file.endsWith('.suspended')) {
                const domain = file.slice(1, -5);
                if (domain.includes('.')) {
                    const cfg = loadDomainConfig(domain);
                    if (cfg) domains.push({ domain, ...cfg });
                }
            }
        });
    } catch (e) { /* dir may not exist */ }
    return domains;
}

// Set (or add) key=value in the global config, keeping file mode 600
function setConfigValue(key, value) {
    let content = '';
    try { content = fs.readFileSync(CONF_PATH, 'utf8'); } catch { fs.mkdirSync(path.dirname(CONF_PATH), { recursive: true }); }
    const re = new RegExp(`^${key}=.*$`, 'm');
    content = re.test(content) ? content.replace(re, `${key}=${value}`) : content.replace(/\n?$/, '\n') + `${key}=${value}\n`;
    fs.writeFileSync(CONF_PATH, content, { mode: 0o600 });
    fs.chmodSync(CONF_PATH, 0o600);
}

module.exports = { loadConfig, loadDomainConfig, listDomainConfigs, setConfigValue, CONF_PATH };
