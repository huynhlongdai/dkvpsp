#!/bin/bash
# 1.1.0: self-update support. Older installs get the daily login check and a release file.
set -e
[[ -f /etc/profile.d/myvps-update.sh ]] || /usr/bin/myvps update notify on >/dev/null
mkdir -p /var/lib/myvps/update
exit 0
