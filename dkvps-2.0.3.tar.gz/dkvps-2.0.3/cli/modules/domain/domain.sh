#!/bin/bash
#
# DKVPS - Domain Management Module
#

domain_handler() {
    local action="$1"
    shift
    case "$action" in
        add|create) domain_add "$@" ;;
        list|ls)    domain_list ;;
        delete|rm)  domain_delete "$@" ;;
        suspend)    domain_suspend "$@" ;;
        unsuspend)  domain_unsuspend "$@" ;;
        info)       domain_info "$@" ;;
        change)     domain_change "$@" ;;
        subfolder)  domain_subfolder "$@" ;;
        permission) domain_permission "$@" ;;
        harden)     domain_harden "$@" ;;
        cache)      domain_cache "$@" ;;
        purge-pending) site_cache_purge_pending ;;
        limit)      domain_limit "$@" ;;
        redis)      domain_redis "$@" ;;
        staging)    source "${CLI_DIR}/modules/migrate/migrate.sh"; staging_handler "$@" ;;
        *)
            if [[ -n "$action" ]]; then
                print_error "Unknown domain action: $action"
            fi
            domain_menu
            ;;
    esac
}

domain_menu() {
    echo ""
    print_subheader "Domain Management"
    echo ""

    local options=(
        "List Domains"
        "Add Domain/SubDomain"
        "Delete Domain/SubDomain"
        "Domain Info"
        "Suspend/Unsuspend Domain"
        "Change Domain (A -> B)"
        "Restore Nginx Config"
        "Fix Permissions (Chown/Chmod)"
        "Setup SubFolder"
        "Setup IP-based Domain"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") domain_list ;;
            "${options[1]}") domain_add ;;
            "${options[2]}") domain_delete ;;
            "${options[3]}") domain_info ;;
            "${options[4]}") domain_suspend_menu ;;
            "${options[5]}") domain_change ;;
            "${options[6]}") domain_restore_nginx ;;
            "${options[7]}") domain_permission ;;
            "${options[8]}") domain_subfolder ;;
            "${options[9]}") domain_ip_setup ;;
            *) return ;;
        esac
    done
}

domain_list() {
    echo ""
    print_subheader "Domain List"
    echo ""
    list_domains
}

domain_add() {
    # Usage: domain_add [domain] [--wp] [--wp-prefix] [--laravel] [--db] [--no-app]
    # Any flag (or DKVPS_ASSUME_YES=1) makes it fully non-interactive (used by the Agent API).
    local domain="" noninteractive=0
    local install_wp="n" install_laravel="n" create_db="n" custom_prefix="n"
    for arg in "$@"; do
        case "$arg" in
            --wp)        install_wp="y"; noninteractive=1 ;;
            --wp-prefix) custom_prefix="y" ;;
            --laravel)   install_laravel="y"; noninteractive=1 ;;
            --db)        create_db="y"; noninteractive=1 ;;
            --no-app)    noninteractive=1 ;;
            -*)          ;;
            *)           domain="$arg" ;;
        esac
    done
    [[ "${DKVPS_ASSUME_YES:-0}" == "1" ]] && noninteractive=1

    echo ""
    print_subheader "Add Domain"
    echo ""

    check_services || return 1

    if [[ -z "$domain" ]]; then
        read -p "Enter Domain/SubDomain [0=Cancel]: " domain
    fi

    [[ "$domain" == "0" ]] && return
    validate_domain "$domain" || return 1

    if domain_exists "$domain"; then
        print_error "Domain $domain already exists."
        return 1
    fi

    # Ask about applications (interactive mode only)
    if [[ "$noninteractive" != "1" ]]; then
        read -p "Install WordPress for $domain? (y/n): " install_wp
        if [[ "$install_wp" == "y" ]]; then
            read -p "Use custom table prefix for security? (y/n): " custom_prefix
        else
            read -p "Install Laravel (latest) for $domain? (y/n): " install_laravel
        fi

        if [[ "$install_wp" != "y" ]] && [[ "$install_laravel" != "y" ]]; then
            read -p "Create database for $domain? (y/n): " create_db
        fi
    fi

    # Generate credentials
    local username=$(get_username "$domain")
    local password_sftp=$(generate_password 32)
    local password_auth=$(generate_password 24)
    local db_name="" db_user="" db_password=""

    if [[ "$install_wp" == "y" ]] || [[ "$install_laravel" == "y" ]] || [[ "$create_db" == "y" ]]; then
        db_name="${username}_db"
        db_user="${username}_user"
        db_password=$(generate_password 32)
    fi

    print_info "Creating domain $domain..."

    # 1. Create Linux user (no interactive shell: SFTP only, chrooted)
    useradd -M -d "/home/$username" -s /usr/sbin/nologin "$username" 2>/dev/null
    echo "$username:$password_sftp" | chpasswd

    # 2. Create HTTP auth user
    if command -v htpasswd &>/dev/null; then
        htpasswd -b "$DKVPS_WEB_DIR/passwd/.htpasswd" "$username" "$password_auth" 2>/dev/null
    fi

    # 3. Directory layout + isolation (see core/sitekit.sh)
    mkdir -p "/home/$username/$domain/public_html"
    usermod -aG sftp_users "$username" 2>/dev/null

    # 4. Default index
    if [[ "$install_wp" != "y" && "$install_laravel" != "y" ]]; then
        cat > "/home/$username/$domain/public_html/index.html" <<EOF
<!DOCTYPE html>
<html>
<head><title>$domain</title></head>
<body>
<h1>Welcome to $domain</h1>
<p>DKVPS has been configured successfully.</p>
</body>
</html>
EOF
    fi

    # 5. SELinux context (if available)
    if command -v chcon &>/dev/null; then
        chcon -R -t httpd_sys_rw_content_t "/home/$username/$domain/public_html" 2>/dev/null
    fi

    # 6. Save domain config early so the cache flag is known to the vhost writer
    save_domain_config "$domain" "$username" "$password_auth" "$password_sftp" "$db_name" "$db_user" "$db_password"
    local app=""
    [[ "$install_wp" == "y" ]] && app="wp"
    [[ "$install_laravel" == "y" ]] && app="laravel"
    set_config "app" "${app:-php}" "$DKVPS_USER_DIR/.$domain.conf"
    [[ "$app" == "wp" ]] && set_config "fcgi_cache" "1" "$DKVPS_USER_DIR/.$domain.conf"

    # 7-10. Permissions, PHP-FPM pool (unix socket, ondemand), Nginx vhost
    site_apply "$domain" "$username" "$app"

    # 11. Create database if needed
    if [[ -n "$db_name" ]]; then
        load_config
        if ! MYSQL_PWD="$db_admin_password" mysql -u "$db_admin_user" -e "CREATE DATABASE IF NOT EXISTS \`$db_name\`; CREATE USER IF NOT EXISTS '$db_user'@'localhost' IDENTIFIED BY '$db_password'; GRANT ALL PRIVILEGES ON \`$db_name\`.* TO '$db_user'@'localhost'; FLUSH PRIVILEGES;"; then
            print_error "Database $db_name could not be created"; return 1
        fi
        print_success "Database $db_name created"
    fi

    # 12. Install WordPress if requested
    if [[ "$install_wp" == "y" ]]; then
        local prefix="wp"
        if [[ "$custom_prefix" == "y" ]]; then
            prefix=$(openssl rand -hex 3)
        fi
        _install_wordpress "$domain" "$username" "$db_name" "$db_user" "$db_password" "$prefix"
    fi

    # 13. Install Laravel if requested
    if [[ "$install_laravel" == "y" ]]; then
        _install_laravel "$domain" "$username" "$db_name" "$db_user" "$db_password"
    fi

    if [[ -n "${WP_ADMIN_USER:-}" ]]; then
        set_config "wp_admin_user" "$WP_ADMIN_USER" "$DKVPS_USER_DIR/.$domain.conf"
        set_config "wp_admin_password" "$WP_ADMIN_PASS" "$DKVPS_USER_DIR/.$domain.conf"
    fi

    # 14. Re-apply permissions/vhost now that the app files exist
    site_apply "$domain" "$username" "$app"

    # 15. Restart services
    restart_nginx
    restart_php

    # Show results
    echo ""
    print_success "Domain $domain created successfully!"
    print_line
    echo ""
    echo "  Domain:        $domain"
    echo ""
    echo "  SFTP Access:"
    echo "    Host:        ${ip:-$(get_public_ip)}"
    echo "    Port:        ${port_ssh:-22}"
    echo "    Username:    $username"
    echo "    Password:    $password_sftp"
    echo "    Path:        /$domain/public_html"
    echo ""
    echo "  HTTP Auth:"
    echo "    URL:         http://${ip:-$(get_public_ip)}:${port_admin:-$DKVPS_PORT_ADMIN}"
    echo "    Username:    $username"
    echo "    Password:    $password_auth"
    echo ""
    if [[ -n "$db_name" ]]; then
        echo "  Database:"
        echo "    DB Name:     $db_name"
        echo "    DB User:     $db_user"
        echo "    DB Password: $db_password"
        echo ""
    fi
    print_line
}

domain_delete() {
    local domain="${1:-}"

    echo ""
    print_subheader "Delete Domain"
    echo ""

    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    if ! domain_exists "$domain"; then
        print_error "Domain $domain not found."
        return 1
    fi

    local username=$(get_username "$domain")

    if ! confirm "Delete domain $domain and ALL its data?"; then
        return
    fi

    print_info "Deleting domain $domain..."

    # Remove Nginx config, site include and page cache
    rm -f "/etc/nginx/conf.d/$domain.conf" "/etc/nginx/conf.d/$domain.conf.suspended"
    rm -f "$DKVPS_SITE_INC_DIR/$domain.inc" "$DKVPS_SITE_INC_DIR/$domain.custom"
    [[ -n "$domain" ]] && rm -rf "${DKVPS_FCGI_CACHE_DIR:?}/$domain"

    # Remove PHP-FPM pool, dedicated FPM master and private Redis
    rm -f "$PHP_POOL_DIR/$domain.conf"
    systemctl disable --now "dkvps-fpm@$domain" >/dev/null 2>&1
    systemctl disable --now "dkvps-app-$domain" >/dev/null 2>&1; rm -f "/etc/systemd/system/dkvps-app-$domain.service"
    rm -rf "/etc/systemd/system/dkvps-fpm@$domain.service.d" /etc/dkvps/fpm/"$domain".conf /etc/dkvps/fpm/"$domain".pool.conf
    systemctl disable --now "dkvps-redis@$username" >/dev/null 2>&1
    rm -f "/etc/dkvps/redis/$username.conf"

    # Remove home directory
    rm -rf "/home/$username"

    # Remove database
    load_config
    if load_domain_config "$domain"; then
        if [[ -n "$db_name" ]]; then
            mysql -u "$db_admin_user" -p"$db_admin_password" -e "DROP DATABASE IF EXISTS \`$db_name\`" 2>/dev/null
            mysql -u "$db_admin_user" -p"$db_admin_password" -e "DROP USER IF EXISTS '$db_user'@'localhost'" 2>/dev/null
        fi
    fi

    # Remove Linux user: stop its PHP-FPM pool workers first, otherwise
    # userdel fails with "user is currently used by process"
    restart_php >/dev/null
    pkill -u "$username" 2>/dev/null; sleep 1
    gpasswd -d "${NGINX_USER:-www-data}" "$username" >/dev/null 2>&1
    userdel "$username" 2>/dev/null || userdel -f "$username" 2>/dev/null || print_warning "Could not delete Linux user $username"
    getent group "$username" >/dev/null && groupdel "$username" 2>/dev/null

    # Remove htpasswd entry
    if command -v htpasswd &>/dev/null; then
        htpasswd -D "$DKVPS_WEB_DIR/passwd/.htpasswd" "$username" 2>/dev/null
    fi

    # Remove domain config
    delete_domain_config "$domain"

    restart_nginx
    restart_php

    print_success "Domain $domain deleted."
}

domain_info() {
    local domain="${1:-}"

    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    if ! domain_exists "$domain"; then
        print_error "Domain $domain not found."
        return 1
    fi

    load_domain_config "$domain"

    echo ""
    print_subheader "Domain Info: $domain"
    echo ""
    print_status_line "Domain" "$domain"
    print_status_line "Username" "$username"
    print_status_line "Public HTML" "/home/$username/$domain/public_html"
    print_status_line "PHP Version" "${php_version:-8.1}"
    print_status_line "Status" "${status:-active}"
    print_status_line "Created" "${created_at:-N/A}"
    if [[ -n "$db_name" ]]; then
        print_status_line "DB Name" "$db_name"
        print_status_line "DB User" "$db_user"
    fi
    echo ""
}

domain_suspend_menu() {
    echo ""
    local options=("Suspend Domain" "Unsuspend Domain")
    local PS3=$'\n'"Select [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}") domain_suspend ;;
            "${options[1]}") domain_unsuspend ;;
            *) return ;;
        esac
    done
}

domain_suspend() {
    local domain="${1:-}"
    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    if ! domain_exists "$domain"; then
        print_error "Domain $domain not found."
        return 1
    fi

    # Rename nginx config to disable
    if [[ -f "/etc/nginx/conf.d/$domain.conf" ]]; then
        mv "/etc/nginx/conf.d/$domain.conf" "/etc/nginx/conf.d/$domain.conf.suspended"
        set_config "status" "suspended" "$DKVPS_USER_DIR/.$domain.conf"
        reload_nginx
        print_success "Domain $domain suspended."
    fi
}

domain_unsuspend() {
    local domain="${1:-}"
    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    if [[ -f "/etc/nginx/conf.d/$domain.conf.suspended" ]]; then
        mv "/etc/nginx/conf.d/$domain.conf.suspended" "/etc/nginx/conf.d/$domain.conf"
        set_config "status" "active" "$DKVPS_USER_DIR/.$domain.conf"
        reload_nginx
        print_success "Domain $domain unsuspended."
    fi
}

domain_restore_nginx() {
    local domain="${1:-}"
    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    local username=$(get_username "$domain")
    load_domain_config "$domain"
    site_ensure_globals
    site_write_vhost "$domain" "$username" "${app:-}"
    reload_nginx
    print_success "Nginx config restored for $domain"
}

domain_permission() {
    local domain="${1:-}"
    if [[ -z "$domain" ]]; then
        choose_domain || return
        domain="$SELECTED_DOMAIN"
    fi

    local username=$(get_username "$domain")
    site_secure_layout "$domain" "$username"
    print_success "Permissions fixed for $domain"
}

domain_change() {
    echo ""
    print_subheader "Change Domain"
    echo ""
    choose_domain || return
    local old_domain="$SELECTED_DOMAIN"
    read -p "Enter new domain: " new_domain
    validate_domain "$new_domain" || return 1

    print_info "Changing $old_domain -> $new_domain"
    # This is complex - would need to rename configs, directories, DB entries etc.
    print_warning "This feature requires manual verification. Please backup first."
}

domain_subfolder() {
    print_info "SubFolder management - use Nginx config to set up subfolder routing."
}

domain_ip_setup() {
    print_info "IP-based domain setup - configure Nginx default server to serve a domain."
}

# Re-apply the isolation + lite model to one domain or --all (migrates old
# TCP-port pools, 755 homes and users that were members of www-data)
domain_harden() {
    local target="${1:-}"
    local domains=()
    if [[ "$target" == "--all" ]]; then
        for conf in "$DKVPS_USER_DIR"/.*.conf; do
            [[ -f "$conf" ]] || continue
            local d=$(basename "$conf" .conf); d="${d#.}"
            [[ "$d" == *"."* ]] && domains+=("$d")
        done
    else
        if [[ -z "$target" ]]; then choose_domain || return; target="$SELECTED_DOMAIN"; fi
        domain_exists "$target" || { print_error "Domain $target not found."; return 1; }
        domains=("$target")
    fi
    local d
    for d in "${domains[@]}"; do
        local username=$(get_username "$d")
        app=""; load_domain_config "$d"
        if [[ -z "$app" ]]; then
            [[ -f "/home/$username/$d/public_html/wp-settings.php" ]] && app="wp"
            [[ -f "/home/$username/$d/public_html/artisan" ]] && app="laravel"
            set_config "app" "${app:-php}" "$DKVPS_USER_DIR/.$d.conf"
        fi
        if [[ "$app" == "wp" ]] && ! grep -q '^fcgi_cache=' "$DKVPS_USER_DIR/.$d.conf"; then
            set_config "fcgi_cache" "1" "$DKVPS_USER_DIR/.$d.conf"
        fi
        usermod -s /usr/sbin/nologin "$username" 2>/dev/null
        site_apply "$d" "$username" "$app"
        print_success "Hardened $d (profile: $(dkvps_profile), max PHP workers: $(site_fpm_max_children))"
    done
    restart_php >/dev/null && reload_nginx >/dev/null
}

# dkvps domain limit <domain> [--cpu 50] [--ram 256M] [--tasks 64] | --unlimit | --show
# Moves the site to its own PHP-FPM master inside its own cgroup, so a flooded
# or hacked site is throttled/OOM-killed alone instead of starving the server.
domain_limit() {
    local domain="" cpu="" ram="" tasks="" unlimit=0 show=0
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --cpu) cpu="${2%%%}"; shift ;;
            --ram) ram="$2"; shift ;;
            --tasks) tasks="$2"; shift ;;
            --unlimit|--off) unlimit=1 ;;
            --show) show=1 ;;
            -*) ;;
            *) domain="$1" ;;
        esac
        shift
    done
    if [[ -z "$domain" ]]; then choose_domain || return; domain="$SELECTED_DOMAIN"; fi
    domain_exists "$domain" || { print_error "Domain $domain not found."; return 1; }
    local username=$(get_username "$domain") conf="$DKVPS_USER_DIR/.$domain.conf"
    if [[ "$show" == "1" ]]; then
        if site_flag "$domain" limit; then
            systemctl show "dkvps-fpm@$domain" -p CPUQuotaPerSecUSec -p MemoryMax -p MemoryCurrent -p TasksMax -p TasksCurrent -p ActiveState
        else
            echo "No limit (shared PHP-FPM)"
        fi
        return 0
    fi
    [[ -z "$cpu" || "$cpu" =~ ^[0-9]+$ ]] || { print_error "--cpu must be a percent, e.g. 50"; return 1; }
    [[ -z "$ram" || "$ram" =~ ^[0-9]+[MG]$ ]] || { print_error "--ram must look like 256M or 1G"; return 1; }
    [[ -z "$tasks" || "$tasks" =~ ^[0-9]+$ ]] || { print_error "--tasks must be a number"; return 1; }
    if [[ "$unlimit" == "1" ]]; then
        set_config "limit" "0" "$conf"
        site_write_pool "$domain" "$username"
        systemctl disable --now "dkvps-fpm@$domain" >/dev/null 2>&1
        rm -rf "/etc/systemd/system/dkvps-fpm@$domain.service.d" "/etc/dkvps/fpm/$domain.conf"
        systemctl daemon-reload; systemctl restart "$PHP_FPM_SERVICE"
        print_success "Limits removed for $domain (back on shared PHP-FPM)"
        return 0
    fi
    if [[ -z "$cpu$ram$tasks" ]]; then
        # sensible default: 1/N of the box, never more than 60% CPU
        local mb; mb=$(dkvps_effective_ram_mb)
        cpu=60; ram="$(( mb / 3 ))M"; tasks=64
    fi
    set_config "limit" "1" "$conf"
    [[ -n "$cpu" ]] && set_config "limit_cpu" "$cpu" "$conf"
    [[ -n "$ram" ]] && set_config "limit_ram" "$ram" "$conf"
    [[ -n "$tasks" ]] && set_config "limit_tasks" "$tasks" "$conf"
    site_write_pool "$domain" "$username"
    site_php_restart "$domain" || { print_error "Dedicated PHP-FPM failed to start: journalctl -u dkvps-fpm@$domain"; return 1; }
    print_success "Limited $domain: CPU ${cpu:-$(site_get "$domain" limit_cpu)}%, RAM ${ram:-$(site_get "$domain" limit_ram)}, tasks ${tasks:-$(site_get "$domain" limit_tasks)}"
}

# dkvps domain redis <domain> on [MB] | off | status
domain_redis() {
    local domain="${1:-}" op="${2:-status}" mem="${3:-}"
    if [[ -z "$domain" ]]; then choose_domain || return; domain="$SELECTED_DOMAIN"; fi
    domain_exists "$domain" || { print_error "Domain $domain not found."; return 1; }
    local username=$(get_username "$domain")
    case "$op" in
        on|enable)
            [[ -z "$mem" || "$mem" =~ ^[0-9]+$ ]] || { print_error "Memory in MB, e.g. 32"; return 1; }
            site_redis_enable "$domain" "$username" "$mem"
            site_write_pool "$domain" "$username"; site_php_restart "$domain"
            print_success "Private Redis for $domain: $(site_redis_socket "$username") (${mem:-$(site_get "$domain" redis_mem)} MB, LRU, no disk)" ;;
        off|disable)
            site_redis_disable "$domain" "$username"
            site_write_pool "$domain" "$username"; site_php_restart "$domain"
            print_success "Private Redis removed for $domain" ;;
        status)
            if site_flag "$domain" redis; then
                systemctl is-active "dkvps-redis@$username"
                sudo -u "$username" redis-cli -s "$(site_redis_socket "$username")" info memory 2>/dev/null | grep -E "used_memory_human|maxmemory_human"
                sudo -u "$username" redis-cli -s "$(site_redis_socket "$username")" info stats 2>/dev/null | grep -E "keyspace_hits|keyspace_misses"
            else
                echo "Private Redis: off"
            fi ;;
        *) print_error "Usage: dkvps domain redis <domain> on [MB]|off|status"; return 1 ;;
    esac
}

# dkvps domain cache <domain> on|off|purge
domain_cache() {
    local domain="${1:-}" op="${2:-purge}"
    if [[ -z "$domain" ]]; then choose_domain || return; domain="$SELECTED_DOMAIN"; fi
    domain_exists "$domain" || { print_error "Domain $domain not found."; return 1; }
    local username=$(get_username "$domain")
    app=""; load_domain_config "$domain"
    case "$op" in
        on|enable)
            set_config "fcgi_cache" "1" "$DKVPS_USER_DIR/.$domain.conf"
            site_write_vhost "$domain" "$username" "$app"
            [[ "$app" == "wp" ]] && site_install_wp_purge_plugin "$domain" "$username"
            reload_nginx >/dev/null; print_success "Page cache enabled for $domain" ;;
        off|disable)
            set_config "fcgi_cache" "0" "$DKVPS_USER_DIR/.$domain.conf"
            site_write_vhost "$domain" "$username" "$app"
            site_cache_purge "$domain"
            reload_nginx >/dev/null; print_success "Page cache disabled for $domain" ;;
        purge)
            site_cache_purge "$domain"; print_success "Page cache purged for $domain" ;;
        *) print_error "Usage: dkvps domain cache <domain> on|off|purge"; return 1 ;;
    esac
}

# ============================================================
# Internal helpers
# ============================================================

_install_wordpress() {
    local domain="$1"
    local username="$2"
    local db_name="$3"
    local db_user="$4"
    local db_password="$5"
    local prefix="${6:-wp}"

    print_info "Installing WordPress for $domain..."

    local work; work=$(mktemp -d)
    curl -fsSL https://wordpress.org/latest.tar.gz -o "$work/wp.tar.gz" || { print_error "WordPress download failed"; rm -rf "$work"; return 1; }
    tar -zxf "$work/wp.tar.gz" -C "$work"
    cp -rf "$work"/wordpress/* "/home/$username/$domain/public_html/"
    rm -rf "$work"
    rm -f "/home/$username/$domain/public_html/index.html"

    # Generate salts
    local SALT=$(curl -sL https://api.wordpress.org/secret-key/1.1/salt/)

    cat > "/home/$username/$domain/public_html/wp-config.php" <<EOF
<?php
define('DISALLOW_FILE_EDIT', true);
define('WP_MEMORY_LIMIT', '256M');
define('WP_CACHE', true);
define('FS_METHOD', 'direct');
define('WP_TEMP_DIR', '/home/$username/$domain/tmp/');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASSWORD', '$db_password');
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');
define('DISABLE_WP_CRON', false);

$SALT

\$table_prefix = '${prefix}_';

define('WP_DEBUG', false);

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
EOF

    # Create robots.txt
    cat > "/home/$username/$domain/public_html/robots.txt" <<EOF
User-agent: *
Disallow: /wp-admin/
Allow: /wp-admin/admin-ajax.php

Sitemap: https://$domain/sitemap.xml
EOF

    # Set permissions
    chown -R "$username:$username" "/home/$username/$domain/public_html"
    chmod 0400 "/home/$username/$domain/public_html/wp-config.php"
    rm -f "/home/$username/$domain/public_html/readme.html"
    rm -f "/home/$username/$domain/public_html/license.txt"

    # Finish the install with WP-CLI (as the site user, inside its own tmp)
    if command -v wp >/dev/null 2>&1; then
        local wp_user="admin_$(openssl rand -hex 3)" wp_pass; wp_pass=$(generate_password 20)
        if sudo -u "$username" HOME="/home/$username/$domain/tmp" wp --path="/home/$username/$domain/public_html" \
            core install --url="http://$domain" --title="$domain" --admin_user="$wp_user" \
            --admin_password="$wp_pass" --admin_email="admin@$domain" --skip-email >/dev/null 2>&1; then
            WP_ADMIN_USER="$wp_user"; WP_ADMIN_PASS="$wp_pass"
            echo "  WP Admin:      http://$domain/wp-admin  user: $wp_user  pass: $wp_pass"
        else
            print_warning "WP-CLI core install failed; finish setup at http://$domain/wp-admin/install.php"
        fi
    fi

    print_success "WordPress installed for $domain"
}

_install_laravel() {
    # _install_laravel <domain> <user> [db_name db_user db_password]
    # Runs composer and artisan as the site user (never root), into an empty
    # public_html. DB is MariaDB over the local socket when given, else sqlite.
    local domain="$1" username="$2" db_name="${3:-}" db_user="${4:-}" db_password="${5:-}"
    local root="/home/$username/$domain" web="/home/$username/$domain/public_html"
    local php="php${DKVPS_PHP_VERSION}"; command -v "$php" >/dev/null || php=php

    print_info "Installing Laravel for $domain (PHP $($php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;'))..."
    _laravel_php_ready "$php" || return 1
    _laravel_composer || return 1

    rm -f "$web/index.html" "$web/index.php"
    if [[ -n "$(ls -A "$web" 2>/dev/null)" ]]; then
        print_error "$web is not empty: Laravel needs an empty site (move or delete the files first)"; return 1
    fi
    mkdir -p "$root/tmp/.composer"; chown -R "$username:$username" "$root/tmp" "$web"
    local -a as=(sudo -u "$username" env HOME="$root/tmp" COMPOSER_HOME="$root/tmp/.composer" COMPOSER_MEMORY_LIMIT=-1 COMPOSER_NO_INTERACTION=1)

    if ! ( cd "$root" && "${as[@]}" "$php" /usr/local/bin/composer create-project --prefer-dist --no-dev --no-progress -q laravel/laravel "$web" ); then
        print_error "composer create-project failed (see output above)"; return 1
    fi
    [[ -f "$web/artisan" ]] || { print_error "Laravel files missing after composer"; return 1; }

    local env="$web/.env"; chmod 0600 "$env"
    _env_set() { if grep -qE "^#? *$1=" "$env"; then sed -i -E "s|^#? *$1=.*|$1=$2|" "$env"; else echo "$1=$2" >> "$env"; fi; }
    _env_set APP_ENV production
    _env_set APP_DEBUG false
    _env_set APP_URL "http://$domain"
    if [[ -n "$db_name" ]]; then
        _env_set DB_CONNECTION mysql
        _env_set DB_HOST localhost
        _env_set DB_PORT 3306
        _env_set DB_DATABASE "$db_name"
        _env_set DB_USERNAME "$db_user"
        _env_set DB_PASSWORD "\"$db_password\""
    fi
    unset -f _env_set
    chown "$username:$username" "$env"

    ( cd "$web" && "${as[@]}" "$php" artisan key:generate --force -q ) || { print_error "artisan key:generate failed"; return 1; }
    if ! ( cd "$web" && "${as[@]}" "$php" artisan migrate --force -q ); then
        print_error "artisan migrate failed: check DB settings in $env"; return 1
    fi
    ( cd "$web" && "${as[@]}" "$php" artisan storage:link -q ) >/dev/null 2>&1
    ( cd "$web" && "${as[@]}" "$php" artisan optimize -q ) >/dev/null 2>&1

    # scheduler, as the site user
    printf 'SHELL=/bin/bash\n* * * * * %s cd %s && %s artisan schedule:run >/dev/null 2>&1\n' \
        "$username" "$web" "$(command -v "$php")" > "/etc/cron.d/dkvps-laravel-${domain//./-}"
    chmod 0644 "/etc/cron.d/dkvps-laravel-${domain//./-}"

    set_config "app" "laravel" "$DKVPS_USER_DIR/.$domain.conf"
    print_success "Laravel installed for $domain"
}

_laravel_php_ready() {   # php binary: install missing extensions Laravel needs
    local php="$1" v miss=() m
    v=$($php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
    for m in mbstring xml dom curl zip bcmath intl pdo_mysql tokenizer fileinfo; do
        $php -m 2>/dev/null | grep -qix "$m" || miss+=("$m")
    done
    command -v unzip >/dev/null || miss+=(unzip)
    [[ ${#miss[@]} -eq 0 ]] && return 0
    print_info "Installing PHP extensions: ${miss[*]}"
    local pk=() x
    for x in "${miss[@]}"; do
        case "$x" in
            unzip) pk+=(unzip) ;;
            dom|xml) pk+=("php$v-xml") ;;
            pdo_mysql) pk+=("php$v-mysql") ;;
            tokenizer|fileinfo) pk+=("php$v-common") ;;
            *) pk+=("php$v-$x") ;;
        esac
    done
    if command -v apt-get >/dev/null; then
        DEBIAN_FRONTEND=noninteractive apt-get install -y -q $(printf '%s\n' "${pk[@]}" | sort -u) >/dev/null || { print_error "Could not install: ${pk[*]}"; return 1; }
    else
        dnf install -y -q $(printf '%s\n' "${pk[@]}" | sed "s/^php$v-/php-/" | sort -u) >/dev/null || { print_error "Could not install: ${pk[*]}"; return 1; }
    fi
    restart_php >/dev/null 2>&1
}

_laravel_composer() {
    if [[ -x /usr/local/bin/composer ]]; then
        /usr/local/bin/composer --version >/dev/null 2>&1 && return 0
    fi
    print_info "Installing Composer..."
    local t; t=$(mktemp -d)
    local sig; sig=$(curl -fsSL https://composer.github.io/installer.sig) || { print_error "Composer download failed"; rm -rf "$t"; return 1; }
    curl -fsSL https://getcomposer.org/installer -o "$t/setup.php" || { print_error "Composer download failed"; rm -rf "$t"; return 1; }
    [[ "$(sha384sum "$t/setup.php" | cut -d' ' -f1)" == "$sig" ]] || { print_error "Composer installer checksum mismatch"; rm -rf "$t"; return 1; }
    php -d memory_limit=-1 "$t/setup.php" --quiet --install-dir=/usr/local/bin --filename=composer || { rm -rf "$t"; return 1; }
    rm -rf "$t"; print_success "Composer $(/usr/local/bin/composer --version 2>/dev/null | awk '{print $3}') installed"
}
