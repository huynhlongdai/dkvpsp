#!/bin/bash
#
# DKVPS - System Monitoring Module
#

show_status_bar() {
    load_config
    local nginx_s=$(service_status nginx)
    local php_s=$(service_status php-fpm)
    local mariadb_s=$(service_status mariadb)

    local status="OK"
    if [[ "$nginx_s" != "active" ]] || [[ "$php_s" != "active" ]] || [[ "$mariadb_s" != "active" ]]; then
        status="ERROR"
    fi

    local disk_info=$(get_disk_info)
    local total_disk=$(echo "$disk_info" | cut -d'|' -f1)
    local used_disk=$(echo "$disk_info" | cut -d'|' -f2)
    local ram_total=$(human_readable $(get_ram_total))
    local ram_used=$(human_readable $(($(get_ram_total) - $(get_ram_available))))

    echo ""
    echo "  Status: $status | Disk: ${used_disk}/${total_disk} | RAM: ${ram_used}/${ram_total} | CPU: $(get_cpu_usage)"
}

show_status() {
    load_config
    local ip="${ip:-$(get_public_ip)}"

    echo ""
    print_header "DKVPS System Status"
    echo ""
    echo "  Date:          $(date +'%Y-%m-%d %H:%M:%S')"
    echo "  IP:            $ip"
    echo "  $(uptime | xargs)"
    echo ""
    echo "  CPU:           $(get_cpu_usage)"
    echo "  RAM:           $(human_readable $(get_ram_total)) (available: $(human_readable $(get_ram_available)))"
    echo "  Swap:          $(human_readable $(get_swap_total)) (free: $(human_readable $(get_swap_free)))"
    local disk_info=$(get_disk_info)
    echo "  Disk:          $(echo $disk_info | tr '|' ' ')"
    echo ""
    print_line
    echo "  Nginx:         $(service_status nginx)"
    echo "  PHP-FPM:       $(service_status php-fpm)"
    echo "  MariaDB:       $(service_status mariadb)"
    echo "  Redis:         $(service_status redis)"
    echo "  Memcached:     $(service_status memcached)"
    echo "  Fail2Ban:      $(service_status fail2ban)"
    echo "  SSHD:          $(service_status sshd)"
    print_line
    echo "  Version:       v${version:-$DKVPS_VERSION}"
    echo "  Docs:          https://github.com/huynhlongdai/dkvpsp"
    print_line
}

show_info() {
    load_config
    echo ""
    print_header "VPS Information"
    echo ""

    echo "  System"
    print_line
    echo "  OS:            $(get_os_name) $(get_os_version)"
    echo "  Kernel:        $(uname -r)"
    if command -v hostnamectl &>/dev/null; then
        echo "  Virtualization: $(hostnamectl 2>/dev/null | grep 'Virtualization' | cut -d':' -f2 | xargs)"
    fi
    echo ""

    echo "  CPU"
    print_line
    echo "  Cores:         $(grep -c ^processor /proc/cpuinfo)"
    echo "  Model:         $(grep 'model name' /proc/cpuinfo | head -1 | cut -d':' -f2 | xargs)"
    echo "  Usage:         $(get_cpu_usage)"
    echo ""

    echo "  Memory"
    print_line
    echo "  RAM:           $(human_readable $(get_ram_total)) (available: $(human_readable $(get_ram_available)))"
    echo "  Swap:          $(human_readable $(get_swap_total)) (free: $(human_readable $(get_swap_free)))"
    echo ""

    echo "  Disk"
    print_line
    df -h / | tail -1 | awk '{printf "  Total: %s | Used: %s | Avail: %s | Use%%: %s\n", $2, $3, $4, $5}'
    echo ""

    echo "  Services"
    print_line
    for svc in nginx php-fpm mariadb redis memcached fail2ban sshd crond; do
        printf "  %-14s: %s\n" "$svc" "$(service_status $svc)"
    done
    echo ""

    echo "  Software"
    print_line
    echo "  PHP:           $(php -v 2>/dev/null | head -1 | awk '{print $2}' || echo 'N/A')"
    echo "  MariaDB:       $(mysql --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo 'N/A')"
    echo "  Nginx:         $(nginx -v 2>&1 | grep -oP '\d+\.\d+\.\d+' || echo 'N/A')"
    echo ""

    echo "  Network"
    print_line
    echo "  IP:            ${ip:-$(get_public_ip)}"
    echo "  SSH Port:      ${port_ssh:-22}"
    echo "  Admin Port:    ${port_admin:-$DKVPS_PORT_ADMIN}"
    echo "  Firewall:      $(fw_state)"
    echo "  Open Ports:    $(fw_list_ports)"
    echo ""
}

show_monitoring() {
    echo ""
    print_header "Real-time Monitoring"
    echo ""
    echo "Press Ctrl+C to exit."
    echo ""

    while true; do
        clear
        show_status
        echo ""
        echo "Top processes by CPU:"
        ps aux --sort=-%cpu | head -6
        echo ""
        echo "Top processes by Memory:"
        ps aux --sort=-%mem | head -6
        sleep 5
    done
}

disk_menu() {
    echo ""
    print_subheader "Disk Management"
    echo ""
    df -h / | tail -1 | awk '{printf "  Total: %s | Used: %s | Avail: %s | Use%%: %s\n", $2, $3, $4, $5}'
    echo ""

    local options=(
        "Full Disk Warning Setup"
        "Check /root"
        "Check /home"
        "Check /var"
        "Check /tmp"
        "Find Large Files"
        "Find Large Files by Domain"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}")
                read -p "Alert when disk available below (GB): " limit
                set_config "limit_disk" "$limit"
                print_success "Full disk alert set to ${limit}GB"
                ;;
            "${options[1]}") du -sh /root/* 2>/dev/null | sort -rh | head -20 ;;
            "${options[2]}") du -sh /home/* 2>/dev/null | sort -rh | head -20 ;;
            "${options[3]}") du -sh /var/* 2>/dev/null | sort -rh | head -20 ;;
            "${options[4]}") du -sh /tmp/* 2>/dev/null | sort -rh | head -20 ;;
            "${options[5]}") find / -type f -size +100M -exec ls -lh {} \; 2>/dev/null | sort -k5 -rh | head -20 ;;
            "${options[6]}")
                choose_domain || return
                local username=$(get_username "$SELECTED_DOMAIN")
                find "/home/$username" -type f -size +10M -exec ls -lh {} \; 2>/dev/null | sort -k5 -rh | head -20
                ;;
            *) return ;;
        esac
    done
}

update_dkvps() {
    echo ""
    print_subheader "Update DKVPS"
    echo ""

    local options=(
        "Update DKVPS Scripts"
        "Update System (dnf/apt)"
        "Update phpMyAdmin"
        "Update rclone"
        "Update acme.sh"
        "Check Version"
    )

    local PS3=$'\n'"Select (1-${#options[@]}) [0=Back]: "
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}")
                source "${CLI_DIR}/modules/update/update.sh"
                update_handler ""
                ;;
            "${options[1]}")
                if [[ "$DKVPS_OS_FAMILY" == "debian" ]]; then
                    apt-get update && DEBIAN_FRONTEND=noninteractive apt-get upgrade -y
                else
                    dnf update -y
                fi
                ;;
            "${options[2]}")
                pma_update
                ;;
            "${options[3]}")
                curl https://rclone.org/install.sh | bash
                ;;
            "${options[4]}")
                "$HOME/.acme.sh/acme.sh" --upgrade 2>/dev/null
                ;;
            "${options[5]}")
                echo "  Current: v${version:-$DKVPS_VERSION}"
                ;;
            *) return ;;
        esac
    done
}

# phpMyAdmin in /usr/share/nginx/dkvps/phpmyadmin: latest release, sha256
# checked, config.inc.php kept, swapped in atomically, previous copy kept
pma_update() {
    local base=/usr/share/nginx/dkvps dir=/usr/share/nginx/dkvps/phpmyadmin
    [[ -d "$dir" ]] || { print_error "phpMyAdmin not installed in $dir"; return 1; }
    local cur new
    cur=$(grep -oE "VERSION = '[^']+'" "$dir/libraries/classes/Version.php" "$dir/src/Version.php" 2>/dev/null | head -1 | cut -d"'" -f2)
    new=$(curl -fsSL --max-time 20 https://www.phpmyadmin.net/home_page/version.txt | head -1)
    [[ "$new" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { print_error "Could not read the latest phpMyAdmin version"; return 1; }
    if [[ "$cur" == "$new" ]]; then print_success "phpMyAdmin $cur is the latest"; return 0; fi
    print_info "phpMyAdmin ${cur:-?} -> $new"
    local t; t=$(mktemp -d)
    local url="https://files.phpmyadmin.net/phpMyAdmin/$new/phpMyAdmin-$new-all-languages.tar.gz"
    curl -fsSL --max-time 300 -o "$t/pma.tgz" "$url" && curl -fsSL --max-time 30 -o "$t/pma.sha" "$url.sha256" \
        || { print_error "Download failed"; rm -rf "$t"; return 1; }
    [[ "$(sha256sum "$t/pma.tgz" | cut -d' ' -f1)" == "$(awk '{print $1}' "$t/pma.sha")" ]] || { print_error "Checksum mismatch"; rm -rf "$t"; return 1; }
    tar -xzf "$t/pma.tgz" -C "$t" || { print_error "Extract failed"; rm -rf "$t"; return 1; }
    local nd="$t/phpMyAdmin-$new-all-languages"
    cp -a "$dir/config.inc.php" "$nd/" 2>/dev/null
    rm -rf "$nd/setup"
    chown -R "$(stat -c %U:%G "$dir")" "$nd"
    rm -rf "$base/phpmyadmin.old"
    mv "$dir" "$base/phpmyadmin.old" && mv "$nd" "$dir" || { print_error "Swap failed"; [[ -d "$dir" ]] || mv "$base/phpmyadmin.old" "$dir"; rm -rf "$t"; return 1; }
    rm -rf "$t"
    print_success "phpMyAdmin updated to $new (previous copy: $base/phpmyadmin.old)"
}
